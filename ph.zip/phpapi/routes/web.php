<?php

$router->group([
    'namespace' => 'V1_1',
    'prefix' => 'api/v1_1',
    'middleware' => ['signToken']
], function () use ($router) {
    $router->group([
        'namespace' => 'Common',
        'middleware' => 'throttle:1,60',
    ], function () use ($router) {
        $router->get('Basis/GetValidateCode', 'SmsController@get');//获取验短信证码
    });

    $router->group([
        'namespace' => 'Mine',
        'middleware' => ['auth', 'throttle:10,1'],//JWT Token验证
    ], function () use ($router) {
        $router->post('Book/AddBookShelf', ['uses' => 'ShelfController@add', 'middleware' => 'checkHeader']);//增加到书架
        $router->post('Book/DelMyBookSehlf', 'ShelfController@del');//删除我的书架
        $router->get('Book/GetMyBookShelf', 'ShelfController@index');//获取我的书架


        $router->post('Book/Reflect', 'ReflectController@index');//举报

        $router->get('Member/GetMemberInfo', 'InfoController@index');//获取用户信息
        $router->post('Member/UpdateNickname', 'InfoController@name');//修改用户名称
        $router->post('Member/UpdateHeadImgurl', 'InfoController@face');//修改用户头像
        $router->post('Member/UpdateGender', 'InfoController@sex');//修改用户性别

        $router->post('Member/Feedback', 'FeedbackController@index');//问题反馈

        $router->get('Book/UpdateShellBookLastTime', 'ShelfController@bookLastTime');

    });
    $router->group([
        'namespace' => 'Mine',
        'middleware' => ['skipToken', 'throttle:10,1'],
    ], function () use ($router) {
        $router->get('Book/GetBookByLike', 'ShelfController@memberByLike');//猜你喜欢
    });
    $router->group([
        'namespace' => 'Mine',
        'middleware' => ['throttle:10,1'],
    ], function () use ($router) {
        $router->post('Book/BookUpdateLastTime', 'ShelfController@updateLastTime');//获取书箱最后更新时间 （在没有登录的时情况下）
    });

    $router->group([
        'namespace' => 'Common',
        'prefix' => 'Auth',
        'middleware' => ['throttle:10,1'],

    ], function () use ($router) {
        $router->post('Login', ['uses' => 'AuthController@login', 'middleware' => ['checkHeader']]);//登录
    });
    $router->group([
        'namespace' => 'Common',
        'prefix' => 'Auth',
        'middleware' => ['throttle:10,1', 'checkHeader'],
    ], function () use ($router) {
        $router->post('Refreshtoken', 'AuthController@refresh');//刷新TOKEN
    });
    $router->group([
        'namespace' => 'Common',
        'prefix' => 'Member',
        'middleware' => ['auth', 'checkHeader'],
    ], function () use ($router) {
        $router->post('Logout', 'AuthController@logout');//退出系统
    });


});



