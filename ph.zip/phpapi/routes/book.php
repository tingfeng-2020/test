<?php

$router->group(['prefix' => 'api', 'middleware' => ['signToken']], function () use ($router) {
    $router->group(['prefix' => 'v1_1', 'namespace' => 'V1_1'], function () use ($router) {
        //获取书籍详情
        $router->group(['prefix' => 'Book', 'namespace' => 'Book', 'middleware' => ['throttle:10,1']], function () use ($router) {
            //获取书籍详情
            $router->get('GetBookById', ['uses' => 'BookController@getBookById', 'middleware' => ['skipToken', 'checkHeader']]);
            //搜索书籍
            $router->get('SearchBooks', ['uses' => 'BookController@search', 'middleware' => ['skipToken', 'checkHeader']]);


            //书籍分享
            $router->get('BookShare', 'BookController@share');
            //热门推荐
             $router->get('GetHotBooks', 'BookController@hotBook');
            //本书友还在读
            $router->get('GetCurrentReaderBooks', 'BookController@getBookBySimilar');


            //获取章节内容
            $router->get('GetBookChapter', 'ChapterController@getChapter');
            //获取书籍目录
            $router->get('GetBookCatalogue', 'ChapterController@getBookCatalogue');
            //下载章节
            $router->get('GetBookChapterDownload', 'ChapterController@getBookByNum');


            //获取书单分类
            //  $router->get('GetBookListClassify', 'ClassController@getBookListClassify');

            //获取书单分类下的书单
            $router->get('GetBookList', 'ClassController@getBookList');
            //获取书单下的书籍
            $router->get('GetBookListDetailPage', 'ClassController@getBookListDetailPage');


            //排行榜分类

            // $router->get('GetRankingClassify', 'RankController@getRankingClassify');

            //排行榜内的书籍
            $router->get('GetRankingBooks', 'RankController@getRankingBooks');

            /**
             * 1.1版本
             */




            //获取作者信息
            $router->get('GetAuthor', 'AuthorController@getAuthorInfo');

            //标签书籍接口
            $router->get('GetBookByTag', 'BookController@getBookByTag');

            //完本书籍
            $router->get('GetCompleteBooks', 'BookOverController@getBookByOver');

            //完本书籍推荐接口
            $router->get('OverRecommend', 'BookOverController@recommend');

            //最新完本书籍接口
            $router->get('OverBookByNews', 'BookOverController@overBookByNews');

            //人气完本接口
            $router->get('OverBookByHot', 'BookOverController@overBookByHot');


            $router->group(['middleware' => 'ClassMatchMiddleware'], function () use ($router) {
                //获取书籍分类
                $router->get('GetBookClass', 'ClassController@GetBookClass');

                //获取分类下的书籍
                $router->get('GetClassBookPage', 'BookController@getBookByClass');

                //获取相同分类书籍
                $router->get('GetClassBookSimilar', 'BookController@getBookSimilar');

                //根据书籍分类获取排行榜
                $router->get('GetRankingByClassId', 'RankController@getRankingByClassId');
            });


        });

    });

});
