<?php

/**
 * Created by PhpStorm.
 * User: xp
 * Date: 2020/6/05
 * Time: 13:39
 * 书城首页基础模块-日志模块
 */
class BasicsTest extends TestCase
{
    /**
     * 板块分类数据
     */
    public function testGetPlates()
    {
        $this->request('get', $this->v.'/Basis/GetPlates');
    }
    /**
     * 板块模块数据
     */
    public function testGetPlateDataItem()
    {
        $this->request('get', $this->v.'/Basis/GetPlateDataItem',['platesId'=>25]);
    }

    /**
     * 获取板块更多数据
     */
    public function testGetPanelMoreData()
    {
        $this->request('get', $this->v.'/Basis/GetPanelMoreData',['plateid'=>25]);
    }

    /**
     * 广告位获取
     */
    public function testGetAdSlot()
    {
        $this->request('get', $this->v.'/Basis/GetAdSlot',['module'=>0]);
    }

    /**
     * 获取广告列表
     */
    public function testGetBanners()
    {
        $this->request('get', $this->v.'/Basis/GetBanners',['slot_id'=>[6]]);
    }

    /**
     * 字体包获取
     */
    public function testGetFontPackage()
    {
        $this->request('get',$this->v.'/Basis/GetFontPackage');
    }

    /**
     * 热门搜索词
     */
    public function testGetWordSearch()
    {
        $this->request('get',$this->v.'/Basis/GetWordSearch');
    }
    /**
     * 听书上报数据
     */
    public function testListenTime()
    {
        $time = time();
        $param = [
            'start_time'=>$time - 2000,
            'end_time'=>$time
        ];
        $this->request('post',$this->v.'/logs/listenTime',$param);
    }
    /**
     * 听书上报数据
     */
    public function testReadTime()
    {
        $time = time();
        $param = [
            'start_time'=>$time - 2000,
            'end_time'=>$time,
            'light'=>12,
            'font'=>'微软雅黑',
            'fonz_size'=>12,
            'flip_style'=>'仿真',
            'background'=>'#ffffff',
            'book_id'=>1
        ];
        $this->request('post',$this->v.'/logs/readTime',$param);
    }
    /**
     * 打开或者关闭app时上报数据
     */
    public function testOpenOrCloseApp()
    {
        $this->request('post',$this->v.'/logs/openOrCloseApp',['status'=>1]);
    }
    /**
     * app留存数据上报
     */
    public function testKeepApp()
    {
        $this->request('post',$this->v.'/logs/keepApp');
    }
    /**
     * 广告点击上报
     */
    public function testAdvertClick()
    {
        $this->request('post',$this->v.'/logs/advertClick',['ad_id'=>[1]]);
    }
    /**
     * 广告曝光上报
     */
    public function testAdvertExpo()
    {
        $this->request('post',$this->v.'/logs/advertExpo',['ad_id'=>[1]]);
    }



}
