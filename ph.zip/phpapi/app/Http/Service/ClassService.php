<?php


namespace App\Http\Service;


use App\Cache\BookListBookCache;
use App\Cache\BookListCache;
use App\Cache\BookListClassCache;
use App\Cache\ClassifyCache;
use App\Cache\ClassifyInParentCache;
use App\Cache\ClassifyInRankingCache;
use App\Exceptions\ApiExceptions;

class ClassService
{

    /**
     * 获取书单分类
     * @return mixed|null
     */
    public function GetBookListClassify()
    {
        $result = BookListClassCache::getInstance('class')->getDetail();

        foreach ($result as &$k) {
            $k = json_decode($k, true);
        }
        unset($k);
        return $result;
    }

    /**
     * 获取书单分类下的书单
     * @return array
     */
    public function getBookList(): array
    {
        $result = BookListCache::getInstance('All')->getDetail();
        $return = [];
        if ($result) {
            ksort($result);
            $return = array_map('json_decode', $result);
        }
        return $return;


    }

    /**
     * 获取书单下单书籍
     * @param $classId
     * @param int $page
     * @param int $pageSize
     * @return array
     */
    public function getBookListDetailPage($classId, $page = 1, $pageSize = 10): array
    {
        $re = BookListBookCache::getInstance($classId)->getDetail();

        $count = count($re);
        $bookId = array_slice($re, ($page - 1) * $pageSize, $pageSize);
        $service = new BookService();
        $result = [];
        foreach ($bookId as $k => $v) {
            try {
                if ($book = $service->getBookById($v)) {
                    $result[] = $book;
                }
            } catch (ApiExceptions $exception) {
                if ($exception->getCode() === 1105) {
                    --$count;
                    continue;
                }
                throw new ApiExceptions($exception->getCode());
            }

        }

        return [
            'page_index' => $page,
            'page_size' => $pageSize,
            'total_count' => $count,
            'page_count' => ceil($count / $pageSize),
            'grid_data' => $result
        ];
    }


    /**
     * 获取当前分类下的子分类
     * @param $classId
     * @param  $type
     * @return array
     */
    public function getClassify($classId = 0, $type = 0): array
    {
        if ($type) {
            $result = ClassifyInRankingCache::getInstance($classId)->getDetail();
        } else {
            $result = ClassifyInParentCache::getInstance($classId)->getDetail();

        }
        $result = array_map('json_decode', $result);
        ksort($result);

        return $result;
    }

    /**
     * 获取排行榜下的分类
     * @param $classId
     * @return array
     */
    public function getClassByRanking($classId = 0): array
    {
        $result = ClassifyInParentCache::getInstance($classId)->getDetail();
        $result = array_map('json_decode', $result);
        ksort($result);

        return $result;
    }


    /**
     * 获取分类信息
     * @param $classId
     * @return array
     */
    public function getByClassify($classId): array
    {
        return ClassifyCache::getInstance($classId)->getDetail();


    }

}
