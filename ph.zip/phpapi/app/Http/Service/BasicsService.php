<?php


namespace App\Http\Service;

use App\Exceptions\ApiExceptions;
use App\Model\Ad\AdModel;
use App\Model\Ad\AdSlotModel;
use App\Model\Basics\AppVersionModel;
use App\Model\Basics\BookClassModel;
use App\Model\Basics\ClassifyModel;
use App\Model\Basics\PageConfigModel;
use App\Model\Basics\PlateBookModel;
use App\Model\Basics\PlateClassifyBannerModel;
use App\Model\Basics\PlateClassifyModel;
use App\Model\Basics\PlateModel;
use App\Model\Basics\WordSearchModel;
use App\Model\FontModel;



class BasicsService extends BaseService
{
    public function getWordSearch($top =10)
    {
        $key = $this->key['WORD_SEARCH'].":".$top;
        if ($data = $this->redis->get($key)) return $data;
        $data = WordSearchModel::query()->limit($top)->orderBy('sort','asc')->pluck('word_name');
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
       return $data? $data->toArray():[];
    }
    public function getProtocol($type)
    {
        $key = $this->key['PROTOCOL'].':'.$type;
        if ($data = $this->redis->get($key)) return $data;
        $data = PageConfigModel::query()->where('type',$type)->first(['content','link','type']);
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data ? $data->toArray():[];
    }
    public function getPageLink()
    {
        $key = $this->key['PAGE_LINK'];
        if ($data = $this->redis->get($key)) return $data;
        $res = PageConfigModel::query()->get(['link','type']);
        $data = [];
        foreach ($res as &$v) {
            if ($v['type'] ==1) {
                $data['UserAgreement'] = $v['link'];
            }elseif($v['type'] ==2) {
                $data['PrivacyPolicy'] = $v['link'];
            }elseif ($v['type'] ==3) {
                $data['TortComplain'] = $v['link'];
            }
            unset($v['link']);
        }
        unset($v);
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data;
    }
    public function getAppVersion($type)
    {
        $key = $this->key['APP_VERSION'].':'.$type;
        if ($data = $this->redis->get($key)) return $data;
        $data = AppVersionModel::query()->where('type',$type)->first();
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data ? $data->toArray():[];

    }
    public function getPanelMoreData($param)
    {
       $pageIndex = $param['page_index']??1;
        $pageSize = getPageSize($param);
        $key = sprintf($this->key['PLATE_MORE_DATA'],$param['plateid'].':'.$pageIndex.':'.$pageSize);
        if ($data = $this->redis->get($key)) return $data;
        $map['a.plate_id'] = (int)$param['plateid'];
        $res = PlateBookModel::query()->from('plate_book as a')
            ->leftJoin('plate as b','a.plate_id','=','b.id')
            ->where($map)
            ->orderBy('a.sort')
            ->paginate($pageSize,['a.book_id'],'page_index')->toArray();
        $da = [];
        foreach ($res['data'] as $v) {
            try {
                $da[] = $this->getBookInfo($v['book_id']);
            } catch (ApiExceptions $e) {
                continue;
            }

        }

        $data = pageDeal($param,$res);
        $data['grid_data'] = $da;
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data;
    }
    public function getBookInfo($book_id)
    {
        $key = $this->key['BOOK_INFO_RESULT'].":BOOK_ID:".$book_id;
        if ($rd = $this->redis->get($key)) return json_decode($rd,true);
        $bs = new BookService();
        $book_info = $bs->getBookById($book_id);
        $this->redis->setex($key,config('cache.ttl'),json_encode($book_info));
        return $book_info;
    }

    public function getPlates()
    {
        $key = $this->key['GET_PLATE'];
        if ($data = $this->redis->get($key)) return $data;
        $data = PlateClassifyModel::query()->where('status',1)->orderBy('sort','asc')->get(['id','name']);
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data ? $data->toArray():[];

    }
    public function getPlateBanners($platesId)
    {
        $key = $this->key['PLATE_BANNERS'].':'.$platesId;
        if ($data = $this->redis->get($key)) return $data;
        $data = PlateClassifyBannerModel::query()->where(['is_enable'=>1,'classify_id'=>$platesId])
            ->selectRaw('if(img_url!="",CONCAT("' . env('MEDIA_HOST') . '",img_url),"") as img_url,link,type,app_Param' )
            ->orderBy('sort','asc')
            ->get();
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data ? $data->toArray():[];
    }
    public function getPlateDataItem($param)
    {
        $topcount = $param['topcount']??5;
        $key = sprintf($this->key['PLATE_DATA'],$param['platesId'].':' . $topcount);
        if ($data = $this->redis->get($key)) return $data;
        $data = PlateModel::query()->where(['classify_id'=>$param['platesId'],'status'=>1])->limit(5)->orderBy('sort','asc')->get(['id','name']);
        $plateNum =[4,4,3,8,4];
       foreach ($data as $k=>&$v) {
            $d = PlateBookModel::query()->where(['plate_id'=>$v['id']])->orderBy('sort')
                ->limit($plateNum[$k])->get(['book_id']);
           $d = $d ? $d->toArray() : [];
           $da = [];
            foreach ($d as $n) {
                try {
                    $da[] = $this->getBookInfo($n['book_id']);
                }catch (ApiExceptions $e){
                    continue;
                }

            }
            $v['dataItem'] = $da;
        }
        unset($v);
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data;
    }
    public function getClassifyTree()
    {
        $key = $this->key['CLASSIFY_TREE'];
        if ($data = $this->redis->get($key)) return $data;

          $data = ClassifyModel::query()->where(['status'=>1])->orderBy('sort','asc')
            ->selectRaw('id,name,parent_id,code,related_name,if(icon !="",CONCAT("' . env('MEDIA_HOST') . '",icon),"") as icon')
            ->get();
        foreach ($data as $k=>&$v) {
            if ($v['parentId'] > 0) {
                $v['book_nums'] = BookClassModel::query()->from('book_class as a')
                    ->leftJoin('book as b','a.book_id','=','b.id')
                    ->where(['classify_id'=>$v['id'],'b.status'=>1])->count();
                $status = ClassifyModel::query()->where('Id',$v['parentId'])->value('status');
                if($status == '0' || $v['book_nums'] ==0){
                    unset($data[$k]);
                }
            }

        }
        unset($v);
         $newData = $data ? getTree($data->toArray(),'parent_id','childrenClassify','id'):[];
         if (!empty($newData))$this->redis->setex($key,config('cache.ttl'),json_encode($newData));
         return $newData;

    }
    public function getBanners($param)
    {
        $slot_id = $param['slot_id'];
        if (!is_array($slot_id)) {
            $slot_id = [$slot_id];
        }

        $key = $this->key['AD_LIST'].':OS:'.$param['os'].':SLOT_ID:'.json_encode($slot_id);

        if ($ad = $this->redis->get($key)) return $ad;

        $res = AdModel::query()->from('ad as a')
            ->leftJoin('ad_material as b','a.material_id','=','b.id')
            ->whereIn('a.slot_id',$slot_id)
            ->whereRaw("find_in_set({$param['os']},a.os)")
            ->orderByRaw('RAND()')
            ->limit(10)
            ->selectRaw('a.id,a.material_id,a.slot_id,a.jump_data,a.sleep,b.title,b.desc,b.url,b.style,b.sub_desc')
            ->get();
        $data = $res->toArray();
        $ad =[];
        foreach ($data as $v) {
            $slot = AdSlotModel::query()->where('id',$v['slot_id'])->first(['status','mark']);
            if (empty($slot)) continue;
            if ($slot->status ==1) {
                $v['url'] = env('MEDIA_HOST').$v['url'];
                $v['jump_data'] =$v['jump_data'][$param['os']];
                $ad[$slot->mark][] = $v;
            }else{
                $ad[$slot->mark][] =[];
            }

       }
        $this->redis->setex($key,config('cache.ttl'),json_encode($ad));
        return $ad;

    }

    public function getAdSlot($param)
    {
        $module = $param['module'] ?? 0;
        $key = $this->key['AD_SLOT'].':module:'. $module;
        if ($data = $this->redis->get($key)) return $data;
        $data = [];
        $map = [];
        if ($module) $map['module'] = $module;
        $res = AdSlotModel::query()->where($map)->get(['id','name','desc','mark','status']);
        foreach ($res as $v) {
            $data[$v['mark']] = $v;
        }
        $this->redis->setex($key, config('cache.ttl'), json_encode($data));
        return $data;
    }
    public function getFontPackage()
    {
        $key = $this->key['FONT_PACKAGE'];
        if ($rd = $this->redis->get($key)) return $rd;
        $data = FontModel::query()->orderBy('sort')->get(['name','url','size','preview','preview_dark']);
        $this->redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data;
    }


}
