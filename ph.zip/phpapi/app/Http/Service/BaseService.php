<?php


namespace App\Http\Service;


use App\Tools\Redis;

class BaseService
{

    protected $redis;
    protected $key;

    public function __construct()
    {
        $class = basename(str_replace('\\', '/', get_called_class()));
        $key = strtolower(str_replace('Service','',$class));
        $this->key = config('cache_key.'.$key);
        $this->redis = Redis::getInstance();
    }











}
