<?php

namespace App\Http\Middleware;

use App\Cache\TokenCache;
use Illuminate\Http\Request;


/**
 * JWT Token验证类
 * Class CheckJwtToken
 * @package App\Http\Middleware
 */
class SkipToken
{
    public function handle(Request $request, \Closure $next, $skip = false)
    {
        //判断处理
        if (!$request->header('Authorization')) {
            $request->offsetUnset('uid');
            return $next($request);
        }

        $uid = TokenCache::getAccessToken($request->header('Authorization'));

        if(!$uid)
        {
            TokenCache::delAccessToken($request->header('Authorization'));
        }

        $request->offsetSet('uid',$uid);


       return $next($request);
    }
}
