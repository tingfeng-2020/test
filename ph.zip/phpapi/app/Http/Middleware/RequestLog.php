<?php

/**
 *
 * 记录请求日志log
 *
 */

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;


class RequestLog
{
    public function handle(Request $request, \Closure $next)
    {
        // dd($request);
        $response = $next($request);
        $return = ['code' => 200, 'msg' => '成功', 'data' => []];
        if ($response->content() === 'object') {
            $return['data'] = (object)[];
        }

        if ($result = json_decode($response->content(), true)) {
            if (!isset($result['code'])) {

                $return['data'] = $this->toString($result);
            } else {
                $return = $result;
            }
        }
        $par = [
            'method' => $request->method(),
            'ip' => $request->ip(),
            'url' => $request->url(),
            'request' => $request->all(),
        ];
        if ($return['code'] !== 200) {
            Log::info(json_encode($par), $return);
        }
        if (10000 === $return['code']) {
            //返回微信所需数据
            $str = '<xml> <return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';
            return response($str);
        }
        return response()->json($return);

    }

    protected function toString($data)
    {
        if (is_array($data)) {
            foreach ($data as $k => $v) {
                if (!is_array($v)) {
                    $data[$k] = (string)$v;
                } else {
                    $data[$k] = $this->toString($v);
                }
            }
            return $data;
        }
        return $data;
    }


}
