<?php


namespace App\Http\Middleware;

use App\Exceptions\ApiExceptions;
use Closure;
use Illuminate\Support\Facades\Log;

/**
 * header 必传字段验证
 * Class CheckSignToken
 * @package App\Http\Middleware
 */
class ClassMatchMiddleware
{


    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {


        $config = [
            1 => env('CLASS_MAN'),
            2 => env('CLASS_WOMAN'),
        ];
        if ($request->get('class_id') && isset($config[$request->get('class_id', 1)])) {
            $request->offsetSet('class_id', $config[$request->get('class_id')]);
        }
        return $next($request);
    }
}
