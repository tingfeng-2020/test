<?php


namespace App\Http\Middleware;

use App\Exceptions\ApiExceptions;
use Closure;

/**
 * header 必传字段验证
 * Class CheckSignToken
 * @package App\Http\Middleware
 */
class CheckDefaultField
{

    const REQUIRHEADER = [
        'device', 'deviceModel', 'os', 'area', 'channel'
    ];

    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        foreach (self::REQUIRHEADER as $h) {
            if ( !$request->hasHeader($h) && $request->header('os') !=3) {
                throw new ApiExceptions(1005,'',[$h]);
            }
            if ($request->hasHeader($h)) {
                if ($h == 'os' && ($request->header($h) > 3 || !is_numeric($request->header($h))))
                    throw new ApiExceptions(1005,'',[$h]);
                if ($h == 'channel' && !is_numeric($request->header($h)))
                    throw new ApiExceptions(1005,'',[$h]);
                $request->offsetSet($h == 'deviceModel' ? 'device_model' : $h, $request->header($h));
            }

        }
        $request->offsetUnset('member_id');

        if ($request->hasHeader('Authorization')) {
            $request->offsetSet('member_id', $request->get('uid'));
        }

        return $next($request);
    }
}
