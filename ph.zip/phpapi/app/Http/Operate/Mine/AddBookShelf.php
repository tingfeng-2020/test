<?php

namespace App\Http\Operate\Mine;

use App\Cache\BookCache;
use App\Cache\MemberCache;
use App\Cache\ShelfCache;
use App\Exceptions\ApiExceptions;
use App\Http\Operate\BaseOperate;
use App\Model\BookModel;
use App\Model\BookShelfModel;
use App\Task\LogTask;
use App\Tools\Redis;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * 添加到书架
 * Class AddBookShelf
 * @package App\Http\Operate\Mine
 */
class AddBookShelf extends BaseOperate
{
    protected $bookIdArr = [];

    public function __construct(Request $request)
    {
        parent::__construct($request);
        $this->bookIdArr = json_decode($request->getContent() , true);
    }

    /**
     * 判断书籍是否存在
     */
    protected function checkBookExists()
    {
        $res_ids = BookModel::query()->where('status',1)
                   ->whereIn('id',$this->bookIdArr)
                   ->pluck('id')->toArray();
        $this->bookIdArr = $res_ids;
    }

    /**
     * 判断书籍是否已加入书架
     */
    protected function checkBookAdded()
    {
        //获取我的书架中的书籍ID列表
        $hasArr = BookShelfModel::query()->where('member_id',$this->request->uid)
                  ->whereIn('book_Id',$this->bookIdArr)
                  ->pluck('book_Id')->toArray();
        if($hasArr) $this->bookIdArr = array_diff($this->bookIdArr, $hasArr);

    }

    protected function check()
    {
        // TODO: Implement check() method.
        if(empty($this->bookIdArr))
        {
            throw new ApiExceptions(1005 , '书籍ID不能为空！');
        }

        $this->bookIdArr = array_unique($this->bookIdArr);

        $this->checkBookExists();

        $this->checkBookAdded();
    }

    protected function doBusiness()
    {
        // TODO: Implement doBusiness() method.

        $createTime = date('Y-m-d H:i:s');
        $uid = $this->request->uid;
        try {
            DB::beginTransaction();
            foreach ($this->bookIdArr as $v) {
                $m = new BookShelfModel();
                $m->book_Id = $v;
                $m->member_id = $uid;
                $m->book_last_time = $createTime;
                $m->createtime = $createTime;
                $res = $m->save();
                if(!$res) {
                    DB::rollBack();
                    throw new ApiExceptions(1000);
                }
                //添加用户加入书架log记录
                $this->request->offsetSet('addOption','shelfLog');
                $this->request->offsetSet('book_id',$v);
                $task = new LogTask($this->request->all());
                Task::deliver($task);
            }
             DB::commit();
        }catch (QueryException $ex) {
            DB::rollBack();
            throw new ApiExceptions(1000);
        }

        //加入我的书架列表缓存中
        foreach ($this->bookIdArr as $bookId)
        {
            ShelfCache::getInstance($this->request->uid)->addBookShelf($bookId , $createTime);
        }
        //删除书架字符序列化缓存
        Redis::getInstance()->del(config('cache_key.shelf.BOOK_SHELF_STRING').":UID:".$uid);

        return;
    }
}
