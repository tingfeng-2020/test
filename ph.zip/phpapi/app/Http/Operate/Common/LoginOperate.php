<?php


namespace App\Http\Operate\Common;


use App\Cache\MemberCache;
use App\Cache\MobileCache;
use App\Exceptions\ApiExceptions;
use App\Http\Operate\BaseOperate;
use App\Http\Service\SMSService;
use App\Http\Service\TokenService;
use App\Model\MembersModel;
use App\Task\LogTask;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

/**
 * 会员登录
 * Class LoginOperate
 * @package App\Http\Operate\Common
 */
class LoginOperate extends BaseOperate
{

    protected function check()
    {
        //数据验证
        $this->validate($this->request, [
            'account' => 'required|max:11',//手机号判断
            'code' => 'required', //验证码
            'gender' => 'in:0,1,2' //性别，只能为0或1、2
        ]);

        //短信验证码验证
        $service = new SMSService();
        $service->checkSMS($this->request->post('account'), 1, $this->request->post('code'));
    }

    public function doBusiness()
    {
        $uid = MobileCache::getInstance($this->request->post('account'))->getDetail();

        if (empty($uid) || $uid =='null') {
            $member = $this->doReg();
        } else {
            $member = MemberCache::getInstance($uid);
            if ($getui_cid = $this->request->get('getuiCid')){
                //异步更新推送设置
                $info = $this->request->all();
                $info['id'] = $uid;
                $info['addOption'] = 'addMemberGetui';
                $task = new LogTask($info);
                Task::deliver($task);
                //$this->addMemberGetui($uid,$getui_cid);
            }
            MembersModel::query()->where('id',$uid)->update(
                [
                    'last_time'=>date("Y-m-d H:i:s"),
                    'ip'=>!empty($this->request->ip())?ip2long($this->request->ip()):0,
                    'area'=>$this->request->get('area','')
                ]
            );
        }

        //生成token
        list($accessToken, $refreshToken) = TokenService::generateToken($member->id);

        $icon = getFilePath($member->icon);
        return [
            'account' => hidePhone($this->request->post('account')),
            'authorization' => $accessToken,//访问接口的令牌
            'refreshToken' => $refreshToken,//刷新令牌
            'nickName' => $member->nickname ? $member->nickname : $this->request->post('account'),
            'gender' => $this->request->post('gender'),
            'icon' => $icon ? env('MEDIA_HOST').$icon:env('MEDIA_HOST').env('DEFAULT_HEADER'),
        ];
    }

    protected function doReg()
    {
        try {
            $date = date("Y-m-d H:i:s");
            //不存在则注册
            $member = new MembersModel();
            $member->account = $this->request->post('account');
            $member->gender = $this->request->post('gender');
            $member->nickname = defaultNickname($this->request->post('account'));
            $member->icon = '';
            $member->area = $this->request->get('area','');
            $member->ip = !empty($this->request->ip())?ip2long($this->request->ip()):0;
            $member->createtime = $date;
            $res = $member->save();
            if (!$res) {
                throw new ApiExceptions(1000);
            }
            DB::commit();
            //异步初始化用户其他信息
            $userInfo['info'] = json_decode($member,true);
            $userInfo['other'] = array_merge($this->request->all(),$userInfo['info']);
            $userInfo['addOption'] = 'dealMemberInit';
            $task = new LogTask($userInfo);
            Task::deliver($task);

        } catch (QueryException $ex){
            throw new ApiExceptions(1007,'',$ex->getMessage());
        }
        return $member;
    }

}
