<?php

namespace App\Http\Operate\Common;

use App\Exceptions\ApiExceptions;
use App\Http\Operate\BaseOperate;
use App\Http\Service\SMSService;


/**
 * 获取短信验证码
 * Class GetSmsCode
 * @package App\Http\Operate\Common
 */
class GetSmsCode extends BaseOperate
{
    protected function check()
    {
        //数据验证
        if(!preg_match("/^1[34578]\d{9}$/", $this->request->get('MobileNumber'))){
            throw new ApiExceptions(1111);
        }

    }

    protected function doBusiness()
    {
        // TODO: Implement doBusiness() method.
        //加入短信发送队列
        $data = [
            'type' => '1',
            'phone' => $this->request->get('MobileNumber')
        ];

        $obj = new SMSService();
        return $obj->send($data);
    }
}
