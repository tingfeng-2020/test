<?php

namespace App\Http\Operate\Common;

use App\Cache\TokenCache;
use App\Exceptions\ApiExceptions;
use App\Http\Operate\BaseOperate;
use App\Http\Service\TokenService;
use App\Model\MemberGetuiModel;

/**
 * 注销登录
 * Class MemberLogout
 * @package App\Http\Operate\Common
 */
class MemberLogout extends BaseOperate
{

    protected function doBusiness()
    {
        // TODO: Implement doBusiness() method.
        if(!$this->request->header('Authorization'))
            throw new ApiExceptions(1005,'','Authorization');


        $uid = TokenCache::getAccessToken($this->request->header('Authorization'));
        if($uid)
        {
            $appGuid = $this->request->post('appGuid');
            $getuiCid=$this->request->post('getuiCid');
            if ( $appGuid || $getuiCid) {
                $os = $this->request->get('os',0);
                if ($os ==1 && $appGuid) {
                    MemberGetuiModel::query()->where(['app_guid'=>$appGuid,'member_id'=>$uid])->update(['status'=>1,'exp'=>(time()-12)]);
                } elseif($getuiCid) {
                    MemberGetuiModel::query()->where(['getui_cid'=>$getuiCid,'member_id'=>$uid])->update(['status'=>1,'exp'=>(time()-12)]);
                }

            }
            TokenCache::delUserToken($uid);
        }

        try
        {
            $result = TokenService::checkToken($this->request->header('Authorization'));
            if($result && $result->uid)
                TokenCache::delUserToken($uid);
        }
        catch (\Exception $exception)
        {
            throw new ApiExceptions(403,'',$exception->getMessage());
        }
        return;

    }
}
