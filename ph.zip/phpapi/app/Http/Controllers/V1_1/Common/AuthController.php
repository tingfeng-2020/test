<?php

namespace App\Http\Controllers\V1_1\Common;

use App\Cache\TokenCache;
use App\Http\Controllers\Controller;
use App\Http\Operate\Common\LoginOperate;
use App\Http\Operate\Common\MemberLogout;
use App\Http\Operate\Common\RefreshToken;
use App\Http\Service\TokenService;
use Firebase\JWT\JWT;
use Illuminate\Http\Request;

/**
 * 登录与注册
 * Class AuthController
 * @package App\Http\Controllers\V1_1\Common
 */
class AuthController extends Controller
{
    /**
     * 登录
     * @param Request $request
     * @return mixed
     */
    public function login(Request $request)
    {
        $operate = new LoginOperate($request);
        return $operate->done();

    }

    /**
     * 退出系统
     * @param Request $request
     * @return mixed
     */
    public function logout(Request $request)
    {
        $operate = new MemberLogout($request);
        $operate->done();
    }

    /**
     * 刷新令牌
     * @param Request $request
     * @return mixed
     */
    public function refresh(Request $request)
    {
        $operate = new RefreshToken($request);
        return $operate->done();
    }
    public function test()
    {
        $key = env('JWT_SECRET');

        $uid = mt_rand(10000,100000);

        $time = time();

        $accessTokenTtl = 60;//env('JWT_TTL',60000);
        $content = [
            'uid' => $uid,
            'iat' => $time,//签发时间
            'nbf' => $time,
            'exp' => $time + $accessTokenTtl,//access_token有效期
            'scopes' => 1 //token标识，请求接口的token
        ];

        //生成访问令牌access_token
        $accessToken = JWT::encode($content,$key);

        //生成刷新令牌refresh_token
        $refreshTokenTtl = 120;//env('JWT_REFRESH_TTL' , 2592000);
        $content['exp'] = $time + $refreshTokenTtl;//refresh_token有效期
        $content['scopes'] = 2;//token标识，刷新access_token

        $refreshToken = JWT::encode($content,$key);
        TokenCache::setUserToken($uid , $accessToken , $accessTokenTtl , $refreshToken , $refreshTokenTtl);

        return [$accessToken , $refreshToken];

    }
}
