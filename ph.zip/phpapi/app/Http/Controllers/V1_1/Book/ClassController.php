<?php


namespace App\Http\Controllers\V1_1\Book;


use App\Http\Controllers\Controller;
use App\Http\Service\ClassService;
use Illuminate\Http\Request;

class ClassController extends Controller
{

    /**
     * 获取书单分类
     * @return mixed|null
     */
    public function getBookListClassify()
    {
        $service = new ClassService();
        return $service->GetBookListClassify();
    }


    /**
     * 获取书单分类下的书单
     * @param Request $request
     * @throws \Illuminate\Validation\ValidationException
     */
    public function getBookList(Request $request): array
    {

        $service = new ClassService();
        return $service->getBookList();
    }


    public function GetBookListDetailPage(Request $request): array
    {
        $this->validate($request, [
            'list_id' => 'required|int',
        ]);
        $service = new ClassService;
        return $service->getBookListDetailPage($request->get('list_id'), $request->get('page_index', 1), $request->get('page_size', 10));

    }

    /**
     * 获取书籍分类
     * @param Request $request
     * @return array
     */
    public function GetBookClass(Request $request): array
    {
        $classId = $request->get('class_id') ?? 0;
        $service = new ClassService();
        return $service->getClassify($classId, $request->get('type', 0));
    }

}
