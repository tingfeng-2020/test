<?php


namespace App\Http\Controllers\V1_1\Book;


use App\Http\Controllers\Controller;
use App\Http\Service\RankService;
use Illuminate\Http\Request;

class RankController extends Controller
{

    /**
     *
     * 获取排行本分类下的数据
     * @param Request $request
     * @return array
     * @throws \Illuminate\Validation\ValidationException
     */

    public function getRankingByClassId(Request $request)
    {

        $this->validate($request, [
            'class_id' => 'required|int',
        ]);
        $service = new RankService();
        return $service->getRankingByClassId($request->get('class_id'));

    }


    public function getRankingBooks(Request $request)
    {
        $this->validate($request, [
            'ranking_id' => 'required|int',
            'page_index' => 'required|int',
            'page_size' => 'required|int|max:20',
        ]);
        $service = new RankService();
        return $service->getRankingBooks($request->get('ranking_id'), $request->get('page_index'), $request->get('page_size'));

    }


    /**
     * 1.1版本已弃用
     * @return array
     */

    public function getRankingClassify(): array
    {
        $service = new RankService();
        return $service->getRanking();

    }

}
