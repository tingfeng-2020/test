<?php


namespace App\Http\Controllers\V1_1\Book;


use App\Http\Controllers\Controller;
use App\Http\Service\BookService;
use App\Http\Service\LogService;
use App\Task\LogTask;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class BookController extends Controller
{

    /**
     * 获取书籍详情
     * @param Request $request
     * @return array|string
     * @throws ValidationException
     */
    public function getBookById(Request $request)
    {
        $this->validate($request, [
            'book_id' => 'required|int',
        ]);
        //浏览记录
        $request->offsetSet('addOption', 'lookLog');

//        $produce = Kafka::getProducer()->newTopic('login');
//        $produce->produce(RD_KAFKA_PARTITION_UA, 0, json_encode($request->all(), JSON_THROW_ON_ERROR, 512));
//
//        $consumer = Kafka::getConsumer()->newTopic('login');
//
//        $consumer->consumeStart(0, RD_KAFKA_OFFSET_BEGINNING);
//        $consumer->consume(0,1000);
//        dd($consumer);


        $task = new LogTask($request->all());
        Task::deliver($task);

        $service = new BookService();
        return $service->getBookById($request->get('book_id'));

    }

    /**
     * 搜索书籍
     * @param Request $request
     * @return mixed
     * @throws ValidationException
     */
    public function search(Request $request)
    {
        $this->validate($request, [
            'search' => 'required',
            'pageindex' => 'required|integer',
            'pagesize' => 'required|integer|max:20',
        ]);
        //搜索记录
        if ($request->get('pageindex') == 1) {
            $request->offsetSet('addOption', 'searchLog');
            $task = new LogTask($request->all());
            Task::deliver($task);
        }
        $service = new BookService();
        return $service->search($request->get('search'), $request->get('pageindex'), $request->get('pagesize'));
    }


    /**
     *
     * 获取分类下的书籍
     * @param Request $request
     * @return array
     * @throws ValidationException
     */
    public function getBookByClass(Request $request): array
    {
        $this->validate($request, [
            'class_id' => 'required|integer',
            'page_index' => 'integer|filled',
            'page_size' => 'integer|filled|max:20',
        ]);
        $service = new BookService();
        return $service->getBookByClass($request->get('class_id'), $request->get('page_index', 1), $request->get('page_size', 10));

    }


    /**
     *（1.1版本挪到 BookOverController ）
     * 获取完本书籍
     * @param Request $request
     * @param Request $request
     * @return array
     * @return array
     * @throws ValidationException
     *
     * public function getBookByOver(Request $request)
     * {
     * $this->validate($request, [
     * 'PageIndex' => 'required|int',
     * 'PageSize' => 'required|int',
     * ]);
     *
     * $service = new BookService();
     * return $service->getBookByOver( $request->get('PageIndex'), $request->get('PageSize'));
     *
     * }
     * /
     *
     *
     * /**
     *
     * 书籍分享
     * @throws ValidationException
     */

    public function share(Request $request): array
    {
        $this->validate($request, [
            'book_id' => 'required|int',
        ]);

        $service = new BookService();
        return $service->share($request->get('book_id'));

    }


    /**
     * 热门书籍
     * @param Request $request
     * @return array
     */
    public function hotBook(Request $request): array
    {
        $book_count = $request->get('page_size', 10);
        $service = new BookService();
        return $service->hotBook($book_count);
    }


    /**
     * 本书友还在读
     * @param Request $request
     * @return array
     * @throws ValidationException
     */
    public function getBookBySimilar(Request $request): array
    {
        $this->validate($request, [
            'book_id' => 'required|int',
            'page_index' => 'integer',
            'page_size' => 'integer|max:20',
        ]);
        $service = new LogService();
        return $service->getReadPercentList($request->all());
    }


    /**
     * 根据标签获取书籍
     * @param Request $request
     * @return array
     * @throws ValidationException
     */
    public function getBookByTag(Request $request): array
    {
        $this->validate($request, [
            'tag' => 'required|int',
            'page_index' => 'integer',
            'page_size' => 'integer|max:20',
        ]);
        $service = new BookService();
        return $service->getBookByTag($request->get('tag'), $request->get('page_index'), $request->get('page_size'));

    }


    /**
     * 获取相同分类书籍
     * @param Request $request
     * @return array
     * @throws ValidationException
     */
    public function getBookSimilar(Request $request): array
    {
        $this->validate($request, [
            'class_id' => 'required|integer',
        ]);

        $service = new BookService();

        return $service->getBookSimilar($request->get('class_id'));
    }





}
