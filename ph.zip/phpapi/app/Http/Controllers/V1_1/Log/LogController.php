<?php

namespace App\Http\Controllers\V1_1\Log;


use App\Http\Controllers\Controller;
use App\Http\Service\LogService;
use App\Task\LogTask;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;


class LogController extends Controller
{
    protected $service;
    public function __construct(LogService $logService)
    {
        $this->service = $logService;
    }
    /**
     * 打开或者关闭app log
     * @param $request
     * @throws ValidationException
     */
    public function openOrCloseApp(Request $request)
    {
        $this->validate($request,
            [
                'status'=>'required|integer',
            ]
        );
         $request->offsetSet('addOption','openOrCloseApp');
         $task = new LogTask($request->all());
         Task::deliver($task);
         return;

    }

    /**
     * app留存数据上报（一天一次）
     */
    public function keepApp(Request $request)
    {
        $request->offsetSet('addOption','keepApp');
        $request->offsetSet('ip',ip2long($request->ip()));
        $task = new LogTask($request->all());
        Task::deliver($task);
        return;

    }

    /**
     * 阅读数据上报
     * @param Request $request
     * @throws ValidationException
     */

    public function readTime(Request $request)
    {
        $this->validate($request,
            [
                'start_time'=>'required|integer',
                'end_time'=>'required|integer',
                'light'=>'required',
                'font'=>'required',
                'font_size'=>'required',
                'flip_style'=>'required',
                'background'=>'required',
                'book_id'=>'required',
            ]
        );
        $request->offsetSet('addOption','readTime');
        $task = new LogTask($request->all());
        Task::deliver($task);
        return;

    }

    /**
     * 听书数据
     * @param Request $request
     * @throws ValidationException
     */
    public function listenTime(Request $request)
    {
        $this->validate($request,
            [
                'start_time'=>'required|integer',
                'end_time'=>'required|integer',
                'book_id'=>'required|integer',
            ]
        );
        $request->offsetSet('addOption','listenTime');
        $task = new LogTask($request->all());
        Task::deliver($task);
        return;


    }

    /**
     * 点击广告
     * @param Request $request
     * @throws ValidationException
     */
    public function advertClick(Request $request)
    {
        $this->validate($request,
            [
                'ad_id'=>'required|array',
            ]
        );
        $request->offsetSet('addOption','advertClick');
        $task = new LogTask($request->all());
        Task::deliver($task);
        return;

    }

    /**
     * 广告曝光
     * @param Request $request
     * @throws ValidationException
     */
    public function advertExpo(Request $request)
    {
        $this->validate($request,
            [
                'ad_id'=>'required|array',
            ]
        );
        $request->offsetSet('addOption','advertExpo');
        $task = new LogTask($request->all());
        Task::deliver($task);
        return;

    }
    public function dealShelfData()
    {
      return $this->service->dealShelfData();
    }





}
