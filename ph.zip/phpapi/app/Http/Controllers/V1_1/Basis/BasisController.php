<?php

namespace App\Http\Controllers\V1_1\Basis;

use App\Http\Controllers\Controller;
use App\Http\Service\BasicsService;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class BasisController extends Controller
{
    protected $service;

    public function __construct(BasicsService $basicsService)
    {
        $this->service = $basicsService;
    }

    /**
     * 获取热门词
     */
   public function getWordSearch(Request $request)
   {
     return  $this->service->getWordSearch($request->get('top',10));
   }
   /**
    * 获取用户协议& 隐私政策 (H5使用)
    */
   public function getProtocol(Request $request)
   {
       $this->validate($request,
           [
               'type'=>'required|integer'
           ]
       );
       return  $this->service->getProtocol($request->get('type'));
   }
   /**
    *获取用户协议& 隐私政策 (APP端使用）
    */
   public function getPageLink()
   {
       return $this->service->getPageLink();
   }
    /**
     * APP版本更新
     * @param Request $request
     * @param integer type
     * @return array
     * @throws ValidationException
     */
   public function getAppVersion(Request $request)
   {
       $this->validate($request,
           [
               'type'=>'required|integer'
           ]
       );
       return $this->service->getAppVersion($request->get('type'));
   }

    /**
     * 板块分类数据
     */
   public function getPlates()
   {
     return $this->service->getPlates();
   }
   /**
    * 板块广告
    * @param integer $platesId
    * @return array
    * @throws ValidationException
    */
   public function getPlateBanners(Request $request)
   {
       $this->validate($request,
           [
               'platesId'=>'required|integer'
           ]
       );
       return $this->service->getPlateBanners($request->get('platesId'));
   }

    /**
     * 板块模块数据
     */
   public function getPlateDataItem(Request $request)
   {
       $this->validate($request,
           [
               'platesId'=>'required|integer',
           ]
       );
       return $this->service->getPlateDataItem($request->all());
   }
    /**
     * 板块更多数据
     * @param integer plateid
     * @param integer pageIndex
     * @param integer pageSize
     * @return array
     * @throws ValidationException
     */
    public function getPanelMoreData(Request $request)
    {
        $this->validate($request,
            [
                'plateid'=>'required|integer',
                'page_index'=>'integer',
                'page_size'=>'integer|max:20'
            ]
        );
        return $this->service->getPanelMoreData($request->all());
    }

    /**
     * 获取分类数据（H5,APP）使用
     */
   public function getClassifyTree()
   {
      return $this->service->getClassifyTree();
   }

    /**
     * 获取广告
     * @param integer type
     * @return array
     * @throws ValidationException
     */
   public function getBanners(Request $request)
   {
       $this->validate($request,
           [
               'slot_id'=>'required'
           ]
       );
      return $this->service->getBanners($request->all());
   }

    /**
     * 广告位获取
     * @param Request $request
     * @return array|bool|mixed|string
     * @throws ValidationException
     */
   public function getAdSlot(Request $request)
   {
       $this->validate($request,
           [
               'module'=>'integer'
           ]
       );
       return $this->service->getAdSlot($request->all());
   }

    /**
     * 字体包获取
     * @return array
     */
   public function getFontPackage()
   {
     return $this->service->getFontPackage();
   }


}

