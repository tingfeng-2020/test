<?php

namespace App\Http\Controllers\V1_1\Bbs;

use App\Http\Controllers\Controller;
use App\Http\Service\BbsService;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class BbsController extends Controller
{
    protected $service;

    public function __construct(BbsService $bbsService)
    {
        $this->service = $bbsService;
    }

    /**
     * 获取评论列表
     * @param Request $request
     * @return array|void
     * @throws ValidationException
     */
    public function topicList(Request $request)
    {
        $this->validate($request,[
            'book_id'=>'required|integer',
            'page_index'=>'integer',
            'page_size'=>'integer|max:20',
        ]);
        return $this->service->topicList($request->all());
    }

    /**
     * 获取评论详情
     * @param Request $request
     * @return mixed
     * @throws ValidationException
     */
    public function replyInfo(Request $request)
    {
        $this->validate($request,[
            'tid'=>'required|integer',
            'page_index'=>'integer',
            'page_size'=>'integer|max:20',
        ]);
       return $this->service->replyInfo($request->all());
    }

    /**
     * 评论提交保存
     * @param Request $request
     * @throws ValidationException
     */
    public function send(Request $request)
    {
        $this->validate($request,[
            'book_id'=>'required|integer',
            'message'=>'required|max:250',
            //'score'=>'required',
            'title'=>'max:40',
        ]);
        return $this->service->send($request->all());
    }

    /**
     * 回复评论保存
     * @param Request $request
     * @return mixed
     * @throws ValidationException
     */
    public function reply(Request $request)
    {
        $this->validate($request,[
        'tid'=>'required|integer',
        'rid'=>'required|integer',
        'message'=>'required|max:250',
        'title'=>'max:40',
    ]);
        return $this->service->reply($request->all());
    }

    /**
     * 点赞
     * @param Request $request
     * @throws ValidationException
     */
    public function likes(Request $request)
    {
        $this->validate($request,[
            'id'=>'required|integer',
            'type'=>'required|integer',
        ]);
        return $this->service->likes($request->all());
    }
    public function delete(Request $request)
    {
        $this->validate($request,[
            'id'=>'required|integer',
            'type'=>'required|integer',
        ]);
        return $this->service->delete($request->all());

    }

}

