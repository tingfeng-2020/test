<?php

namespace App\Http\Controllers\V1_1\Mine;

use App\Cache\MemberCache;
use App\Exceptions\ApiExceptions;
use App\Http\Controllers\Controller;
use App\Model\MembersModel;
use App\Model\NotifyMessageModel;
use Illuminate\Http\Request;

/**
 * 用户信息相关
 * Class InfoController
 * @package App\Http\Controllers\V1_1\Mine
 */
class InfoController extends Controller
{
    /**
     * 获取用户信息
     * @param Request $request
     * @return mixed
     */
    public function index(Request $request)
    {
        $member = MemberCache::getInstance($request->uid);
        if (!$member) throw new ApiExceptions(1007,'',['用户不存在!']);
        return [
            'account' => hidePhone($member->account),
            'nickName' => $member->nickname ? : $member->account,
            'gender' =>  $member->gender ? : 0,
            'icon' => $member->icon ? env('MEDIA_HOST').$member->icon : env('MEDIA_HOST').env('DEFAULT_HEADER')
        ];
    }

    /**
     * 修改用户名称
     * @param Request $request
     * @return mixed
     * @throws \Exception
     */
    public function name(Request $request)
    {
        $this->validate($request , [
            'nickName' => 'required|max:150'
        ]);

        $member = MembersModel::where('id',$request->uid)->first();
        if (!$member) throw new ApiExceptions(1007,'','用户不存在');
        $nickname = htmlspecialchars($request->nickName);
        $member->nickname = $nickname;
        if($member->save())
        {
            MemberCache::getInstance($request->uid)->field('nickname');
            MemberCache::getInstance($request->uid)->updateFieldCache('nickname' , $nickname);
        }

        return;
    }

    /**
     * 修改用户头像
     * @param Request $request
     * @return mixed
     * @throws \Exception
     */
    public function face(Request $request)
    {
        $this->validate($request , [
            'headImgurl' => 'required|max:225'
        ]);
        $headImgurl = getFilePath($request->headImgurl);
        $member = MembersModel::where('id',$request->uid)->first();
        if (!$member) throw new ApiExceptions(1007,'','用户不存在');
        $member->icon = $headImgurl;
        if($member->save())
        {
            NotifyMessageModel::query()->where(['send_memberId'=>$request->uid])->update(['headImgUrl'=>$headImgurl]);
            MemberCache::getInstance($request->uid)->updateFieldCache('icon' , $headImgurl);
        }

        return;
    }

    /**
     * 修改用户性别
     * @param Request $request
     * @return mixed
     * @throws \Exception
     */
    public function sex(Request $request)
    {
        $this->validate($request , [
            'gender' => 'required|in:0,1,2'
        ]);

        $member = MembersModel::where('id',$request->uid)->first();
        if (!$member) throw new ApiExceptions(1007,'','用户不存在');
        $member->gender = $request->gender;
        if($member->save())
        {
            MemberCache::getInstance($request->uid)->updateFieldCache('gender' , $request->gender);
        }

        return;
    }
}
