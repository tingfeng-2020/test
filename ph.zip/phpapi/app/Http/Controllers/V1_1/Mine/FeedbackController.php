<?php

namespace App\Http\Controllers\V1_1\Mine;

use App\Http\Controllers\Controller;
use App\Model\FeedbackModel;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/**
 * 意见反馈
 * Class FeedbackController
 * @package App\Http\Controllers\V1_1\Mine
 */
class FeedbackController extends Controller
{
    /**
     * 问题反馈
     * @param Request $request
     * @return mixed
     * @throws ValidationException
     */
    public function index(Request $request)
    {
        $this->validate($request , [
            'text' => 'required|max:512'
        ]);

        $feedback = new FeedbackModel();
        $feedback->member_id = $request->uid;
        $feedback->content = htmlspecialchars($request->text);
        $feedback->createtime = date('Y-m-d H:i:s');

        $feedback->save();

        return;
    }
}
