<?php

namespace App\Cache;

use App\Exceptions\ApiExceptions;
use App\Tools\Redis;
use App\Traits\BaseTrait;
use App\Traits\RedisTrait;

/**
 * 基本缓存详情数据类
 * Class BaseCache
 * @package App\Cache
 */
abstract class BaseCache
{
    use BaseTrait;
    use RedisTrait;

    /**
     * @var string $pk
     */
    protected $pk;
    /**
     * @var string 缓存键名
     */
    protected $detailKey;
    /**
     * @var int 缓存有效时间，单位：秒
     */
    protected $ttl = 86500;
    /**
     * @var mixed 详情数据
     */
    protected $detail = [];

    protected $cacheConfig = [];

    protected $redis = null;

    public function __construct($pk)
    {


        $class = basename(str_replace('\\', '/', static::class));
        $cacheKey = lcfirst(str_replace('Cache', '', $class));
        if (empty($pk) && $class === static::class) {
            throw new ApiExceptions(1105);
        }
        $this->pk = $pk;

        $this->cacheConfig = config('cache_key.' . $cacheKey);
        if (isset($this->cacheConfig['key'])) {
            $keys = is_array($pk) ? implode('-', $this->pk) : $this->pk;
            $this->detailKey = $this->cacheConfig['key'] . '_' . $keys;
            $this->ttl = $this->cacheConfig['ttl'];
        } else {
            $this->setDetailKey();
        }
        $this->redis = Redis::getInstance();
        $this->setKey();

    }

    /**
     * 设置key值
     */
    protected function setKey(): void
    {

    }


    /**
     * 从数据库中查询数据
     * @return mixed
     */
    abstract protected function fromDb();


    /**
     * 获取数据详情。
     * 优先从缓存获取，不存在则从数据库中获取再存入缓存中
     */
    public function getDetail()
    {
        // if ($this->detail) return $this->detail;


        $this->getCache();
        if ($this->detail === null) {
            return [];
        }

        if (empty($this->detail)) {
            $this->buildCache();
        }

        $this->dealDetailExt($this->detail);

        return $this->detail;
    }

    /**
     * 从缓存中获取数据
     */
    protected function getCache()
    {
        $this->detail = $this->redis->hGetAll($this->detailKey);
    }

    /**
     * 获取某字段的缓存值
     * @param $field
     * @return mixed|null
     */
    public function field($field)
    {
        $this->getDetail();

        return $this->detail[$field] ?? null;
    }

    public function __get($name)
    {
        // TODO: Implement __get() method.
        return $this->field($name);
    }

    public function __set($name, $value)
    {
        // TODO: Implement __set() method.
        return $this->updateFieldCache($name, $value);
    }

    /**
     * 数据额外处理
     * @param $detail
     */
    protected function dealDetailExt(&$detail)
    {
    }

    /**
     * 清除缓存及内存中的数据
     */
    public function clearCache(): void
    {
        $this->detail = '';
        $this->redis->del($this->detailKey);
    }

    /**
     * 创建/重构缓存数据
     */
    protected function buildCache()
    {
        $this->clearCache();
        $object = $this->fromDb();
        if (!$object) {
            $this->detail = '';//不存在，则直接置为null
        } else if (is_object($object)) {
            if (get_class($object) === 'stdClass') {
                $this->detail = get_object_vars($object);
            } else {
                $this->detail = json_decode($object, true);
            }
        } else {
            $this->detail = $object;
        }
        $this->dealUpdateCacheExt($this->detail);
        $this->saveCache();
    }

    /**
     * 更新或重构缓存额外处理
     * @param mixed $data
     */
    protected function dealUpdateCacheExt($data)
    {

    }


    /**
     * 保存数据到缓存中
     */
    protected function saveCache()
    {
        if ($this->detail) {
            $this->redis->hMSet($this->detailKey, $this->detail);
            $this->ttl();
        }

    }

    /**
     * 更新缓存过期时间
     */
    protected function ttl()
    {
        if ($this->ttl <= 0) {
            return;
        }

        $this->redis->expire($this->detailKey, $this->ttl + mt_rand(1, 120));
    }

    /**
     * 字段增长（整型增长）
     * @param string $field 字段
     * @param int $incr
     * @return bool|mixed
     */
    public function incr($field, $incr = 1)
    {
        $this->getDetail();

        if (!isset($this->detail[$field])) return false;
        $this->detail[$field] = $this->redis->hIncrBy($this->detailKey, $field, $incr);

        $this->dealUpdateCacheExt([$field => $this->detail[$field]]);

        $this->ttl();

        return $this->detail[$field];
    }

    /**
     * 字段增长（浮点数增长）
     * @param string $field 字段
     * @param float $incr
     * @return bool|mixed
     */
    public function incrByFloat($field, $incr = 1.0)
    {
        $this->getDetail();

        if (!isset($this->detail[$field])) return false;
        $this->detail[$field] = $this->redis->hIncrByFloat($this->detailKey, $field, $incr);

        $this->dealUpdateCacheExt([$field => $this->detail[$field]]);

        $this->ttl();

        return $this->detail[$field];
    }

    /**
     * 更新某个字段的缓存
     * @param string $field
     * @param $value
     * @return bool
     */
    public function updateFieldCache($field, $value)
    {
        $this->getDetail();

        //    if (!isset($this->detail[$field])) return false;


        $this->redis->hSet($this->detailKey, $field, $value);

        //   $this->dealUpdateCacheExt([$field => $this->detail[$field]]);

        $this->ttl();

        $this->detail[$field] = $value;

        return true;
    }

    /**
     * 更新多个字段的缓存
     * @param array $data
     * @return bool
     */
    public function updateMulFieldCache(array $data)
    {
        $this->getDetail();
        if (empty($this->detail) || $this->detail === 'null')
            return false;

        foreach ($data as $field => $value) {
            if (!$this->detail[$field])
                unset($data[$field]);
        }

        if (empty($data)) return false;

        $this->detail = array_merge($this->detail, $data);

        $this->dealUpdateCacheExt($data);

        $this->saveCache();

        return true;
    }

    /**
     * 直接设置缓存详情并保存
     * @param mixed $detail
     */
    public function setDetail($detail): void
    {
        if (is_object($detail)) {
            if (get_class($detail) === 'stdClass') {
                $detail = get_object_vars($detail);

            } else {
                $detail = json_decode($detail, true);

            }
        }
        $this->detail = $detail;
        $this->dealUpdateCacheExt($this->detail);
        $this->saveCache();
    }

    /**
     * 判断缓存是否存在
     * @return bool
     */
    public function empty()
    {
        $detail = $this->getDetail();

        return !$detail;
    }

    /**
     * 清除所有相关缓存
     */
    public static function clearAll()
    {
    }

    /**
     * 重构所有相关缓存
     */
    public static function reset()
    {
    }


}
