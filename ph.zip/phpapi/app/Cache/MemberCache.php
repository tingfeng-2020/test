<?php

namespace App\Cache;

use App\Model\MembersModel;
use App\Tools\Redis;
use Illuminate\Support\Facades\DB;

/**
 * 会员详情缓存类
 * Class MemberCache
 * @package App\Cache
 */
class MemberCache extends BaseCache
{
    /**
     * @var string 用户的书架列表缓存键
     */
    private $readUid;

    protected function setDetailKey()
    {
        // TODO: Implement setDetailKey() method.
        $this->detailKey = config('cache_key.user.UID').'.'.$this->pk;
        $this->readUid = config('cache_key.user.READ_MSG_UID').'.'.$this->pk;

    }

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        // TODO: Implement fromDb() method.
        return MembersModel::where('id' , $this->pk)->first(['id','account','nickname','gender','icon','bbs_status']);
    }


    /**
     * 加入已读系统信息（普推类型、msg_type=4\5\6）
     * @param $uid
     * @return bool
     */
    public function addReaduid($uid)
    {
        return Redis::getInstance()->sAdd($this->readUid,$uid);
    }

    /**
     * 获取用户已读系统信息状态（普推类型、msg_type=4\5\6）
     * @return bool|mixed|string
     */
    public function getReadUid($uid)
    {
        return Redis::getInstance()->SISMEMBER($this->readUid,$uid);
    }

    /**
     * 清除会员详情相关缓存
     */
    public static function clearAll()
    {
        $keyPrefix = config('cache_key.user.UID').'.';

        $redis = Redis::getInstance();

        $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $iterator = null;
        $count = 1000; // 测试时redis中大概有20w个key，用时约2s，当count为500时用时约4s，count越大时扫描用时越短（当然需要根据你的业务需要来定）

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }

        $keyPrefix = config('cache_key.user.BOOK_SHELF').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
    }

    public static function reset()
    {
        self::clearAll();
        MobileCache::clearAll();

        $list = MembersModel::all();
        if(empty($list))  return;

        foreach ($list as $member)
        {
            $cacheObj = new self($member->id);
            $cacheObj->setDetail($member);

            $mobileObj = new MobileCache($member->account);
            $mobileObj->setDetail($member->id);

        }
    }
}
