<?php


namespace App\Cache;


use App\Http\Service\ClassService;
use App\Model\BookClassModel;
use App\Task\Cache\SetBookByClassCacheTask;
use Hhxsv5\LaravelS\Swoole\Task\Task;

/**
 * 分类中所属书籍缓存
 * Class BookInClassCache
 * @package App\Cache
 */
class BookByClassCache extends BaseCache
{
    private const MAX_CONT = 'max_count';


    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        [$classId, $page, $pageSize] = $this->pk;
        $start = ($page - 1) * $pageSize;
        $service = new ClassService();
        $data = $service->getClassify($classId);
        $model = BookClassModel::query()->join('book', 'book_id', '=', 'book.id')->where('book.status', 1)->orderByDesc('book.on_read');
        //如果下面没有子级分类则读取当前分类id
        if (empty($data)) {
            $model->where(['classify_id' => $classId]);
        } else {
            $model->whereIn('classify_id', array_column($data, 'id'));
        }
        $count = $model->count('book_id');
        $result = $model->offset($start)->limit($pageSize)->distinct()->get(['book_id', 'on_read'])->toArray();
        if ($result) {
            $result = array_column($result, 'book_id');
            $result[$count] = self::MAX_CONT;
        }
        return $result;

    }


    /**
     * 设置key值
     */
    protected function setKey(): void
    {

        $this->detailKey = $this->cacheConfig['key'] . $this->pk[0];
    }

    protected function saveCache(): void
    {

        [, $page, $pageSize] = $this->pk;
        if ($this->detail) {
            $start = ($page - 1) * $pageSize;
            //将最大
            $max = array_search(self::MAX_CONT, $this->detail, true);

            unset($this->detail[$max]);
            foreach ($this->detail as $k => $v) {
                $this->redis->zAdd($this->detailKey, $start, $v);
                $start++;
            }
            $this->redis->zAdd($this->detailKey, $max, self::MAX_CONT);

        }


        $this->ttl();

    }


    protected function getCache(): void
    {
        [, $page, $pageSize] = $this->pk;
        $start = ($page - 1) * $pageSize;
        $end = $start + $pageSize - 1;

        //取出总数
        $count = $this->redis->zScore($this->detailKey, self::MAX_CONT);
        //如果当前页数大于缓存中 最大数 就不查数据库
        if ($count) {
            if ($count && $page > ceil($count / $pageSize)) {
                $this->detail = null;
            } else {
                $result = $this->redis->zRangeByScore($this->detailKey, $start, $end);
                $start = $start < 1 ? 1 : $start;
                if (count($result) >= $pageSize || $start == ceil($count / $pageSize)) {
                    $this->detail = $result;
                }
            }
        }


    }

    public function clearCache(): void
    {

    }


}
