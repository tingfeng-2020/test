<?php


namespace App\Cache;


use App\Model\BookModel;
use App\Tools\Redis;

class SearchCache extends BaseCache
{


    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        $obj =  BookModel::query()->where('book_name', 'like', "%$this->pk%")->where('status','1')->orWhere('author', 'like', "%$this->pk%");
        return $obj ? $obj->pluck('id')->toArray() : '';

    }


    protected function saveCache()
    {

        Redis::getInstance()->set($this->detailKey, json_encode($this->detail));
        $this->ttl();
    }


}
