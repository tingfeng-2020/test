<?php


namespace App\Cache;


use App\Tools\Redis;

/**
 * Class TokenCache
 * @package App\Cache
 */
class TokenCache
{
    /**
     * 保存access_token
     * @param string $accessToken
     * @param $uid
     * @param $ttl
     */
    public static function setAccessToken($accessToken , $uid , $ttl)
    {
        if(empty($accessToken)) return;
        //echo self::getAccessTokenKey($accessToken);exit;
        Redis::getInstance()->setex(self::getAccessTokenKey($accessToken) , $ttl , $uid);
    }

    /**
     * 获取access_token缓存键
     * @param $accessToken
     * @return string
     */
    private static function getAccessTokenKey($accessToken)
    {
        return config('cache_key.token.ACCESS_TOKEN').'.'.$accessToken;
    }

    /**
     * 获取access_token
     * @param $accessToken
     * @return bool|mixed|string
     */
    public static function getAccessToken($accessToken)
    {
        if(empty($accessToken)) return false;
        return Redis::getInstance()->get(self::getAccessTokenKey($accessToken));
    }

    /**
     * 删除access_token
     * @param $accessToken
     * @return int
     */
    public static function delAccessToken($accessToken)
    {
        if(empty($accessToken)) return false;
        return Redis::getInstance()->del(self::getAccessTokenKey($accessToken));
    }

    /**
     * 保存refresh_token
     * @param string $refreshToken
     * @param $uid
     * @param $ttl
     */
    public static function setRefreshToken($refreshToken , $uid , $ttl)
    {
        if(empty($refreshToken)) return;
        Redis::getInstance()->setex(self::getRefreshTokenKey($refreshToken) , $ttl , $uid);
    }

    /**
     * 获取refresh_token缓存键
     * @param $refreshToken
     * @return string
     */
    private static function getRefreshTokenKey($refreshToken)
    {
        return config('cache_key.token.REFRESH_TOKEN').'.'.$refreshToken;
    }

    /**
     * 获取refresh_token
     * @param $refreshToken
     * @return bool|mixed|string
     */
    public static function getRefreshToken($refreshToken)
    {
        if(empty($refreshToken)) return false;
        return Redis::getInstance()->get(self::getRefreshTokenKey($refreshToken));
    }

    /**
     * 删除refresh_token
     * @param $refreshToken
     * @return int
     */
    public static function delRefreshToken($refreshToken)
    {
        if(empty($refreshToken)) return false;
        return Redis::getInstance()->del(self::getRefreshTokenKey($refreshToken));
    }

    /**
     * 获取会员登录存储的token信息
     * @param $uid
     * @return string
     */
    private static function getUserTokenKey($uid)
    {
        return config('cache_key.token.UID').'.'.$uid;
    }

    /**
     * 获取会员存储的token信息
     * @param $uid
     * @return array
     */
    public static function getUserToken($uid)
    {
        if(empty($uid)) return  null;
        return Redis::getInstance()->hGetAll(self::getUserTokenKey($uid));
    }

    /**
     * 清除用户的登录token信息
     * @param $uid
     */
    public static function delUserToken($uid)
    {
        if(empty($uid)) return;
        $tokenInfo = self::getUserToken($uid);
        if($tokenInfo)
        {
            //清理之前的token信息
            self::delAccessToken($tokenInfo['access_token']);
            self::delRefreshToken($tokenInfo['refresh_token']);
        }

        Redis::getInstance()->del(self::getUserTokenKey($uid));
    }

    /**
     * 保存token信息
     * @param $uid
     * @param $accessToken
     * @param $accessTokenTtl
     * @param $refreshToken
     * @param $refreshTokenTtl
     * @return bool
     */
    public static function setUserToken($uid , $accessToken , $accessTokenTtl , $refreshToken , $refreshTokenTtl)
    {
        if(empty($uid) || empty($accessToken) || empty($refreshToken)) return false;

        //self::delUserToken($uid);//清理之前的信息

        self::setAccessToken($accessToken , $uid , $accessTokenTtl);

        self::setRefreshToken($refreshToken , $uid , $refreshTokenTtl);

        //重新保存信息
        Redis::getInstance()->hMSet(self::getUserTokenKey($uid) , [
            'access_token' => $accessToken ,
            'refresh_token' => $refreshToken ,
        ]);
    }
}
