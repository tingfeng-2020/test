<?php

namespace App\Cache;

use App\Model\MembersModel;
use App\Tools\Redis;

/**
 * 手机号关联会员ID
 * Class MobileCache
 * @package App\Cache
 */
class MobileCache extends BaseCache
{
    protected $ttl = 0;//永久

    protected function setDetailKey()
    {
        $this->detailKey = config('cache_key.user.PHONE');
    }

    protected function getCache()
    {
        $this->detail = Redis::getInstance()->hGet($this->detailKey , $this->pk);
    }

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        return MembersModel::where('account' , $this->pk)->value('id');
    }

    protected function saveCache()
    {
        Redis::getInstance()->hSet($this->detailKey , $this->pk , $this->detail);
        $this->ttl();
    }

    public static function clearAll()
    {
        Redis::getInstance()->del(config('user.PHONE'));
    }

    public static function reset()
    {
        self::clearAll();

        $list = MembersModel::all(['id','account']);
        if(empty($list))  return;

        foreach ($list as $member)
        {
            $cacheObj = new self($member->id);
            $cacheObj->setDetail($member->account);
        }
    }
}
