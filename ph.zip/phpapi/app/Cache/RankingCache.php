<?php

namespace App\Cache;


use App\Model\RankingModel;

/**
 * 排行榜
 * Class BookCache
 * @package App\Cache
 */
class RankingCache extends BaseCache
{


    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        $where['status'] = 1;

        $re = RankingModel::query()->where(['status' => 1, 'classify_id' => $this->pk])->orderBy('sort', 'asc');
        return $re ? $re->get(['id', 'alias', 'name'])->toArray() : '';
    }

    protected function dealUpdateCacheExt($data)
    {
        if($data !== 'null' and !empty($data)){
            $this->detail = [];
            foreach ($data as $k => $v) {
                $this->detail[] = json_encode($v);
            }
        }

    }


}
