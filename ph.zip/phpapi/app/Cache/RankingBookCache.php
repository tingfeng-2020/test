<?php

namespace App\Cache;


use App\Model\RankingBookModel;

/**
 * 排行榜下的书籍
 * Class BookCache
 * @package App\Cache
 */
class RankingBookCache extends BaseCache
{


    private const MAX_CONT = 'max_count';

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        [$rank, $page, $pageSize] = $this->pk;
        $start = ($page - 1) * $pageSize;
        $model = RankingBookModel::query()->where('ranking_id', $rank);
        $count = $model->count('id');
        $result = [];
        if ($count) {
            $result = RankingBookModel::query()->where('ranking_id', $rank)->orderBy('sort')->offset($start)->limit($pageSize)->pluck('book_id')->toArray();
            //取出最大值做分页
            $result[$count] = self::MAX_CONT;
        }
        return $result;
    }


    /**
     * 设置key值
     */
    protected function setKey(): void
    {
        $this->detailKey = $this->cacheConfig['key'] . $this->pk[0];
    }

    protected function saveCache()
    {
        [, $page, $pageSize] = $this->pk;
        if ($this->detail) {
            $start = ($page - 1) * $pageSize;
            //将最大
            $max = array_search(self::MAX_CONT, $this->detail, true);

            unset($this->detail[$max]);

            foreach ($this->detail as $k => $v) {
                $this->redis->zAdd($this->detailKey, $start, $v);
                $start++;
            }
            $this->redis->zAdd($this->detailKey, $max, self::MAX_CONT);


        }


        $this->ttl();
    }


    protected function getCache()
    {
        [, $page, $pageSize] = $this->pk;
        $start = ($page - 1) * $pageSize;
        $end = $start + $pageSize - 1;

        //取出总数
        $count = $this->redis->zScore($this->detailKey, self::MAX_CONT);
        //如果当前页数大于缓存中 最大数 就不查数据库

        if ($count && $page > ceil($count / $pageSize)) {
            $this->detail = null;
        } else {
            $result = $this->redis->zRangeByScore($this->detailKey, $start, $end);
            $start = $start < 1 ? 1 : $start;
            if (count($result) >= $pageSize || $start == ceil($count / $pageSize)) {
                $this->detail = $result;
            }
        }
    }

    public function clearCache(): void
    {

    }


}
