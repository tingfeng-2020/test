<?php


namespace App\Cache;


use App\Model\TagModel;
use App\Tools\Redis;

/**
 * 书籍标签
 * Class BookInClassCache
 * @package App\Cache
 */
class BookTagCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        return TagModel::query()->join('book_tag', 'tag.id', 'book_tag.tag')->where('book_tag.book_id', $this->pk)->get(['name', 'tag.id'])->toArray();


    }


    protected function saveCache()
    {
        if ($this->detail){
            Redis::getInstance()->set($this->detailKey, json_encode($this->detail));
            $this->ttl();
        }

    }
    protected function getCache()
    {

        $this->detail = json_decode($this->redis->get($this->detailKey),true);
        $this->detail = empty($this->detail) ? []:$this->detail;

    }

    /**
     * 清除评论相关缓存
     */
    public static function clearAll()
    {
        $keyPrefix = config('cache_key.bookTag')['key'];

        $redis = Redis::getInstance();

        $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $iterator = null;
        $count = 1000;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }



    }



}
