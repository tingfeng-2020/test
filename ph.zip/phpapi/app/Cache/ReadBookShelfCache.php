<?php

namespace App\Cache;

use App\Model\Bbs\BbsTopicModel;
use App\Tools\Redis;
use Illuminate\Support\Facades\Log;

/**
 * 每本书的读友书架已读书籍百分比缓存
 * Class BookCache
 * @package App\Cache
 */
class ReadBookShelfCache extends BaseCache
{
    /**
     * @var string 缓存键
     */
    private $readBookKey;


    protected function setDetailKey()
    {
        $this->readBookKey = config('cache_key.log.BOOK_READ_PERCENT').'.'.$this->pk;

    }

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {

    }
    /**
     * 添加书的其他书已被读的书籍百分比等信息记录
     * @param array $bookInfo  书籍信息
     * @param float $percent 书友已读百分比
     * @return bool|int
     */
    public function addBookPercent($k , $info)
    {
        if (empty($info)) return;

        return Redis::getInstance()->zAdd($this->readBookKey,$k , $info);
    }
    /**
     * 获取列表，按照百分比 正序
     * @return array
     */
    public function getReadPercentList($startRow=0, $row = 20)
    {
        return self::getSortedListKey($this->readBookKey , $startRow , $row,0,0,false,1);
    }
    /**
     * 移除
     * @param int $id 标识ID
     * @return bool|int
     */
    public function rem($id)
    {
        if(empty($id)) return false;
        return Redis::getInstance()->zRem($this->readBookKey , $id);
    }

    /**
     * 获取数量
     * @return int
     */
    public function getCount()
    {
        return self::getSortedListLen($this->readBookKey);
    }




    /**
     * 清除评论相关缓存
     */
    public static function clearAll()
    {
        $keyPrefix = config('cache_key.log.BOOK_READ_PERCENT').'.';

        $redis = Redis::getInstance();

        $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $iterator = null;
        $count = 1000;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }

        $keyPrefix = config('cache_key.log.BOOK_ID_READ_PERCENT');
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
    }



}
