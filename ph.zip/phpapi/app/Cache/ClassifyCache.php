<?php


namespace App\Cache;


use App\Model\ClassifyModel;

/**
 *
 * 书籍分类缓存
 * Class ClassifyCache
 * @package App\Cache
 */
class ClassifyCache extends BaseCache
{



    /**
     * @inheritDoc
     */
    protected function fromDb()
    {

        return ClassifyModel::query()->where(['status' => 1])->get(['id', 'name', 'related_name', 'icon'])->keyBy('id');
    }

    protected function dealUpdateCacheExt($data): void
    {

        $arr = [];
        foreach ($data as $k => $v) {
            $arr[$k] = json_encode($v);
        }

        $this->detail = $arr;

    }






}
