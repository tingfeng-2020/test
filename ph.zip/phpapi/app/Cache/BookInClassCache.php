<?php


namespace App\Cache;


use App\Model\BookClassModel;

/**
 * 书籍所属分类缓存
 * Class BookInClassCache
 * @package App\Cache
 */
class BookInClassCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        return BookClassModel::query()->where(['book_id' => $this->pk])->pluck('classify_id')->toArray();

    }





}
