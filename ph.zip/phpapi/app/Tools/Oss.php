<?php
/**
 * Created by PhpStorm.
 * User: xiaop
 * Date: 2020/06/15
 * Time: 下午11:16
 */
namespace App\Tools;

use App\Exceptions\ApiExceptions;
use App\Model\OssEtagModel;
use App\Model\OssModel;
use Illuminate\Support\Facades\Log;
use OSS\Core\OssException;
use OSS\OssClient;

class Oss
{
    /**
     * 上传到云存储
     * @param $path
     * @param $fileName
     * @param $etag
     * @param string $type
     * @return string
     * @throws ApiException
     */
    public function uploadToOss(&$path, $fileName, $etag,$type = 'common')
    {
        $filePath = base_path('public/').$path;
        $model = new OssEtagModel();
        if ($etag) {
            $oss = $model::query()->where([
                'etag' => $etag
            ])->first();
            if ($oss) {
                    @unlink($filePath);
                $path = $oss['path'];
                return config('oss.cdnServer').$oss['path'];
            }
        }
        $bucket = config('oss.bucketName');
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $oss = new OssClient(
            config('oss.accessKeyId'),
            config('oss.accessKeySecret'),
            config('oss.ossServer')
        );
        $disposition = 'attachment;filename="' . rawurlencode($fileName) .'";filename*=utf-8\'\'' . rawurlencode($fileName);
        if ($type != 'mail' && in_array(strtolower($ext), ['jpg', 'jpeg', 'gif', 'png'])) {
            $disposition = 'inline;filename="' . rawurlencode($fileName) .'";filename*=utf-8\'\'' . rawurlencode($fileName);
        }
        $options = [
            OssClient::OSS_HEADERS => [
                'Cache-Control' => 'max-age=365',
                'Content-Disposition' => $disposition,
                'x-oss-server-side-encryption' => 'AES256',
            ],
        ];
        try {
            $response = $oss->uploadFile($bucket, $path, $filePath, $options);
            $url = $response['info']['url']??'';
                     $find =$model::query()->where('etag',trim($response['etag'], '"')??'')->first();
                      if(!$find){
                         $save= [
                              'etag' => trim($response['etag'], '"')??'',
                              'path' => $path,
                              'file_size' => filesize($filePath),
                              'createtime' =>date('Y-m-d H:i:s')
                          ];
                          $model->create($save);
                      }
                         @unlink($filePath);
                         $this->rm_empty_dir('./media/');

            return $url;
        } catch (OssException $e) {
            throw new ApiExceptions(1007, '',[
                '上传到云存储异常:'.$e->getMessage().'error_code:'.$e->getCode(),
            ]);
        }
    }
    /**
     * 删除云上文件
     */
    public function delete($data =[]){
        $bucket = config('oss.bucketName');
        $oss = new OssClient(
            config('oss.accessKeyId'),
            config('oss.accessKeySecret'),
            config('oss.ossServer')
        );
        $res =null;
        if ($data && is_array($data['object'])){
            $res = $oss->deleteObjects($bucket,$data['object']);
        }elseif($data){
            $res = $oss->deleteObject($bucket,$data['object']);
        }
        return $res;

    }
    /** 删除所有空目录
     * @param String $path 目录路径
     */
   public function rm_empty_dir($path){
        if(is_dir($path) && ($handle = opendir($path))!==false){
            while(($file=readdir($handle))!==false){// 遍历文件夹
                if($file!='.' && $file!='..'){
                    $curfile = $path.'/'.$file;// 当前目录
                    if(is_dir($curfile)){// 目录
                        $this->rm_empty_dir($curfile);// 如果是目录则继续遍历
                        if(count(scandir($curfile))==2){//目录为空,=2是因为.和..存在
                            @rmdir($curfile);// 删除空目录
                        }
                    }
                }
            }
            closedir($handle);
        }
    }
}
