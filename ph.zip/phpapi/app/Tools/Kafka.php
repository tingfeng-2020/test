<?php


namespace App\Tools;


use RdKafka\Consumer;
use RdKafka\Producer;

class Kafka
{


    public static function getProducer(): Producer
    {
        $kafka = new Producer();
        $kafka->addBrokers('127.0.0.1:9000');
        return $kafka;
    }


    public static function getConsumer(): Consumer
    {
        $kafka = new Consumer();
        $kafka->addBrokers('127.0.0.1:9000');
        return $kafka;
    }

}
