<?php
namespace App\Tools;
use App\Exceptions\ApiExceptions;
use Elasticsearch\ClientBuilder;
use Elasticsearch\Common\Exceptions\Conflict409Exception;

class EsOption
{
   public function __construct()
   {
       $host = [
           [
               'host' => env('ELASTIC_SEARCH_HOST'),
               'port' => env('ELASTIC_SEARCH_PORT'),
               'scheme' => 'http',
               'user' => env('ELASTIC_SEARCH_USER'),
               'pass' => env('ELASTIC_SEARCH_PASS'),
           ]
       ];
       $this->client = ClientBuilder::create()->setHosts($host)->build();
   }

    /**
     * 添加数据
     * @param $params
     */
    public function create($index='',$data=[])
    {
        if (empty($index) || empty($data)) throw new ApiExceptions(1007,'',['es:not find data or index']);
        try {
            $params = [
                'index' =>$index,
                'type' => 'docs',
                'body' => $data,
            ];
            $res = $this->client->index($params);
            if ($res['result'] != 'created') throw new ApiExceptions(1106);
        }catch (Conflict409Exception $e){
            throw new ApiExceptions(1007,'','创建失败，id已存在');
        }
        return;
    }

    /**
     * 获取最新一条
     * @param string $index 索引
     * @param array $match 过滤条件 ['uid'=>1]
     * @param string $fields 获取字段 uid,os,device
     * @return mixed
     */
    public static function searchOne($index='', $match=[], $fields='')
    {
        $res = (new self())->search($index, $match, $fields,1);
        if (!empty($res)) return $res[0]['_source'];
    }

    /**
     * 获取数据列表
     * @param string $index 索引
     * @param array $match 过滤条件 ['uid'=>1]
     * @param string $fields 获取字段
     * @param string $limit 获取条数
     * @return mixed
     */
    public function search($index='', $match=[], $fields='', $limit='')
    {
        if (empty($index)) throw new ApiExceptions(1007,'',['es:not find index']);
        $body = !empty($match) ? ['query' => ['match' => $match]]:[];
        if ($limit) {
            $params = [
                'index' => $index,
                'type' => 'docs',
                'body' => $body,
                '_source'=>$fields,
                'sort'=>'createtime:desc',
                'size'=>$limit
            ];
        }else {
            $params = [
                'index' => $index,
                'type' => 'docs',
                'body' => $body,
                '_source'=>$fields,
                'sort'=>'createtime:desc',
            ];
        }
        $res = $this->client->search($params);
        if ($res['hits']['total'] > 0) return $res['hits']['hits'];
    }

    /**
     * 查询index是否存在
     * @param $params
     * @return bool
     */
   public static function existsIndex($index='')
   {
       if (empty($index)) throw new ApiExceptions(1007,'',['es:not find index']);
       $params['index'] = $index;
       return (new self())->client->indices()->exists($params);
   }

    /**
     * 创建索引
     * @param $index
     * @return array
     */
    public function createIndex($index)
    {
        $params = [
            'index' => $index,
            'body' => [
                'settings' => [
                    'number_of_shards' => 5,
                    'number_of_replicas' => 1
                ]
            ]
        ];
        return $this->client->indices()->create($params);

    }

    /**
     * 删除索引
     * @param $index
     * @return array
     */
    public function deleteIndex($index)
    {
        $params =['index'=>$index];
        return $this->client->indices()->delete($params);
    }
    private function updateByQuery($params)
    {
        if (empty($params)) throw new ApiExceptions(1000);
        try {
            return $res = $this->client->updateByQuery($params);
        }catch (BadMethodCallException $e){
            throw new ApiExceptions(1007,'',$e->getMessage());
        }
        return;
    }


}
