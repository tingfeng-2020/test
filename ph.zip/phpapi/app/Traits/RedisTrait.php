<?php

namespace App\Traits;

use App\Tools\Redis;

/**
 * Redis工具Trait
 * Trait RedisTrait
 * @package App\Traits
 */
trait RedisTrait
{
    /**
     * 获取有序列表的长度
     * @param string $key
     * @return int
     */
    public static function getSortedListLen($key)
    {
        return Redis::getInstance()->zCard($key);
    }

    /**
     * 获取有序列表
     * @param string $key 列表键名
     * @param int $startRow 起始行
     * @param int $row 获取记录数，默认为10条
     * @param int $startScore score起始值，默认为0
     * @param int $endScore score截止值，默认为0
     * @param bool $withScores 是否返回score，true则返回，否则不返回
     * @param int $sortType 排序类型，1=顺序，2=倒序
     * @param int $skipNum 跳过数量，默认为1
     * @return array
     */
    public static function getSortedListKey(string $key, $startRow = 0, $row = 10, $startScore = 0, $endScore = 0,
                                            $withScores = false, $sortType = 2, $skipNum = 1)
    {
        $endRow = $startRow + $row - 1;
        $endRow < -1 && $endRow = -1;

        if ($startScore) {
            $method = $sortType == 1 ? 'zRangeByScore' : 'zRevRangeByScore';
            $keyList = Redis::getInstance()->$method($key, $startScore, $endScore, [
                'limit' => [$skipNum, $row],
                'withscores' => $withScores
            ]);
        } else {
            $method = $sortType == 1 ? 'zRange' : 'zRevRange';
            $keyList = Redis::getInstance()->$method($key, $startRow, $endRow, $withScores);
        }

        return $keyList ? $keyList : [];
    }

    /**
     * 判断有序列表中是否存在某成员
     * @param string $key
     * @param $value
     * @return bool
     */
    public static function hasInSortedList(string $key, $value)
    {
        return Redis::getInstance()->zScore($key, $value) === false ? false : true;
    }

    /**
     * 获取无序列表的长度
     * @param string $key
     * @return int
     */
    public static function getUnSortedListLength(string $key)
    {
        return Redis::getInstance()->sCard($key);
    }

    /**
     * 获取无序列表
     * @param string $key
     * @return array
     */
    public static function getUnSortedList(string $key)
    {
        return Redis::getInstance()->sMembers($key);
    }

    /**
     * 判断无序列表中是否存在某成员
     * @param string $key
     * @param $value
     * @return bool
     */
    public static function hasInUnSortedList(string $key, $value)
    {
        return Redis::getInstance()->sIsMember($key, $value);
    }
}
