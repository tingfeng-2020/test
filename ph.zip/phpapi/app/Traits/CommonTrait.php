<?php

namespace App\Traits;

use App\Exceptions\ApiExceptions;
use App\Tools\Redis;

trait CommonTrait
{
    /**
     * @var int 操作并发锁随机值
     */
    private $random = 1;

    public function dealOperateLock(string $key)
    {
        if(empty($key)) return;

        if(Redis::getInstance()->set($key , $this->random , [
            'nx',
            'ex' => 60
        ]))
        {
            throw new ApiExceptions(1105);
        }
    }

    /**
     * 删除操作并发锁
     * @param string $key
     */
    public function delOperateLock(string $key)
    {
        if(empty($key)) return;

        if(Redis::getInstance()->get($key) == $this->random)
        {
            Redis::getInstance()->del($key);
        }
    }

    /**
     * 手机号判断
     * @param $mobile
     */
    protected function checkMobile($mobile)
    {
        if(empty($mobile)){
            throw new ApiExceptions(1102);
        }

        if(!preg_match("/^1[3456789]{1}\d{9}$/",$mobile)){
            throw new ApiExceptions(1103);
        }
    }

    /**
     * 是否为空及长度判断
     * @param $content
     * @param int $len
     * @param bool $required
     */
    protected function checkContent($content , $len = 0 , $required = true)
    {
        if($required && empty($content))
        {
            throw new ApiExceptions(1005);
        }

        if($len && abslength($content) > $len){
            throw new ApiExceptions(1005);
        }
    }

    protected function checkInArray($value , $arr)
    {
        if(!in_array($value, $arr))
        {
            throw new ApiExceptions(1005);
        }
    }
}