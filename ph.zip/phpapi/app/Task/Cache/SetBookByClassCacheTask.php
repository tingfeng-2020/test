<?php


namespace App\Task\Cache;

use App\Tools\Redis;
use Hhxsv5\LaravelS\Swoole\Task\Task;


class SetBookByClassCacheTask extends Task
{
    private $data;


    public function __construct($data)
    {
        $this->data = $data;

    }

    public function handle(): void
    {
        if (empty($this->data['detail'])) return;
        //预防缓存击穿，将最大数据缓存进去。。
        $redis = Redis::getInstance();
        foreach ($this->data['detail'] as $k => $v) {
            $redis->zAdd($this->data['detailKey'], $k, $v);
        }

        $redis->expire($this->data['detailKey'], $this->data['ttl'] + mt_rand(1, 120));

    }


}
