<?php


namespace App\Task;

use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Support\Facades\Log;

class SMSTask  extends  Task
{
    private $data;
    public function __construct($data)
    {
        $this->data = $data;
    }

    public function handle()
    {
        $arr = [
            'action' => 'send',
            'account' => env('SMS_PLATFORM_ACCOUNT'),
            'password' => env('SMS_PLATFORM_PWD'),
            'extno' => env('SMS_PLATFORM_KEY'),
            'content' => $this->data['content'],
            'mobile' => $this->data['phone'],
            'rt' => 'json',
        ];
        $client = new \GuzzleHttp\Client();
        $response = $client->post(env('SMS_PLATFORM_URL'),['form_params'=>$arr]);
        $result = json_decode($response->getBody()->getContents(),true);
        if(!isset($result['status']) or !$result['status'] == 0){
            Log::error('短信发送失败',$result);
        }

    }
}
