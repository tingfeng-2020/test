<?php


namespace App\Task;

use App\Exceptions\ApiExceptions;
use App\Http\Service\BbsService;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Swoole\Exception;


class SaveBbsDbTask  extends  Task
{
    private $data;
    public function __construct($data)
    {
        $this->data = $data;
    }

    public function handle()
    {
        if (isset($this->data['addOption']) && !empty($this->data['addOption'])) {
            try {
                $s = new BbsService();
                $addOption = $this->data['addOption'];
                $s->$addOption($this->data);
            } catch (Exception | ApiExceptions $e){

            }

        }

    }
}
