<?php

namespace App\Jobs\Timer;

use App\Task\GetChapterTask;
use App\Tools\Redis;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Hhxsv5\LaravelS\Swoole\Timer\CronJob;

/**
 * 发送短信
 * Class SendSmsJob
 * @package App\Jobs\Timer
 */
class GetChapterJob extends CronJob
{
    public function interval()
    {
        return 50;// 每0.5秒运行一次
    }


    public function run()
    {
        $redis = Redis::getInstance();
        $redis->select(8);
        $result = $redis->lPop('spider_chapter');
        if($result){
            $task = new GetChapterTask(json_decode($result,true));
            Task::deliver($task);
        }
        // TODO: Implement run() method.
    }
}
