<?php


namespace App\Jobs\Timer;


use Hhxsv5\LaravelS\Swoole\Task\Task;
use Hhxsv5\LaravelS\Swoole\Timer\CronJob;

class SendJob extends CronJob
{

    public function interval()
    {
        return 1000;// 每1秒运行一次
    }


    public function run()
    {
        $service = new PayService();
        $order = $service->getSendInfo();
        if($order){
            $ret = Task::deliver(new SendGoodTask($order));
        }
        // TODO: Implement run() method.
    }
}
