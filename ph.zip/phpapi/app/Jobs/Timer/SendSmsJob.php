<?php

namespace App\Jobs\Timer;

use Hhxsv5\LaravelS\Swoole\Timer\CronJob;

/**
 * 发送短信
 * Class SendSmsJob
 * @package App\Jobs\Timer
 */
class SendSmsJob extends CronJob
{
    public function interval()
    {
        return 1000;// 每1秒运行一次
    }


    public function run()
    {
        // TODO: Implement run() method.
    }
}