<?php


namespace App\Jobs\Timer;


use App\Http\Service\MessageService;
use Hhxsv5\LaravelS\Swoole\Timer\CronJob;

class SendPushBuJob extends CronJob
{
    public function interval()
    {
        return 10000;// 每10秒运行一次
    }


    public function run()
    {
        $service = new MessageService();
        $service->pushMessageBu();

    }
}

