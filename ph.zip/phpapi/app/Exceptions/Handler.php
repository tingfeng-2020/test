<?php

namespace App\Exceptions;

use App\Tools\RequestLogTools;
use Exception;
use Firebase\JWT\ExpiredException;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Laravel\Lumen\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\HttpException;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that should not be reported.
     *
     * @var array
     */
    protected $dontReport = [
        AuthorizationException::class,
        HttpException::class,
        ModelNotFoundException::class,
        ValidationException::class,
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param \Exception $exception
     * @return void
     */
    public function report(Exception $exception)
    {
//        if ($exception instanceof ApiExceptions) {
//            $result = [
//                'code' => $exception->getCode(),
//                'msg' => $exception->getMessage(),
//                'data' => [],
//            ];
//            //这里要打个日志记录
//        } elseif ($exception instanceof ValidationException) {
//            $msg = json_decode($exception->getResponse()->getContent(), true);
//            $par = array_keys($msg);
//            $message = empty($message) ? Lang::get("error.1005") : $message;
//            if ($par) {
//                array_unshift($par, $message);
//                $message = call_user_func_array('sprintf', $par);
//            }
//            $result = [
//                "code" => 1005,
//                "msg" => $message,
//                "data" => []
//            ];
//        }
//        if($result){
//            return response()->json($result);
//        }

        // parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Exception $exception
     * @return \Illuminate\Http\Response|\Illuminate\Http\JsonResponse
     */
    public function render($request, Exception $exception)
    {
        //表单校验错误
        if (!$exception instanceof ValidationException and !$exception instanceof ApiExceptions and !$exception instanceof ExpiredException) {
            $result = [
                "code" => 1000,
                "msg" => '系统错误',

            ];
            Log::error($exception->getFile().$exception->getLine().$exception->getMessage());
        } else {
            $result = [
                'code' => $exception->getCode(),
                'msg' => $exception->getMessage(),
              //  'data' => [],
            ];

            //表单验证抛出的错误
            if ($exception instanceof ValidationException) {
                $msg = json_decode($exception->getResponse()->getContent(), true);
                $par = array_keys($msg);
                throw new ApiExceptions(1005,'',$par);
            }
            //jwt 抛出的错误
            if($exception instanceof  ExpiredException){
                throw new ApiExceptions(1006);
            }

        }
        return response()->json($result);
        //   return parent::render($request, $exception);
    }
}
