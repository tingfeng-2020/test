<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookListModel extends Model
{
    protected $table = 'book_list';


    /**
     * @param $key
     * @return string
     */
    public function getImgUrlAttribute($key): string
    {
        return env('MEDIA_HOST') . $key;

    }
}
