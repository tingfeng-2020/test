<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookRecommendModel extends Model
{
    protected $table = 'book_recommend';
}
