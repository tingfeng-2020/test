<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogDeviceModel extends  LogBaseModel
{
    protected $table = 'log_device';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','os','channel','area','long_time','ip','createtime'
    ];
}
