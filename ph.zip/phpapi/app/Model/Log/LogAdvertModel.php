<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogAdvertModel extends  LogBaseModel
{
    protected $table = 'log_advert';
    public $timestamps = false;
    protected $fillable = [
        'ad_id','click','exposure','material_id','createtime'
    ];
}
