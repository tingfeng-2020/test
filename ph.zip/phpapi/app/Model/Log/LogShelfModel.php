<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogShelfModel extends  LogBaseModel
{
    protected $table = 'log_shelf';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','member_id','os','channel','area','book_id','createtime'
    ];
}
