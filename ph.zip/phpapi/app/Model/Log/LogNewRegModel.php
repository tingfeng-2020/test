<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogNewRegModel extends  LogBaseModel
{
    protected $table = 'log_new_reg';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','member_id','os','channel','area','long_time','createtime'
    ];
}
