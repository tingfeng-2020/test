<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogNewDeviceModel extends  LogBaseModel
{
    protected $table = 'log_new_device';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','member_id','os','channel','area','long_time','ip','createtime'
    ];
}
