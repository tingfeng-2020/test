<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogLookModel extends  LogBaseModel
{
    protected $table = 'log_look_all';
    public $timestamps = false;
    protected $fillable = [
        'id','device', 'device_model','member_id','os','channel','area','book_id','createtime'
    ];
}
