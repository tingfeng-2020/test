<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogSearchModel extends  LogBaseModel
{
    protected $table = 'log_search';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','member_id','os','channel','area','content','createtime'
    ];
}
