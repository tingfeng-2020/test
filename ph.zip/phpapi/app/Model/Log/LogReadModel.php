<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogReadModel extends  LogBaseModel
{
    protected $table = 'log_read';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','member_id','os','channel','area','long_time','createtime',
        'light','font','font_size','flip_style','background','book_id',
        'start_time','end_time'
    ];
}
