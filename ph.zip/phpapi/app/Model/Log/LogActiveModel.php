<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogActiveModel extends  LogBaseModel
{
    protected $table = 'log_active';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','member_id','os','channel','area','long_time','grade_day','createtime'
    ];
}
