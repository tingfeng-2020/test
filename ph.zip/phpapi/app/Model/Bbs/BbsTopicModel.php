<?php


namespace App\Model\Bbs;


use Illuminate\Database\Eloquent\Model;

class BbsTopicModel extends BbsBaseModel
{
    protected $table = 'bbs_topic';

    protected $primaryKey = 'tid';
    /**
     * 过滤掉非数据库字段的数据
     * @param $data
     * @return array
     */
    public function filter($data)
    {
        if (empty($this->fillable)) {
            $this->setFillable();
        }
        $result = [];
        if (empty($data) || !is_array($data)) {
            return $result;
        }
        foreach ($this->fillable as $item) {
            if (isset($data[$item])) {
                $result[$item] = $data[$item];
            }
        }
        return $result;
    }

    /**
     * 保存数据
     * @param $data
     * @return BaseModel
     */
    public function saveData($data)
    {
        $data = $this->newInstance()->filter($data);
        foreach ($data as $key => $item) {
            $this->$key = $item;
        }
        $this->save();
        return $this;
    }
}