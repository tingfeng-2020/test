<?php


namespace App\Model\Bbs;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class BbsBaseModel extends Model
{
    public $timestamps = false;
    /**
     * 过滤掉非数据库字段的数据
     * @param $data
     * @return array
     */
    public function filter($data)
    {
        if (empty($this->fillable)) {
            $this->setFillable();
        }
        $result = [];
        if (empty($data) || !is_array($data)) {
            return $result;
        }
        foreach ($this->fillable as $item) {
            if (isset($data[$item])) {
                $result[$item] = $data[$item];
            }
        }
        return $result;
    }
    /**
     * 自动获取数据库表字段
     */
    public function setFillable()
    {
        $key = get_class($this);
        $cache = Cache::store('file')->get($key);
        if (empty($cache)) {
//            $columns = Schema::getColumnListing($this->table);
            //如果是公共库的，会读取默认库，而默认库没有表的情况下会为空，所以改成以下语句
            $columns = $this->getConnection()->getSchemaBuilder()->getColumnListing($this->table);
            $cache = $columns;
            Cache::store('file')->put($key, $columns,60);
        }
        $this->fillable = $cache;
    }
    /**
     * 保存数据
     * @param $data
     * @return BaseModel
     */
    public function saveData($data)
    {
        $data = $this->newInstance()->filter($data);
        foreach ($data as $key => $item) {
            $this->$key = $item;
        }
        $this->save();
        return $this;
    }
    /**
     * 更新数据
     * @param int $id
     * @param array $data 更新数据
     * @return BaseModel
     */
    public function updateData($id, array $data, $pk='id')
    {
        $data = $this->filter($data);
        $res = $this->newInstance()->whereKey($id)->update($data);
        if ($res) {
            $data[$pk] = $id;
            $this->options = [
                'where' => [$pk => $id]
            ];
            $this->data = $data;
            $this->fireModelEvent('updated', false);
        }
        return $this;
    }
}