<?php


namespace App\Model\Bbs;


use Illuminate\Database\Eloquent\Model;

class BbsLogModel extends BbsBaseModel
{
    protected $table = 'bbs_log';
}