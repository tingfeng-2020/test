<?php


namespace App\Model\Bbs;


use Illuminate\Database\Eloquent\Model;

class BbsReplyModel extends BbsBaseModel
{
    protected $table = 'bbs_reply';
    protected $primaryKey = 'rid';
}