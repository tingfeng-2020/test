<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

/**
 * 会员模型
 * Class MembersModel
 * @package App\Model
 */
class MembersModel extends Model
{

    protected $table = 'members';
    public $timestamps = false;


}