<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class NotifyMessageModel extends Model
{

    protected $table = 'notify_message';
    public $timestamps = false;
    protected $fillable = [
        'title','type','content','msg_type','link_param','send_memberId','createtime','headImgUrl'
    ];

}