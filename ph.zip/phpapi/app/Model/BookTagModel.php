<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookTagModel extends Model
{

    protected $table = 'book_tag';


}
