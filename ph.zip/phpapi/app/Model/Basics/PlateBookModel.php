<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class PlateBookModel extends Model
{
    protected $table = 'plate_book';
}