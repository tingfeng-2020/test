<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class ClassifyModel extends Model
{
    protected $table = 'classify';
}