<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class BookClassModel extends Model
{
    protected $table = 'book_class';
}