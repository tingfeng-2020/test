<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class WordSearchModel extends Model
{
    protected $table = 'word_search';
}