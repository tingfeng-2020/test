<?php
namespace App\Model\Ad;


use Illuminate\Database\Eloquent\Model;

class AdSlotModel extends Model
{
    protected $table = 'ad_slot';
}
