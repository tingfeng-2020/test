<?php
namespace App\Model\Ad;


use Illuminate\Database\Eloquent\Model;

class AdMaterialModel extends Model
{
    protected $table = 'ad_material';
}
