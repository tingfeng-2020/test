<?php
namespace App\Model\Ad;


use Illuminate\Database\Eloquent\Model;

class AdModel extends Model
{
    protected $table = 'ad';
    protected $casts = [
        'jump_data' => 'array',
    ];

}
