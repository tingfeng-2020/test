<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookClassModel extends Model
{

    protected $table = 'book_class';




  


}
