<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookShelfModel extends Model
{

    protected $table = 'book_shelf';
    public $timestamps = false;

}
