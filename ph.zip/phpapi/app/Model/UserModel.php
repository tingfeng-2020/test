<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class UserModel extends  Model
{

    protected $table = 'user';
    public $timestamps = false;
    protected $fillable = [
        'phone', 'nick_name','header_img','sex','open_id'
    ];
}
