<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookAuthorModel extends Model
{


    protected $table = 'book_author';
    public $timestamps = false;

    public function getAvatarAttribute($key): string
    {
        return $key ?env('MEDIA_HOST') . $key:'';
    }

}
