<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class FontModel extends Model
{

    protected $table = 'font';
    public $timestamps = false;


    public function getUrlAttribute($key): string
    {
        return env('MEDIA_HOST') . $key;
    }
    public function getPreviewAttribute($key): string
    {
        return env('MEDIA_HOST') . $key;
    }
    public function getPreviewDarkAttribute($key): string
    {
        return env('MEDIA_HOST') . $key;
    }
    public function getSizeAttribute($key): string
    {
        return formatBytes($key);
    }


}
