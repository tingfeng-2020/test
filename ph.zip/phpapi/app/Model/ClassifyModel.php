<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class ClassifyModel extends Model
{
    protected $table = 'classify';


    public function getIconAttribute($key)
    {
        return env('MEDIA_HOST') . $key;
    }


}
