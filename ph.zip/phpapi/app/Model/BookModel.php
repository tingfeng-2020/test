<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookModel extends Model
{


    protected $table = 'book';
    public $timestamps = false;


    public function getBookImgurlAttribute($key): string
    {
        return env('MEDIA_HOST') . $key;
    }

}
