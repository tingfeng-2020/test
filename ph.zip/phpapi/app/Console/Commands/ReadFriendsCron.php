<?php

namespace App\Console\Commands;


use App\Http\Service\LogService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;


class ReadFriendsCron extends Command
{

    protected $name = 'ReadFriendsCron';//命令名称


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '本书读友还在读定时数据处理';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Log::info('ReadFriendsCron='.date('Y-m-d H:i:s'));
        $s = new LogService();
        $s->dealShelfData();
    }








}
