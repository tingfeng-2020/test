<?php

namespace App\Console;

use App\Console\Commands\ReadFriendsCron;
use App\Console\Commands\Test;
use App\Console\Commands\UpdateBookHotCron;
use Illuminate\Console\Scheduling\Schedule;
use Laravel\Lumen\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
        Test::class,
        ReadFriendsCron::class,
        UpdateBookHotCron::class
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        /**
         * 每天凌晨零点定时计算一次存在redis缓存中；
         * 计算每本书的被加入书架中的用户 还有加入其他书的占比
         */
        $schedule->command('ReadFriendsCron')
        ->daily();//每天凌晨执行一次
        /**
         * 更新书籍人气值与在读人数值（2小时更新一次）
         */
        $schedule->command('UpdateBookHotCron')
            ->cron('0 */2 * * *');//每两小时执行一次
    }

}
