###api服务

###所需环境部署
- `centos`: 7.6
- `php`: 7.4 https://www.php.net/manual/zh/install.php
- `mysql`: 8.0.18 https://blog.csdn.net/qq_40223688/article/details/90733495
- `redis`: 5.0 https://blog.csdn.net/lc1010078424/article/details/78295482
- `php所需开启扩展`： redis,swoole
- `composer` : 建议使用最新版本  https://docs.phpcomposer.com/00-intro.html
- `nginx` : 建议使用最新版本  http://nginx.org/en/download.html  

## PHP代码部署
    1.将php代码目录下 .env.example 复制一份放与相同目录下 文件名问 .env
    2.修改 .env 里的 服务配置等配置  
    2.在当前项目目录下 执行命令  composer install
    3.执行php bin/laravels start #start 开启 restart重启进程   reload 进程重新加载代码
    
    
    
## nginx参考配置

    参考配置
    gzip on;
    gzip_min_length 1024;
    gzip_comp_level 2;
    gzip_types text/plain text/css text/javascript application/json application/javascript application/x-javascript application/xml application/x-httpd-php image/jpeg image/gif image/png font/ttf font/otf image/svg+xml;
    gzip_vary on;
    gzip_disable "msie6";
    ###nginx 负载均衡配置
    upstream swoole {
        # 通过 IP:Port 连接
        server 127.0.0.1:5200 weight=5 max_fails=3 fail_timeout=30s;
        # 通过 UnixSocket Stream 连接，小诀窍：将socket文件放在/dev/shm目录下，可获得更好的性能
        #server unix:/yourpath/laravel-s-test/storage/laravels.sock weight=5 max_fails=3 fail_timeout=30s;
        #server 192.168.1.1:5200 weight=3 max_fails=3 fail_timeout=30s;
        #server 192.168.1.2:5200 backup;
        keepalive 16;
    }
    server {
        listen 80;
        # 别忘了绑Host
        server_name laravels.com;
        access_log /yourpath/log/nginx/$server_name.access.log  main;
        autoindex off;
        index index.html index.htm;
        # Nginx处理静态资源(建议开启gzip)，LaravelS处理动态资源。
        location / {
            try_files $uri @laravels;
        }
         当请求PHP文件时直接响应404，防止暴露public/*.php
        location ~* \.php$ {
            return 404;
        }
        location @laravels {
            # proxy_connect_timeout 60s;
            # proxy_send_timeout 60s;
            # proxy_read_timeout 120s;
            proxy_http_version 1.1;
            proxy_set_header Connection "";
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Real-PORT $remote_port;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header Host $http_host;
            proxy_set_header Scheme $scheme;
            proxy_set_header Server-Protocol $server_protocol;
            proxy_set_header Server-Name $server_name;
            proxy_set_header Server-Addr $server_addr;
            proxy_set_header Server-Port $server_port;
            # “swoole”是指upstream
            proxy_pass http://swoole;
        }
    }

## 其它
            如果遇见请求数据超过机器所承载 可以扩展负载均衡机器 
            1.将php当前运行服务器作为镜像复制到多台机器
            2.设置负载均衡策略
            
            例子: 这里以nginx 负载均衡配置
            upstream是Nginx的HTTP Upstream模块，这个模块通过一个简单的调度算法来实现客户端IP到后端服务器的负载均衡。
            在上面的设定中，通过upstream指令指定了一个负载均衡器的名称cszhi.com。这个名称可以任意指定，在后面需要的地方直接调用即可。
            
            Nginx的负载均衡模块目前支持4种调度算法，下面进行分别介绍，其中后两项属于第三方的调度方法。
            
            轮询（默认）：每个请求按时间顺序逐一分配到不同的后端服务器，如果后端某台服务器宕机，故障系统被自动剔除，使用户访问不受影响；
            Weight：指定轮询权值，Weight值越大，分配到的访问机率越高，主要用于后端每个服务器性能不均的情况下；
            ip_hash：每个请求按访问IP的hash结果分配，这样来自同一个IP的访客固定访问一个后端服务器，有效解决了动态网页存在的session共享问题；
            fair：比上面两个更加智能的负载均衡算法。此种算法可以依据页面大小和加载时间长短智能地进行负载均衡，也就是根据后端服务器的响应时间来分配请求，响应时间短的优先分配。Nginx本身是不支持fair的，如果需要使用这种调度算法，必须下载Nginx的upstream_fair模块；
            url_hash：按访问url的hash结果来分配请求，使每个url定向到同一个后端服务器，可以进一步提高后端缓存服务器的效率。Nginx本身是不支持url_hash的，如果需要使用这种调度算法，必须安装Nginx 的hash软件包。
            在HTTP Upstream模块中，可以通过server指令指定后端服务器的IP地址和端口，同时还可以设定每个后端服务器在负载均衡调度中的状态。常用的状态有：
            
            down：表示当前的server暂时不参与负载均衡；
            backup：预留的备份机器。当其他所有的非backup机器出现故障或者忙的时候，才会请求backup机器，因此这台机器的压力最轻；
            max_fails：允许请求失败的次数，默认为1。当超过最大次数时，返回proxy_next_upstream 模块定义的错误；
            fail_timeout：在经历了max_fails次失败后，暂停服务的时间。max_fails可以和fail_timeout一起使用。
            注意，当负载调度算法为ip_hash时，后端服务器在负载均衡调度中的状态不能是weight和backup。

## docker













