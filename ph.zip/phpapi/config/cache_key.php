<?php
/***
 *
 *
 * redis  key 设置
 * 默认没有前缀都为string类型
 * HASH: 对应hash类型
 * SET: 无序集合
 * SSET:有序集合
 * LIST: 对应队列
 *
 */


return [

    //验证码key值
    'sms' => [
        1 => 'USER_LOGIN_SMS_%s',
        'SMS_IPHONE_LOG'=>'SET:SMS_IPHONE_LOG',
        'SMS_IPHONE_NUMS'=>'SMS_IPHONE_NUMS',
        'SMS_IPHONE_ERROR_NUMS'=>'SMS_IPHONE_ERROR_NUMS',
    ],

    //token key
    //'TOKEN' => 'TOKEN_LOGIN_%s',
    'token' => [
        'ACCESS_TOKEN' => 'SET:ACCESS_TOKEN',
        'REFRESH_TOKEN' => 'SET:REFRESH_TOKEN',
        'UID' => 'HASH:LOGIN_TOKEN_INFO'
    ],

    //用户手机号码 hash表
    'user' => [
        'PHONE' => 'HASH:USER_PHONE',
        'UID' => 'HASH:USER_UID',
        'READ_MSG_UID'=>'SET:READ_MSG_UID'
    ],
    //书架
    'shelf' => [
        'SHELF_INFO' => 'HASH:SHELF_INFO',
        'BOOK_SHELF' => 'ZSET:USER_BOOK_SHELF',
        'BOOK_SHELF_STRING' => 'BOOK_SHELF_STRING',
        'BOOK_SHELF_UPDATE' => 'STRING:BOOK_SHELF_UPDATE',
    ],

    //消息
    'message'=>[
        'USER_MSG_LIST'=>'USER_MSG_LIST',
        'USER_MSG_COUNT'=>'USER_MSG_COUNT',
    ],


    //书籍详情
    'book' => [
        'key' => 'HASH_BOOK_INFO:BOOK_ID',
        'ttl' => 60
    ],


    //书籍所属分类
    'bookInClass' => [
        'key' => 'HASH_BOOK_IN_CLASS:',
        'ttl' => 60
    ],
    //评论
    'bbs' => [
        'BOOK' => 'ZSET:BOOK',
        'BOOK_TOPIC' => 'STRING:BOOK_TOPIC',
        'BOOK_REPLAY' => 'STRING:BOOK_REPLAY',
        'TID' => 'HASH:TOPIC',
        'TOPIC_LIKE' => 'SET:LIKE',
        'REPLY' => 'ZSET:REPLY',
        'RID' => 'HASH:REPLY',
        'REPLY_LIKE' => 'SET:REPLY_LIKE',
        'PUSH_BBS' => 'LIST:BBS',
        'TOPIC_COMMENTS' => 'TOPIC_COMMENTS',
        'TOPIC_LIKE_NUM' => 'TOPIC_LIKE_NUM',
        'REPLY_COMMENTS' => 'REPLY_COMMENTS',
        'REPLY_LIKE_NUM' => 'REPLY_COMMENTS',
        'TOPIC_TOTAL' => 'TOPIC_TOTAL',
        'REPLY_TOTAL' => 'REPLY_TOTAL',
    ],
    //书城板块
    'basics' => [
        'PLATE_DATA' => 'PLATE_DATA_%s',
        'PLATE_MORE_DATA' => 'PLATE_MORE_DATA_%s',
        'CLASSIFY_TREE' => 'CLASSIFY_TREE',
        'PLATE_BANNERS' => 'PLATE_BANNERS',
        'GET_PLATE' => 'GET_PLATE',
        'WORD_SEARCH' => 'WORD_SEARCH',
        'PROTOCOL' => 'PROTOCOL',
        'PAGE_LINK' => 'PAGE_LINK',
        'APP_VERSION' => 'APP_VERSION',
        'AD_LIST' => 'AD_LIST',
        'AD_SLOT' => 'AD_SLOT',
        'FONT_PACKAGE' => 'FONT_PACKAGE',
        'BOOK_INFO_RESULT' => 'BOOK_INFO_RESULT',
    ],
    'log' => [
        'BOOK_READ_PERCENT' => 'ZSET:BOOK_READ_SHELF_PERCENT', //读友还在读数据（前一天）
        'BOOK_ID_READ_PERCENT' => 'BOOK_ID_READ_PERCENT_LIST',
        'BOOK_ID_READ_DETAIL' => 'HASH:BOOK_ID_READ_DETAIL',//书籍详情阅读人气值记录
        'BOOK_ID_ADD_SHELF' => 'HASH:BOOK_ID_ADD_SHELF',//书籍添加到书架记录在读人数
    ],

    //分类
    'classify' => [
        'key' => 'HASH:CLASSIFY',
        'ttl' => 30,
    ],

    //子分类所属
    'classifyInParent' => [
        'key' => 'CLASSIFY_IN_PARENT_HASH:',
        'ttl' => 30,
    ],

    //排行榜分类
    'classifyInRanking' => [
        'key' => 'CLASSIFY_IN_RANKING_HASH:',
        'ttl' => 30,
    ],

    //搜索
    'search' => [
        'key' => 'key:search',
        'ttl' => 30
    ],

    //分类中所属书籍
    'bookByClass' => [
        'key' => 'BOOK_BY_CLASS_ZSET:',
        'ttl' => 86400,
    ],

    //排行榜
    'rankingClassify' => [
        'key' => 'STRING:RANKING',
        'ttl' => 60,
    ],
    //排行榜所属分类
    'ranking' => [
        'key' => 'RANKING_ZSET:',
        'ttl' => 30,
    ],

    //排行榜下的书籍
    'rankingBook' => [
        'key' => 'HASH_BOOK:RANKING',
        'ttl' => 60
    ],

    //完本书籍
    'bookByOver' => [
        'key' => 'BOOK_BY_OVER_ZSET:',
        'ttl' => 86400  //完本书籍爬虫 一天更新一次
    ],

    //完本书籍推荐
    'bookOverRecommend' => [
        'key' => 'BOOK_BY_OVER_ZSET:',
        'ttl' => 120   //完本书籍后台配置
    ],

    //最新完本书籍
    'bookOverNews' => [
        'key' => 'BOOK_BY_OVER_ZSET:',
        'ttl' => 86400 //完本书籍爬虫 一天更新一次
    ],

    //人气完本书籍
    'bookOverHot' => [
        'key' => 'BOOK_BY_OVER_ZSET:',
        'ttl' => 86400 //完本书籍爬虫 一天更新一次
    ],


    //书籍章节缓存
    'chapter' => [
        'key' => 'HASH_CHAPTER:BOOK_ID',
        'ttl' => 120
    ],


    //书单分类
    'bookListClass'=>[
        'key' => 'HASH:BOOK_LIST_TYPE',
        'ttl' => 60
    ],

    //书单分类
    'bookList' => [
        'key' => 'HASH:BOOK_LIST',
        'ttl' => 60
    ],

    //书单中的书籍
    'bookListBook' => [
        'key' => 'HASH:BOOK_LIST_BOOK',
        'ttl' => 60
    ],

    //书籍标签
    'bookTag' => [
        'key' => 'BOOK_TAG_STRING:',
        'ttl' => 60,
    ],

    //作者
    'author' => [
        'key' => 'BOOK_AUTHOR_HASH:',
        'ttl' => 60,
    ],

    //作者下的书籍
    'bookInAuthor' => [
        'key' => 'BOOK_IN_AUTHOR_STRING:',
        'ttl' => 60,
    ],

    //标签下的书籍
    'bookByTag' => [
        'key' => 'BOOK_BY_TAG_ZSET:',
        'ttl' => 60,
    ],

    //阅读记录
    'bookRed' => [
        'key' => 'BOOK_RED_NOTE_HASH:',
        'ttl' => 168000
    ],

    //阅读记录
    'bookByLike' => [
        'key' => 'BOOK_BY_LIKE_ZSET:',
        'ttl' => 120
    ],
];
