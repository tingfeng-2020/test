<?php
/**
 * Created by PhpStorm.
 * User: xiaop
 * Date: 2020/6/15
 * Time: 下午5:54
 */

return [
    'cdnServer' => env('CDN_SERVER', 'https://rayman-read-book.oss-cn-hongkong.aliyuncs.com/'),                       // 外网
    'ossServer' => env('OSS_SERVER', 'oss-cn-hongkong.aliyuncs.com'),                       // oss外网
    'ossServerHttp'=>'https://',
    'ossServerInternal' => env('OSS_SERVER_INTERNAL', 'oss-cn-hongkong-internal.aliyuncs.com'),      // oss内网
    'ossServerInternalHttp'=>'https://',
    'accessKeyId' => env('OSS_KEY_ID', 'LTAI4GCZyteQSN7APxCTLFUW'),                     // key
    'accessKeySecret' => env('OSS_KEY_SECRET', 'Ghj2okyRdn7ccR9yGjuk7WOfMaOsVC'),             // secret
    'bucketName' => env('OSS_BUCKET_NAME', 'rayman-read-book'),                 // bucket
    'ossObject' => env('OSS_OBJECT', 'media'),
];
