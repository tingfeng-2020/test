<?php

/**
 * Created by PhpStorm.
 * User: xp
 * Date: 2020/6/05
 * Time: 13:39
 * 书籍模块
 */
class BookTest extends TestCase
{

    /**
     * 本书书友还在读
     */
    public function testGetCurrentReaderBooks()
    {
        $param = [
            'book_id'=>1,
            'page_index'=>1,
            'page_size'=>10,
        ];
        $this->request('get',$this->v.'/Book/GetCurrentReaderBooks',$param);
    }

    /**
     * 猜你喜欢
     */
    public function testGetBookByLike()
    {
        $param = [
            'class_id'=>376,
            'page_index'=>1,
            'page_size'=>10,
        ];
        $this->request('get',$this->v.'/Book/GetBookByLike',$param);
    }
    public function testGetRankingClassify()
    {
        $this->request('get',$this->v.'/Book/GetRankingClassify');
    }
    /**
     * 作者详情
     */
    public function testGetAuthor()
    {
        $param = [
            'author_id'=>1,
        ];
        $this->request('get',$this->v.'/Book/GetAuthor',$param);
    }
    /**
     * 获取书籍详情
     */
    public function testGetBookById()
    {
        $param = [
            "book_id"=> 1,
        ];
        $this->request('get', $this->v.'/Book/GetBookById', $param);

    }

    /**
     * 搜索书籍
     */
    public function testSearchBooks()
    {
        $param = [
            'search'=>'诱惑',
            'pageindex'=>1,
            'pagesize'=>10
        ];
        $this->request('get',$this->v.'/Book/SearchBooks',$param);
    }



    /**
     * 完本书单
     */
    public function testOverBookByHot()
    {
        $this->request('get',$this->v.'/Book/OverBookByHot');
    }

    /**
     * 书籍标签
     */
    public function testGetBookByTag()
    {
        $param = [
            'tag'=>1,
            'page_index'=>1,
            'page_size'=>10,
        ];
        $this->request('get',$this->v.'/Book/GetBookByTag',$param);
    }





}
