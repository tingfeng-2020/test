<?php

abstract class TestCase extends Laravel\Lumen\Testing\TestCase
{
    protected $account = '18250161111';
    protected $code = '123456';
    protected $token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOjE0MywiaWF0IjoxNTkxMzQ3MTM2LCJuYmYiOjE1OTEzNDcxMzYsImV4cCI6MTU5MTk1MTkzNiwic2NvcGVzIjoxfQ.xJuN7tDq0PrktJh5QdJwuAPKZeP4osbTXE6RnvX2nc8';//登录token
    protected $v = '/api/v1_1';
    /**
     * Creates the application.
     *
     * @return \Laravel\Lumen\Application
     */
    public function createApplication()
    {
        return require __DIR__.'/../bootstrap/app.php';
    }

    /**
     * 测试模拟请求
     * @param string $method
     * @param string $url
     * @param array $params
     */
    public function request(string $method,string $url,array $params=[], $content=null){
        $login = stristr($url,'/Auth/Login');
        if ($login) $this->token = '';
        $Timestamp = time();
        $Signtoken = md5($Timestamp.'JDe(*0LPe2H1');
        $headers = [
            'Signtoken' => $Signtoken,
            'Timestamp'=>$Timestamp,
            'Os'=>1,
            'Device'=>'62852f91967d98768d1036bb1d2d7155',
            'DeviceModel'=>'JKM-AL00a',
            'Channel'=>0,
            'Area'=>'22.527531,113.937745',
            'Authorization'=>$this->token,
            'X-Requested-With'=>'XMLHttpRequest',
            'Content-Type' => 'application/x-www-form-urlencoded',
        ];
        //刷新应用,避免缓存，应用于$request->user();
        $this->refreshApplication();
        $this->setUp();
        $server = $this->transformHeadersToServerVars($headers);
        $response = $this->call($method,$url,$params,[], [], $server, $content);
        print_r('HTTP状态码：'.$response->getStatusCode().PHP_EOL);
        print_r('返回值：'.PHP_EOL);
        $data = json_decode($response->getContent(),true);
        print_r($data);
        $this->assertEquals(200,$data['code']??-1);
        echo PHP_EOL.PHP_EOL.json_encode($data,JSON_UNESCAPED_UNICODE);
    }
    /**
     * 覆盖setUp方法 添加对sql查询监听
     */
    public function setUp():void
    {
        parent::setUp();
        echo '执行sql语句:'.PHP_EOL;
        sqlDump();
    }


}
