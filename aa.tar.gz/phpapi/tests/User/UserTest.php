<?php

/**
 * Created by PhpStorm.
 * User: xp
 * Date: 2020/6/05
 * Time: 13:39
 * 用户操作-书架-消息模块
 */
class UserTest extends TestCase
{
    /**
     * 用户登录
     */
    public function testLogin()
    {
        $this->request('post', $this->v.'/Auth/Login',  [
                "account"=> $this->account,
                "os"=>"1",
                "code"=> $this->code,
                "deviceModel"=> "",
                "getuiCid"=> "",
                "appGuid"=>"",
                ]
          );

    }
    /**
     * 获取用户信息
     */
    public function testAccount()
    {
        $this->request('get', $this->v.'/Member/GetMemberInfo');
    }
    /**
     * 修改用户昵称
     */
    public function testUpdateNickname()
    {
        $this->request('post', $this->v.'/Member/UpdateNickname',['nickName'=>'ppp']);
    }
    /**
     * 修改用户头像
     */
    public function testUpdateHeadImgurl()
    {
        $this->request('post', $this->v.'/Member/UpdateHeadImgurl',['headImgurl'=>'media/20200111/1215924702497869824.png']);
    }

    /**
     * 用户注销
     */
    public function testLogout()
    {
        $this->request('post', $this->v.'/Member/Logout',[
            'getuiCid' => '',
            'appGuid' => '',
        ]);
    }
    /**
     * 获取消息数量
     */
    public function testMessageCount()
    {
        $this->request('get', $this->v.'/Member/MessageCount');
    }
    /**
     * 获取消息列表
     */
    public function testGetNotifyMessage()
    {
        $this->request('get', $this->v.'/Member/GetNotifyMessage',['type'=>1]);
    }
    /**
     * 获取消息列表
     */
    public function testMessageUpdateByType()
    {
        $this->request('post', $this->v.'/Member/MessageUpdateByType',['type'=>1,'status'=>2]);
    }

    /**
     * 获取书架列表
     */
    public function testGetMyBookShelf()
    {
        $this->request('get', $this->v.'/Book/GetMyBookShelf');
    }
    /**
     * 删除书架
     */
    public function testDelMyBookSehlf()
    {
        $this->request('post', $this->v.'/Book/DelMyBookSehlf',[]);
    }
    /**
     * 举报
     */
    public function testReflect()
    {
        $param = ['book_id'=>3,'type'=>7,'tid'=>1,'rid'=>0];
        $this->request('post', $this->v.'/Book/Reflect',$param);
    }




}
