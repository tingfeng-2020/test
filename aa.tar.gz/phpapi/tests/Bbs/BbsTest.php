<?php

/**
 * Created by PhpStorm.
 * User: xp
 * Date: 2020/6/05
 * Time: 13:39
 * 评论模块
 */
class BbsTest extends TestCase
{
    /**
     * 评论列表
     */
    public function testTopiclist()
    {
        $param = [
            'book_id'=>23,
            'page_index'=>1,
            'page_size'=>10,
            'keyword'=>'',
        ];
        $this->request('get', $this->v.'/bbs/topiclist',$param);
    }
    /**
     * 评论详情列表
     */
    public function testReplyinfo()
    {
        $param = [
            'tid'=>23,
            'page_index'=>1,
            'page_size'=>10,
        ];
        $this->request('get', $this->v.'/bbs/replyinfo',$param);
    }
    /**
     * 评论详情列表
     */
    public function testSend()
    {
        $param = [
            'book_id'=>23,
            'message'=>'11111',
        ];
        $this->request('post', $this->v.'/bbs/send',$param);
    }
    /**
     * 评论删除
     */
    public function testDel()
    {
        $param = [
            'id'=>67,
            'type'=>1,
        ];
        $this->request('delete', $this->v.'/bbs/del',$param);
    }




}
