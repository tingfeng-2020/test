<?php
$router = app()->router;
$router->group([
    'namespace' => 'V1_1',
    'prefix' => 'api/v1_1',
    'middleware' => ['signToken','throttle:10,1']
],function () use ($router)
{
        //基础模块
        $router->group([
            'namespace' => 'Basis',
            'prefix' => 'Basis',
        ],function () use ($router)
        {
            $router->get('/GetWordSearch','BasisController@getWordSearch');//获取热门搜索词
            $router->get('/GetProtocol','BasisController@getProtocol');//获取用户协议& 隐私政策 (H5使用）
            $router->get('/GetPageLink','BasisController@getPageLink');//获取用户协议& 隐私政策 (APP端使用）
            $router->get('/GetAppVersion','BasisController@getAppVersion');//APP版本更新
            $router->get('/GetPlates','BasisController@getPlates');//板块分类数据
            $router->get('/GetPanelMoreData','BasisController@getPanelMoreData');//板块更多数据
            $router->get('/GetPlateBanners','BasisController@getPlateBanners');//板块广告
            $router->get('/GetClassifyTree','BasisController@getClassifyTree');//获取分类数据（H5,APP）使用
            $router->get('/GetBanners',['uses'=>'BasisController@getBanners','middleware'=>'checkHeader']);//获取广告
            $router->get('/GetAdSlot','BasisController@getAdSlot');//获取广告位
            $router->get('/GetFontPackage','BasisController@getFontPackage');//获取字体包

        });
        $router->group([
            'namespace' => 'Basis',
            'middleware' => 'auth:skip',
            'prefix' => 'Basis',
        ],function () use ($router)
        {
            $router->get('/GetPlateDataItem','BasisController@getPlateDataItem');//板块模块数据

        });
        //我的消息模块

        $router->group([
            'namespace' => 'Basis',
            'middleware' => 'auth',
            'prefix' => 'Member',
        ],function () use ($router)
        {
            $router->get('GetNotifyMessage','MessageController@getNotifyMessage');//获取消息
            $router->post('NotifyMessageUpdate','MessageController@messageUpdate');//消息设置（通过id）
            $router->get('MessageDetailed','MessageController@messageDetailed');//消息详情
            $router->get('MessageCount','MessageController@messageCount');//消息数量
            $router->get('PushMessage','MessageController@pushMessage');//消息数量
            $router->post('MessageUpdateByType','MessageController@messageUpdateByType');//消息设置（通过类型）
        });
        //评论模块

        $router->group([
            'namespace' => 'Bbs',
            'middleware' => 'auth',
            'prefix' => 'bbs',
        ],function () use ($router)
        {
            $router->post('/send','BbsController@send');//评论提交保存
            $router->post('/reply','BbsController@reply');//评论回复提交
            $router->post('/likes','BbsController@likes');//评论回复提交
            $router->delete('/del','BbsController@delete');//评论删除
        });
        $router->group([
            'namespace' => 'Bbs',
            'middleware' => 'auth:skip',
            'prefix' => 'bbs',
        ],function () use ($router)
        {
            $router->get('/topiclist','BbsController@topicList');//评论列表
            $router->get('/replyinfo','BbsController@replyInfo');//评论详情
        });
        //上传文件
        $router->group([
            'namespace' => 'UploadFile',
            'middleware' => 'auth',
            'prefix' => 'Book',
        ],function () use ($router)
        {
            $router->post('/UploadFile','FileController@upload');//文件上传

        });
        //日志
        $router->group([
            'namespace' => 'Log',
            'middleware' => ['skipToken','checkHeader'],
            'prefix' => 'logs',
        ],function () use ($router)
        {
            $router->post('/openOrCloseApp','LogController@openOrCloseApp');//打开或者关闭app时上报
            $router->post('/readTime','LogController@readTime');//阅读数据上报
            $router->post('/listenTime','LogController@listenTime');//听书数据上报
            $router->post('/keepApp','LogController@keepApp');//留存数据上报
            $router->post('/advertClick','LogController@advertClick');//点击广告数据上报
            $router->post('/advertExpo','LogController@advertExpo');//广告曝光上报

        });




});
$router->group([
        'namespace' => 'V1_1\Basis',
        'prefix' => 'api/Basis',
    ],function () use ($router)
    {
        $router->get('/pushMessageBu','MessageController@pushMessageBu');//推送补发
    });
$router->group([
    'namespace' => 'V1_1\Log',
    'prefix' => 'api/logs',
],function () use ($router)
{
    $router->get('/dealShelfData','LogController@dealShelfData');//每天零时定时处理读友书架书籍数据
});


