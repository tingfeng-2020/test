<?php

namespace App\Console\Commands;


use App\Cache\MobileCache;
use App\Cache\ShelfCache;
use App\Http\Operate\Common\LoginOperate;
use App\Http\Service\LogService;
use App\Model\BookModel;
use App\Model\MembersModel;
use App\Model\TagModel;
use Illuminate\Console\Command;



class Test extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'make:test';


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '本地测试';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {


      //  $s = new LogService();
       // $s->dealShelfData();
        list($topic,$w,$s) = [['uid'=>1],2,3];
        print_r($w);
//        BookModel::query()->where('status1',1)
//            ->orderByRaw('RAND()')->limit(50)->pluck('id')->toArray();
        //echo PHP_EOL;
    }








}
