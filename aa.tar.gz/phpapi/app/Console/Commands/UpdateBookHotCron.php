<?php

namespace App\Console\Commands;


use App\Http\Service\LogService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;


class UpdateBookHotCron extends Command
{

    protected $name = 'UpdateBookHotCron';//命令名称


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '更新书籍人气值与在读人数值';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Log::info('UpdateBookHotCron='.date('Y-m-d H:i:s'));
        $s = new LogService();
        $s->updateBookHotAndRead();
    }








}
