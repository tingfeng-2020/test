<?php


namespace App\Exceptions;


use Illuminate\Support\Facades\Lang;
use Throwable;

class ApiExceptions extends \RuntimeException
{


    public function __construct($code,$message='',$replace=[],Throwable $previous = null)
    {
        $message =  empty($message) ? Lang::get("error.{$code }") : $message;
        if($replace){
            is_array($replace) or $replace = (array)$replace;
            $message = sprintf($message,...$replace);
        }
        parent::__construct($message, $code, $previous);
    }


}
