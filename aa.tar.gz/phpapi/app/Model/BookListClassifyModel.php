<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookListClassifyModel extends Model
{

    protected $table = 'book_list_classify';

}
