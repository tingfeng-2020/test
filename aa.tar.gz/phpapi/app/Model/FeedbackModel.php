<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

/**
 * 意见反馈模型
 * Class FeedbackModel
 * @package App\Model
 */
class FeedbackModel extends Model
{
    protected $table = 'feedback';
    public $timestamps = false;
    protected $fillable = ['member_id','content'];







}
