<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogListenModel extends  LogBaseModel
{
    protected $table = 'log_listen';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','member_id','os','channel','area','long_time','grade_day','createtime','start_time','end_time','book_id'
    ];
}
