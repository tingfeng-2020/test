<?php


namespace App\Model\Log;


use Illuminate\Database\Eloquent\Model;

class LogOpenModel extends  LogBaseModel
{
    protected $table = 'log_open';
    public $timestamps = false;
    protected $fillable = [
        'device', 'device_model','member_id','os','channel','area','status','createtime'
    ];
}
