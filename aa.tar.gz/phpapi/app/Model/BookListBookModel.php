<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookListBookModel extends Model
{
    protected $table = 'book_list_book';
}
