<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class BookChapterModel extends Model
{


    protected $table = 'book_chapter';
    public $timestamps = false;

}
