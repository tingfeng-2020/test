<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class OssEtagModel extends  Model
{

    protected $table = 'oss_etag';
    public $timestamps = false;
    protected $fillable = [
        'etag', 'path','file_size','createtime'
    ];
}

