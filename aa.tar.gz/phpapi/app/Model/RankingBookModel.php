<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class RankingBookModel extends Model
{

    protected $table = 'ranking_book';


}
