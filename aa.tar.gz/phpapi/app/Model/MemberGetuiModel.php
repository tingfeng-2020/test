<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

/**
 * 会员模型
 * Class MembersModel
 * @package App\Model
 */
class MemberGetuiModel extends Model
{

    protected $table = 'member_getui';
    public $timestamps = false;
    protected $fillable=['member_id','getui_cid','app_guid','os','device_model','last_time','createtime','status','exp'];

}
