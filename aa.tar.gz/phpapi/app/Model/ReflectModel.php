<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

/**
 * 举报模型
 * Class ReflectModel
 * @package App\Model
 */
class ReflectModel extends Model
{
    protected $table = 'reflect';
    public $timestamps = false;
}