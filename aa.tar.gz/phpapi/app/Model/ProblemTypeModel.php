<?php

/**
 * 广告
 */
namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class ProblemTypeModel extends Model
{

    protected $table = 'problem_type';
    public $timestamps = false;







}
