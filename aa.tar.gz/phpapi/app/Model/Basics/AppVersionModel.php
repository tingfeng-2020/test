<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class AppVersionModel extends Model
{
    protected $table = 'app_version';
}