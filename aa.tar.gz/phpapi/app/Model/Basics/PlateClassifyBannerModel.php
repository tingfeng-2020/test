<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class PlateClassifyBannerModel extends Model
{
    protected $table = 'plate_classify_banner';
}