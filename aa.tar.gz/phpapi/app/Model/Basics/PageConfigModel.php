<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class PageConfigModel extends Model
{
    protected $table = 'page_config';
    static $type = [1=>'用户协议',2=>'隐私政策',3=>'侵权申诉'];
    public $appends = ['type_name'];

    public function getTypeNameAttribute($key){
        $key = $this->attributes['type'] ?? 0;
        return self::$type[$key] ?? '无';
    }
}
