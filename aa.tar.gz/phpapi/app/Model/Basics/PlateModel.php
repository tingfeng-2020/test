<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class PlateModel extends Model
{
    protected $table = 'plate';
}