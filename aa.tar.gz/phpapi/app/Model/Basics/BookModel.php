<?php


namespace App\Model\Basics;


use Illuminate\Database\Eloquent\Model;

class BookModel extends Model
{
    protected $table = 'book';
}