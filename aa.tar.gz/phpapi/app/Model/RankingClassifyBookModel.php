<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class RankingClassifyBookModel extends Model
{

    protected $table = 'ranking_classify';


}
