<?php


namespace App\Model;


use Illuminate\Database\Eloquent\Model;

class NotifyUserModel extends Model
{

    protected $table = 'notify_user';
    public $timestamps = false;
    protected $fillable = [
        'member_id','notify_message_id','status','createtime','is_push','is_push_ios'
    ];

}
