<?php


namespace App\Traits;


trait BaseTrait
{
    /**
     * @param mixed ...$args
     * @return $this
     */
    public static function getInstance(...$args)
    {
        static $classMap = null;
        $class = static::class;
        $key = md5($class . json_encode($args));
        if (!isset($classMap[$key])) {
            $classMap[$key] = new $class(...$args);
        }
        return $classMap[$key];
    }
}
