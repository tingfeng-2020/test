<?php
namespace App\Traits;



use Cncal\Getui\Facades\Getui;

/**
 * 消息推送
 * Trait PushTrait
 * @package App\Traits
 */
trait PushTrait
{
    /**
     * 推送通知至指定用户
     * @param $data
     * @param $deviceId
     * @return $rep
     */
     public static function pushToUser($data)
     {
        return Getui::pushMessageToSingle($data);

     }
    /**
     *推送通知至指定用户列表
     * @param $data
     */
    public static function pushToListUser($data)
    {
       return Getui::pushMessageToList($data);
    }
    /**
     *推送通知至该应用的所有用户
     * @param $data
     */
     public static function pushToApp($data)
     {
       return Getui::pushMessageToApp($data);
     }


}
