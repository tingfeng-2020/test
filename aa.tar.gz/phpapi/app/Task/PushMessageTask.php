<?php


namespace App\Task;

use App\Cache\MemberCache;
use App\Http\Service\MessageService;
use App\Model\MemberGetuiModel;
use App\Model\NotifyMessageModel;
use App\Model\NotifyUserModel;
use App\Traits\PushTrait;
use Cncal\Getui\Sdk\Exception\GetuiException;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Support\Facades\Log;
error_reporting(E_ALL ^ E_DEPRECATED);
class PushMessageTask  extends  Task
{
    use PushTrait;
    private $data;
    public function __construct($pushData=[])
    {
        $this->data = $pushData;
    }

    public function handle()
    {
        try {
            Log::info('进入推送data=',$this->data);
            if ( !empty($this->data) ) {
                  Log::info('进入$this->data');
                        $transmission_content = json_encode($this->data);
                        $is_send_ios = 1;
                        $is_send = 1;
                        if ($this->data['os'] ==1) { //安卓
                            $da = [
                                'template_type' => 4,//安卓用1模版(改为4 透传模版)
                                'template_data' => [
                                    'is_ios' => false, // 是否支持 ios （默认不支持）
                                    'title' => $this->data['title'], // 通知标题，string(40), 必填
                                    'text'  => $this->data['content'], // 通知内容，string(600), 必填
                                    'logo'  => 'pushImgUrl', // 通知图标名称，string(40), 必填
                                    'logo_url'  => env('PUSH_IMG') ? env('MEDIA_HOST').env('PUSH_IMG'): 'https://rayman-read-book.oss-cn-hongkong.aliyuncs.com/media/defaults/push_icon.jpg', // 通知图标url地址，string(100), 必填
                                    'transmission_type'    => 2, // 是否立即启动应用：1 立即启动 2 等待客户端自启动，必填
                                    'transmission_content' => $transmission_content, // 透传内容，不支持转义字符，string(2048), 必填
                                ],
                                'cid' => '', // 推送通知至指定用户时填写
                                'cid_list' => $this->data['deviceId'], // 推送通知至指定用户列表时填写
                            ];
                            Log::info(date('m-d H:i').'安卓推送data=',$da);


                            try {
                                //改为多端登录多端推送
                                $res = self::pushToListUser($da);
                                $is_send =2;
                                if (empty($res) || $res['result'] !='ok'){
                                    $is_send = 3;
                                    Log::info(date('m-d H:i').'推送失败00',$da);
                                }
                                Log::info(date('m-d H:i').'推送成功',$res);
                            }catch (\Exception $e){
                                //推送失败
                                Log::info(date('m-d H:i').'推送失败01'.$e->getMessage(),$da);
                                $is_send =3;

                            }catch (GetuiException $e){
                                //推送失败
                                Log::info(date('m-d H:i').'推送失败02'.$e->getMessage(),$da);
                                $is_send =3;

                            }


                        }
                        if ($this->data['os'] ==2) { //ios
                            $da = [
                                'template_type' => 4,//ios用4模版
                                'template_data' => [
                                    'is_ios' => true, // 是否支持 ios （默认不支持）
                                    'title' => $this->data['title'], // 通知标题，string(40), 必填
                                    'text'  => $this->data['content'], // 通知内容，string(600), 必填
                                    'logo'  => 'pushImgUrl', // 通知图标名称，string(40), 必填
                                    'logo_url'  => env('PUSH_IMG') ? env('MEDIA_HOST').env('PUSH_IMG'): 'https://rayman-read-book.oss-cn-hongkong.aliyuncs.com/media/defaults/push_icon.jpg', // 通知图标url地址，string(100), 必填
                                    'transmission_type'    => 2, // 是否立即启动应用：1 立即启动 2 等待客户端自启动，必填
                                    'custom_msg'=> ['data'=>$this->data],
                                    'transmission_content' => $transmission_content, // 透传内容，不支持转义字符，string(2048), 必填
                                ],
                                'cid' => '', // 推送通知至指定用户时填写
                                'cid_list' => $this->data['deviceId'], // 推送通知至指定用户列表时填写
                            ];
                            Log::info(date('m-d H:i').'ios推送data=',$da);


                            try {
                                //改为多端登录多端推送

                                $res = self::pushToListUser($da);
                                $is_send_ios = 2;
                                if (empty($res) || $res['result'] !='ok'){
                                    Log::info(date('m-d H:i').'补发推送失败00',$da);
                                    //推送失败
                                    $is_send_ios = 3;
                                }

                                Log::info(date('m-d H:i').'推送成功',$res);
                            }catch (\Exception $e){
                                //推送失败
                                Log::info(date('m-d H:i').'推送失败01'.$e->getMessage(),$da);
                                $is_send_ios = 3;
                            }catch (GetuiException $e){
                                //推送失败
                                Log::info(date('m-d H:i').'推送失败02'.$e->getMessage(),$da);
                                $is_send_ios = 3;

                            }


                        }
                        //记录发送状态
                        NotifyUserModel::query()->where('notify_message_id',$this->data['id'])->update(['is_push_ios'=>$is_send_ios,'is_push'=>$is_send]);

                //$newData = $server->getMessage();
                //$this->data = !empty($newData)? json_decode($newData,true):[];
            } else{
                $server = new MessageService();
                $server->messagePush($this->data);
            }
            unset($this->data);//释放变量
        }catch (\Exception $e){
            Log::info(date('m-d H:i').'推送失败'.$e->getMessage());
            $server = new MessageService();
            $server->messagePush($this->data);
        }

    }











}
