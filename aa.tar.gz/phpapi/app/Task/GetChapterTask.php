<?php


namespace App\Task;


use App\Http\Service\ChapterService;
use App\Http\Service\MessageService;
use App\Model\BookChapterModel;
use App\Model\BookModel;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class GetChapterTask extends Task
{
    private $data;

    public function __construct($data)
    {
        $this->data = $data;
    }

    public function handle()
    {
        $model = BookChapterModel::query();
        $obj = new MessageService();

        if (!isset($this->data['flag'])) {
            if (!$model->where(['sequence' => $this->data['sequence'], 'book_id' => $this->data['book_Id']])->exists()) {
                DB::beginTransaction();
                $id = $model->insertGetId([
                    'name' => $this->data['name'],
                    'book_id' => $this->data['book_Id'],
                    'sequence' => $this->data['sequence'],
                ]);
                try {
                    $table = explode('/', $this->data['path']);
                    $result = DB::connection('mongodb')->table($table[0])->find($table[1]);
                    $service = new ChapterService();
                    if ($service->uploadChapter($id, $this->data['name'], $this->data['sequence'], $result['content'])) {
                        DB::commit();
                        $obj->pushBookInfo($this->data['book_Id']);
                        //这里要推送
                        return;
                    }
                    DB::rollBack();
                    //修改书籍最后更新时间
                    BookModel::query()->find($this->data['book_Id'])->update(['last_time' => date('Y-m-d H:i:s')]);
                } catch (\Exception $exception) {
                    Log::info('书籍入库错误' . $exception->getFile() . $exception->getCode() . $exception->getMessage());
                    DB::rollBack();
                }
            }

        } else {
            $obj->pushBookInfo($this->data['book_Id']);

        }


    }

}
