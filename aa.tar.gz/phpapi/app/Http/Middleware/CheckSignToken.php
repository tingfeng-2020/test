<?php


namespace App\Http\Middleware;

use App\Exceptions\ApiExceptions;
use Closure;

/**
 * 验证签名Token
 * Class CheckSignToken
 * @package App\Http\Middleware
 */
class CheckSignToken
{

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!$request->hasHeader('Signtoken') || !$request->hasHeader('Timestamp')) {
            throw new ApiExceptions(1001);
        }
        $timestamp = trim($request->Header('Timestamp'));
        $sign_token = trim($request->Header('Signtoken'));
        if((time() - $timestamp) > env('API_TIMEOUT')){
            throw new ApiExceptions(1002);
        }

        $key = md5($timestamp.env('APP_KEY'));
        if ( $key != $sign_token) {
            throw new ApiExceptions(1003);
        }

        return $next($request);
    }
}
