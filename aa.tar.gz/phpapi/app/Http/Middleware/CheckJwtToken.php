<?php

namespace App\Http\Middleware;

use App\Cache\TokenCache;
use App\Exceptions\ApiExceptions;
use App\Http\Service\TokenService;
use Illuminate\Http\Request;

/**
 * JWT Token验证类
 * Class CheckJwtToken
 * @package App\Http\Middleware
 */
class CheckJwtToken
{
    public function handle(Request $request, \Closure $next, $skip = false)
    {
        //判断处理
        if ($skip == 'skip' && !$request->header('Authorization')) {
            $request->offsetUnset('uid');
            return $next($request);
        } elseif (!$request->header('Authorization')) {
            throw new ApiExceptions(401);//
        }

        $uid = TokenCache::getAccessToken($request->header('Authorization'));

        if(!$uid)
        {
            TokenCache::delAccessToken($request->header('Authorization'));
            throw new ApiExceptions(403);//
        }

        $result = TokenService::checkToken($request->header('Authorization'));

        if(!$result){
            TokenCache::delAccessToken($request->header('Authorization'));
            throw new ApiExceptions(403);//
        }

        //权限判断
        if($result->scopes != 1)
        {
            throw new ApiExceptions(403);//
        }

        if(!$result->uid || $result->uid != $uid)
        {
            TokenCache::delAccessToken($request->header('Authorization'));
            throw new ApiExceptions(403);//
        }

        $request->offsetSet('uid',$result->uid);

       return $next($request);
    }
}
