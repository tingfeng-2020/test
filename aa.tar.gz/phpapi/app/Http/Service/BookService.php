<?php


namespace App\Http\Service;


use App\Cache\AuthorCache;
use App\Cache\BookByClassCache;
use App\Cache\BookByTagCache;
use App\Cache\BookCache;
use App\Cache\BookInClassCache;
use App\Cache\BookRedCache;
use App\Cache\BookTagCache;
use App\Cache\ClassifyCache;
use App\Cache\MemberCache;
use App\Cache\SearchCache;
use App\Cache\ShelfCache;
use App\Exceptions\ApiExceptions;
use App\Model\BookModel;
use App\Model\BookShelfModel;
use App\Tools\Redis;
use Illuminate\Support\Facades\Log;


class BookService extends BaseService
{


    /**
     *
     * 获取书籍详情
     * @param $id
     * @return array
     * @throws \JsonException
     */

    public function getBookById($id): array
    {

        $return = [];
        $result = BookCache::getInstance($id)->getDetail();
        if ($result) {

            //热度
            $result['hot'] = round($result['hot'] / 10000, 1);
            //再读人数
            $result['on_read'] = round($result['on_read'] / 10000, 1);
            //作者
            $result['author'] = AuthorCache::getInstance($result['author_id'])->getDetail();
            //分类
            $result['classify'] = $this->getBookNameById($id);
            //标签
            $result['tag'] = BookTagCache::getInstance($id)->getDetail() ?: [];

            $return = $result;
        }
        return $return;
    }


    /**
     * 获取书籍分类id
     * @param $id
     * @return mixed|null
     *
     */
    public function getBookTypeId($id)
    {
        return BookInClassCache::getInstance($id)->getDetail();

    }


    /**
     * 获取书籍分类名称
     * @param $id
     * @return array
     */
    public function getBookNameById($id): array
    {
        $classify = ClassifyCache::getInstance('All')->getDetail();
        $typeId = $this->getBookTypeId($id);
        $return = [];
        if (isset($typeId) && !empty($typeId)) {
            foreach ($typeId as $k => $v) {
                $class = isset($classify[$v]) ? json_decode($classify[$v], true) : '';
                if (empty($class['name']) || empty($v)) {
                    continue;
                }
                $return[] = ['id' => $v, 'name' => $class['name'] ?? ''] ?? [];
            }
        }
        return $return;
    }

    /**
     *
     * 搜索书籍
     * @param $name
     * @param $page
     * @param $pageSize
     * @return mixed
     *
     */
    public function search($name, $page, $pageSize)
    {

        $result = SearchCache::getInstance($name)->getDetail();
        $return = [
            'totalCount' => 0,
            'pageIndex' => $page,
            'pageSize' => $pageSize,
            'gridData' => [],
            'pageCount' => 0,
        ];
        if ($result) {
            $return['totalCount'] = count($result);
            $book = array_slice($result, ($page - 1) * $pageSize, $pageSize);
            foreach ($book as $k => $v) {
                try {
                    $return['gridData'][] = $this->getBookById($v);
                } catch (ApiExceptions $exception) {
                    continue;
                }
            }
            $return['pageCount'] = ceil(count($result) / $pageSize);

        }


        return $return;


    }

    /**
     * 根据分类获取书籍
     * @param $classId
     * @param int $pageIndex
     * @param int $pageSize
     * @return array
     */

    public function getBookByClass($classId, $pageIndex = 1, $pageSize = 10): array
    {
        $result = BookByClassCache::getInstance([$classId, $pageIndex, $pageSize])->getDetail();
        $bookInfo = [];
        if ($result) {
            foreach ($result as $k => $v) {
                try {
                    $bookInfo[] = $this->getBookById($v);
                } catch (ApiExceptions $exception) {
                    continue;
                }
            }
        }
        return [
            'page_index' => (int)$pageIndex,
            'page_size' => (int)$pageSize,
            'grid_data' => $bookInfo
        ];
    }

    /**
     * 根据分类随机获取书籍
     * @param $classId
     * @return array
     *
     */
    public function getBookSimilar($classId): array
    {
        $pageIndex = mt_rand(1, 20);

        $result = $this->getBookByClass($classId, $pageIndex, 8);

        if (empty($result) && $pageIndex === 1) {
            $result = [];
        } elseif (empty($result)) {
            $result = $this->getBookSimilar($classId);
        }
        unset($result['page_index'], $result['page_size']);
        return $result;
    }


    /**
     * 分享
     * @param $bookId
     * @return array
     */
    public function share($bookId): array
    {
        $result = $this->getBookById($bookId);
        return [
            'id' => $result['id'],
            'book_name' => $result['book_name'],
            'author' => $result['author'],
            'book_imgurl' => $result['book_imgurl'],
            'book_des' => $result['book_des'],
            'share_Link' => env('BOOK_SHARE') . $bookId
        ];

    }

    /**
     * 热门书籍
     * @param $count
     * @return array
     */
    public function hotBook($count): array
    {
        $re = BookModel::query()->where('status', 1)->orderByRaw('RAND()')->limit($count)->get(['id'])->toArray();
        $return = [];
        foreach ($re as $k => $v) {
            $book = $this->getBookById($v['id']);
            if ($book) {
                $return[] = $book;
            }

        }
        return $return;

    }


    /**
     * 根据标签获取书籍
     * @param $tag
     * @param int $pageIndex
     * @param int $pageSize
     * @return array
     */
    public function getBookByTag($tag, $pageIndex = 1, $pageSize = 10): array
    {

        $return = [
            'page_index' => $pageIndex,
            'page_size' => $pageSize,
            'grid_data' => []
        ];
        $result = BookByTagCache::getInstance([$tag, $pageIndex, $pageSize])->getDetail();
        foreach ($result as $k) {
            try {
                $return['grid_data'][] = $this->getBookById($k);
            } catch (ApiExceptions $e) {
                continue;
            }
        }

        return $return;
    }


    public function getBookByLike($device, $pageIndex = 1, $pageSize = 10, $uid = null, $classId = null)
    {

        $key = 'BOOK_BY_LIKE_ZSET:';
        //  \xhprof_enable(XHPROF_FLAGS_MEMORY + XHPROF_FLAGS_CPU + XHPROF_FLAGS_NO_BUILTINS);
        $return = [
            'page_index' => $pageIndex,
            'page_size' => $pageSize,
            'grid_data' => []
        ];
        $class = [];
        //登陆情况下获取书架的书
        $bookShelf = [];
        if ($uid) {
            $key .= $uid;
            $bookShelf = ShelfCache::getInstance($uid)->getBookShelfList();
            if (!$bookShelf) {
                $model = BookShelfModel::query()->where('member_id', $uid)->pluck('book_id');
                if ($model) {
                    $bookShelf = $model->toArray();
                }
            }
        } elseif ($device) {
            $key .= $device;
            $bookShelf = BookRedCache::getInstance([$device, 2])->getDetail();
        }


        if ($bookShelf) {
            foreach ($bookShelf as $k) {

                if ($re = $this->getBookTypeId($k)) {
                    $class[] = $re;
                }
            }
        }
        if ($class && is_array($class)) {
            $arr = array_count_values(array_merge(...$class));

            $redis = Redis::getInstance();
            $start = ($pageIndex - 1) * $pageSize;
            $end = $start + $pageSize - 1;
            //没有值去取
            if (!$re = $redis->zRangeByScore($key, $start, $end)) {
                $bookInfo = [];
                //计算所有书架分类占比
                $count = array_sum($arr);

                $cardinality = ceil(200 / $count);

                foreach ($arr as $k => $v) {
                    $bookInfo[] = BookByClassCache::getInstance([$k, 1, $v * $cardinality])->getDetail();
                }
                $result = array_merge(...$bookInfo);
                $result = array_unique($result);
                $keys = array_search('max_count', $result, true);
                if ($key) {
                    unset($result[$keys]);
                }
                shuffle($result);

                $info = [];
                foreach ($result as $k => $v) {
                    $info[] = $k;
                    $info[] = $v;
                }
                $redis->zAdd($key, ...$info);
                $redis->expire($key, 600);
                $chunk = array_chunk($result, $pageSize);
                $re = $chunk[0] ?? [];
            }

            if ($re && is_array($re)) {
                foreach ($re as $k) {
                    if (in_array($k, $bookShelf, true)) {
                        continue;
                    }
                    try {
                        $return['grid_data'][] = $this->getBookById($k);
                    } catch (\Exception $e) {
                        continue;
                    }
                }
            }
            //书架和阅读记录都没有  根据传过来的分类去取值
        } elseif ($classId) {
            $return = $this->getBookByClass($classId, $pageIndex, $pageSize);

        }
        //如果没有值 去随机取d
        if (empty($return) || !isset($return['grid_data']) || empty($return['grid_data'])) {
            $classService = new ClassService();
            $classId = $classService->getClassify();
            if ($classId) {
                $return = $this->getBookByClass($classId[0]->id, $pageIndex, $pageSize);
            }

        }

        return $return;

    }


}
