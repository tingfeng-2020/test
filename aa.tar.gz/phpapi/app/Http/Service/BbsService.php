<?php


namespace App\Http\Service;


use App\Cache\BbsCache;
use App\Cache\BbsReplyCache;
use App\Cache\MemberCache;
use App\Exceptions\ApiExceptions;
use App\Model\Bbs\BbsLogModel;
use App\Model\Bbs\BbsReplyModel;
use App\Model\Bbs\BbsTopicModel;
use App\Model\BookModel;
use App\Model\MembersModel;
use App\Model\NotifyMessageModel;
use App\Model\NotifyUserModel;
use App\Task\SaveBbsDbTask;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;


class BbsService extends BaseService
{
    protected $topicKey;//评论列表key:book_id.tid
    protected $replyKey;//回复列表key:book_id.tid.rid
    protected $cache = true;//是否使用redis库存储数据
    const LIMIT_TIME = 30;//发言限制时间(秒)

    /**
     * 评论列表
     * @param $param
     * @return bool|mixed|string
     */
    public function topicList($param)
    {
        $pageSize = $param['page_size']??10;
        $book_id = $param['book_id'];
        $uid = $param['uid']??0;
        if ($this->cache) {
            //开启redis存储与缓存
            $pageIndex = $param['page_index']??1;
            return $this->redisTopicList($book_id,$uid, $pageSize, $pageIndex);
        } else {
            //直接mysql存储方式
            return $this->mysqlTopicList($book_id,$uid,$param);
        }

    }

    /**
     * 评论详情
     * @param $param
     * @return bool|mixed|string
     */
    public function replyInfo($param)
    {
        $tid = $param['tid'];
        $book_id = BbsTopicModel::query()->where('tid',$tid)->value('book_id');
        $pageIndex = $param['page_index']??1;
        $pageSize = $param['page_size']??20;
        $uid = $param['uid']??0;
        if ($this->cache) {
            //开启redis存储与缓存
            return  $this->redisReplyList($book_id,$tid,$uid,$pageSize,$pageIndex);
        } else {
            //直接mysql存储方式
            return $this->mysqlReplyList($tid,$uid,$pageSize,$pageIndex);
        }

    }
    protected function redisTopicList($book_id, $uid, $pageSize, $pageIndex)
    {
        $count = BbsCache::getInstance($book_id)->getTotal();
        $string_key = $this->key['BOOK_TOPIC'].':BOOK:'.$book_id.':PAGE:'.$pageIndex.':PAGE_SIZE:'.$pageSize.':TOTAL:'.$count;
        if ($count > 0 ) {
            //redis中有数据
            if ($rd = $this->redis->get($string_key)) {
                //字符序列化缓存有数据直接返回
                $rd = json_decode($rd,true);
                $this->dealRdList('BbsCache',$book_id,$uid,$rd);
                return $rd;
            } else {
                //字符序列化缓存没有数据 从redis中获取列表数据并格式化处理
                $list = $this->dealRd($book_id,$uid,$pageSize,$pageIndex);
                $person =  BbsTopicModel::query()->where('book_id',$book_id)->count(DB::Raw('DISTINCT member_id'));
                $res['total'] = BbsCache::getInstance($book_id)->getTotal();
                $res['last_page'] = ceil($res['total']/$pageSize);
            }

        } else {
            //redis中没数据-取mysql数据并更新到redis
            $count = BbsTopicModel::query()->where('book_id',$book_id)->count(DB::Raw('DISTINCT member_id'));
            if ($count > 0) {
                $res = BbsTopicModel::query()->from('bbs_topic as a')
                    ->leftJoin('members as b','b.id','=','a.member_id')
                    ->where(['book_id'=>$book_id])
                    ->selectRaw('a.tid,a.member_id,a.comments,a.likes,a.message,a.title,a.createtime,b.icon,IFNULL(b.nickname,b.account) as nick_name')
                    ->orderBy('a.createtime','desc')
                    ->paginate($pageSize,['*'],'page_index')->toArray();
                foreach ($res['data'] as &$v) {
                    //记录更新到redis
                    BbsCache::getInstance($book_id)->addBbs($v['tid'],strtotime($v['createtime']));
                    $has_like =0;
                    $is_own = 0;
                    if ($uid) {
                        $has_like = BbsLogModel::query()->where(['re_id'=>$v['tid'],'type'=>1,'member_id'=>$uid,'re_table'=>'bbs_topic'])->count('id');
                        $is_own = $v['member_id'] == $uid ?1:0;
                        if ($has_like) BbsCache::getInstance($book_id.'.'.$v['tid'])->addLog($uid);

                    }
                    $v['avatar'] = !empty($v['icon'])? env('MEDIA_HOST').$v['icon']: env('MEDIA_HOST').env('DEFAULT_HEADER');
                    $v['nickname'] = $v['nick_name'];
                    $v['message'] = str_resolve($v['message']);
                    $v['title'] = str_resolve($v['title']);
                    $v['is_like']  = $has_like;
                    $v['rid']  = 0;
                    $v['is_own']  = $is_own;
                    $v['createtime'] = countDownTime(strtotime($v['createtime']));
                }
                unset($v);
                $person = $count;
                $list = $res['data'];
                BbsCache::getInstance($book_id)->addTotal($res['total'],true);
            }
            $total = $res['total']??0;
            $string_key = $this->key['BOOK_TOPIC'].':BOOK:'.$book_id.':PAGE:'.$pageIndex.':PAGE_SIZE:'.$pageSize.':TOTAL:'.$total;

        }
        $data['list'] = $list??[];
        $data['count'] = $person??0;
        $param['pageIndex'] = $param['page_index']??1;
        $param['pageSize'] = $pageSize;
        $data['page'] = pageDeal($param,$res??[],'desc','createtime');
        //序列化字符到redis缓存
        $this->redis->setex($string_key,6000,json_encode($data));
        return $data;
    }
    protected function mysqlTopicList($book_id, $uid, $param)
    {
        $model = BbsTopicModel::query()->from('bbs_topic as a')
            ->leftJoin('members as b','b.id','=','a.member_id')
            ->where(['book_id'=>$book_id]);
        $total = $model->count('tid');
        //暂时关闭评分统计
        // $data = $this->getScore($param['book_id'],$param['uid']??0);
        if ($total > 0) {
            $res = $model->selectRaw('a.tid,a.member_id,a.comments,a.likes,a.message,a.title,a.createtime,b.icon,IFNULL(b.nickname,b.account) as nick_name')
                ->orderBy('a.createtime','desc')
                ->paginate($param['page_size']??10,['*'],'page_index')->toArray();
            foreach ($res['data'] as &$v) {
                $has_like =0;
                $is_own = 0;
                if ($uid){
                    $has_like = BbsLogModel::query()->where(['re_id'=>$v['tid'],'type'=>1,'member_id'=>$uid,'re_table'=>'bbs_topic'])->count('id');
                    $is_own = $v['member_id'] == $uid ?1:0;
                }
                $v['avatar'] = !empty($v['icon'])? env('MEDIA_HOST').$v['icon']: env('MEDIA_HOST').env('DEFAULT_HEADER');
                $v['nickname'] = $v['nick_name'];
                $v['message'] = str_resolve($v['message']);
                $v['title'] = str_resolve($v['title']);
                $v['is_like']  = $has_like;
                $v['rid']  = 0;
                $v['is_own']  = $is_own;
                $v['createtime'] = countDownTime(strtotime($v['createtime']));
            }
            unset($v);
            $person =  BbsTopicModel::query()->where('book_id',$book_id)->count(DB::Raw('DISTINCT member_id'));
            $list = $res['data'];
        }

        $data['list'] = $list??[];
        $data['count'] = $person??0;
        $data['page'] = pageDeal($param,$res??[],'desc','createtime');
        return $data;
    }
    protected function mysqlReplyList($tid,$uid,$pageSize,$pageIndex)
    {
        $topic = BbsTopicModel::query()->from('bbs_topic as a')
            ->leftJoin('members as b','a.member_id','=','b.id')
            ->where('a.tid',$tid)
            ->selectRaw('a.*,b.icon,IFNULL(b.nickname,b.account) as nick_name,likes')
            ->first();

        if (empty($topic)) throw new ApiExceptions(1104);
        $topic_has_like = 0;
        $is_own = 0;
        if ($uid){
            $topic_has_like = BbsLogModel::query()->where(['re_id'=>$tid,'type'=>1,'member_id'=>$uid,'re_table'=>'bbs_topic'])->count('id');
            $is_own = $uid == $topic->member_id?1:0;
        }
        $member = MembersModel::query()->where('id',$topic->member_id)->first(['icon','nickname','account']);

        $data['topic_info'] = $this->topicInfo($topic,$member,$topic_has_like,$is_own);

        $count = BbsReplyModel::query()->where('tid',$tid)->count();

        if ($count >0) {
            $res = BbsReplyModel::query()->from('bbs_reply as a')
                ->leftJoin('members as b','a.member_id','=','b.id')
                ->where(['a.tid'=>$tid])
                ->selectRaw('a.rid,a.tid,a.member_id,a.message,a.likes,a.comments,a.createtime,b.icon,IFNULL(b.nickname,b.account) as nick_name ')
                ->orderBy('a.rid','desc')
                ->paginate($pageSize,['*'],'page_index')->toArray();
            foreach ($res['data'] as &$v) {
                BbsReplyCache::getInstance($this->topicKey)->addBbs($v['rid'],strtotime($v['createtime']));
                $has_like = 0;
                $is_own = 0;
                if ($uid){
                    $has_like = BbsLogModel::query()->where(['re_id'=>$v['rid'],'type'=>1,'member_id'=>$uid,'re_table'=>'bbs_reply'])->count('id');
                    $is_own = $v['member_id'] == $uid ? 1:0;
                }
                $v['avatar'] = !empty($v['icon'])? env('MEDIA_HOST').$v['icon']: env('MEDIA_HOST').env('DEFAULT_HEADER');
                $v['nickname'] = $v['nick_name'];
                $v['is_like']  = $has_like;
                $v['is_own']  = $is_own;
                $v['createtime'] = countDownTime(strtotime($v['createtime']));
            }
            unset($v);
            $list = $res['data'];
        }
        $data['list'] = $list;
        $data['count'] = $res['total'];
        $param['pageIndex'] = $pageIndex;
        $param['pageSize'] = $pageSize;
        $data['page'] = pageDeal($param,$res,'desc','createtime');

        return $data;
    }
    protected function dealRdList($class,$book_id,$uid,&$rd)
    {
        foreach ($rd['list'] as &$v) {
            $has_like =0;
            $is_own = 0;
            $key = $class == 'BbsCache'? $book_id.'.'.$v['tid']: $book_id.'.'.$v['tid'].'.'.$v['rid'];
            $bbs = $class == 'BbsCache'? BbsCache::getInstance($key):BbsReplyCache::getInstance($key);
            if ($uid){
                $has_like = $bbs->is_like($uid);
                $is_own = $v['member_id'] == $uid ?1:0;
            }
            $member = MemberCache::getInstance($v['member_id']);
            $v['avatar'] = !empty($member->icon)? env('MEDIA_HOST').$member->icon: env('MEDIA_HOST').env('DEFAULT_HEADER');
            $v['nick_name'] = $member->nickname ?? $member->account;
            $v['comments'] = $bbs->comments;
            $v['likes'] = $bbs->likes;
            $v['is_like']= $has_like;
            $v['is_own'] = $is_own;
        }
        unset($v);
        return $rd;
    }
    //redis中获取列表数据并格式化处理
    protected function dealRd($book_id,$uid,$pageSize,$pageIndex)
    {
        $startRow = ($pageIndex - 1) * $pageSize;
        $res =  BbsCache::getInstance($book_id)->getBbsList($startRow,$pageSize);
        $rd =[];
        foreach ($res as $v) {
            $bbs = BbsCache::getInstance($book_id.'.'.$v);
            $has_like =0;
            $is_own = 0;
            if ($uid){
                $has_like = $bbs->is_like($uid);
                $is_own = $bbs->member_id == $uid ?1:0;
            }
            $rd[]=[
                'avatar'=>!empty($bbs->icon)? env('MEDIA_HOST').$bbs->icon: env('MEDIA_HOST').env('DEFAULT_HEADER'),
                'comments'=> $bbs->comments,
                'createtime'=>countDownTime(strtotime($bbs->createtime)),
                'is_like'=> $has_like,
                'is_own'=> $is_own,
                'likes'=> $bbs->likes,
                'member_id'=>$bbs->member_id,
                'message'=>str_resolve($bbs->message),
                'nick_name'=>$bbs->nick_name,
                'rid'=>0,
                'tid'=>$bbs->tid,
                'title'=>str_resolve($bbs->title),
            ];
        }
        return $rd;
    }
    protected function dealReplyRd($book_id,$tid,$uid,$res=[])
    {
        $r_list =[];
        $keys = $book_id.'.'.$tid;
        foreach ($res as $v) {
            $key = $keys.'.'.$v;
            $bbs = BbsReplyCache::getInstance($key);
            $has_like = 0;
            $is_own = 0;
            if ($uid){
                $has_like = BbsReplyCache::getInstance($key)->is_like($uid);
                $is_own =$bbs->member_id == $uid ? 1:0;

            }
            $r_list[]=[
                'avatar'=>!empty($bbs->icon)? env('MEDIA_HOST').$bbs->icon: env('MEDIA_HOST').env('DEFAULT_HEADER'),
                'comments'=> BbsReplyCache::getInstance($key)->getComments(),
                'createtime'=>countDownTime(strtotime($bbs->createtime)),
                'is_like'=>$has_like,
                'is_own'=>$is_own,
                'likes'=> $bbs->likes,
                'member_id'=>$bbs->member_id,
                'message'=>str_resolve($bbs->message),
                'nick_name'=>$bbs->nick_name,
                'rid'=>$bbs->rid,
                'tid'=>$tid,
                'title'=>str_resolve($bbs->title),
            ];
        }
        return $r_list;

    }

    /**
     * 评论详情-回复列表
     * @param $topic
     * @param $member
     * @param int $topic_has_like
     * @param int $is_own
     * @return mixed
     */
    protected function topicInfo($topic,$member,$topic_has_like=0,$is_own=0)
    {
        $tInfo['tid'] = $topic->tid;
        $tInfo['message'] = $topic->message;
        $tInfo['title'] = $topic->title;
        $tInfo['nick_name'] = $member->nickname??$member->account;
        $tInfo['likes'] = $topic->likes;
        $tInfo['comments'] = $topic->comments;
        $tInfo['is_like'] = $topic_has_like;
        $tInfo['is_own']  = $is_own;
        $tInfo['avatar'] = !empty($member->icon) ? env('MEDIA_HOST').$member->icon : env('MEDIA_HOST').env('DEFAULT_HEADER');
        $tInfo['createtime'] =  countDownTime(strtotime($topic->createtime));
        return $tInfo;
    }

    //评分处理
    public function getScore($book_id, $member_id =0)
    {
        if (empty($book_id)) return;
        $number_parts = BbsTopicModel::query()->where('book_id',$book_id)->where('score','>',0)->count(DB::Raw('distinct `member_id`'));
        if (empty($number_parts)){
            return ['score_avg'=>10.0,'number_parts'=>0,'score_list'=>['one'=>0,'two'=>0,'three'=>0,'four'=>0,'five'=>0],'person_score'=>0];
        }
        $total = $number_parts??1;
        $sum = BbsTopicModel::query()->where('book_id',$book_id)->selectRaw('SUM(`score`) AS sum_score, COUNT(member_id) as nums')->first();
        $score_avg = sprintf("%1\$.1f", $sum->sum_score/$sum->nums);
        $score_list =['one'=>[0.1,2.9],'two'=>[3,4.9],'three'=>[5,6.9],'four'=>[7,8.9],'five'=>[9,10]];
        foreach ($score_list as $k=>$v) {
            $count = BbsTopicModel::query()->where('book_id',$book_id)
                ->whereBetween('score',$v)
                ->count(DB::Raw('distinct `member_id`'));
            $score_list[$k] = round($count/$total,2);

        }
        $person_score = 0;
        if ($member_id) $person_score = BbsTopicModel::query()->where(['book_id'=>$book_id,'member_id'=>$member_id])->value('score');
        return compact('score_avg','number_parts','score_list','person_score');

    }
    //redis数据回复列表
    protected function redisReplyList($book_id,$tid,$uid,$pageSize,$pageIndex)
    {
            $topic = BbsCache::getInstance($book_id.'.'.$tid);
            $this->topicKey = $book_id.'.'.$tid;
            if (empty($topic)) throw new ApiExceptions(1104);
            $count = BbsReplyCache::getInstance($this->topicKey)->getTotal();
            $string_key = $this->key['BOOK_REPLAY'].':REPLAY_ID:'.$this->topicKey.':PAGE_SIZE:'.$pageSize.":pageIndex:".$pageIndex.':TOTAL:'.$count;
            $is_own = 0;
            $topic_has_like = 0;
            if ($uid){
                $topic_has_like = BbsCache::getInstance($this->topicKey)->is_like($uid);
                $is_own = $uid == $topic->member_id?1:0;
            }
            if ($rd = $this->redis->get($string_key)) {
                //序列化字符缓存中有数据 直接返回数据
                $rd = json_decode($rd,true);
                $member = MemberCache::getInstance($topic->member_id);
                $bbs = BbsCache::getInstance($this->topicKey);
                $rd['topic_info']['is_like'] = $topic_has_like;
                $rd['topic_info']['is_own'] = $is_own;
                $rd['topic_info']['likes'] = $bbs->likes;
                $rd['topic_info']['comments'] = $bbs->comments;
                $rd['topic_info']['nick_name'] = $member->nickname??$member->account;
                $rd['topic_info']['avatar'] = !empty($member->icon) ? env('MEDIA_HOST').$member->icon : env('MEDIA_HOST').env('DEFAULT_HEADER');
                //列表数据格式化处理
                $this->dealRdList('BbsReplyCache',$book_id,$uid,$rd);
                return $rd;
            }
            $member = MemberCache::getInstance($topic->member_id);
            $data['topic_info'] = $this->topicInfo($topic,$member,$topic_has_like,$is_own);
            if ($count > 0) {
                $startRow = ($pageIndex - 1) * $pageSize;
                $res =  BbsReplyCache::getInstance($this->topicKey)->getBbsList($startRow,$pageSize);
                $list = $this->dealReplyRd($book_id,$tid,$uid,$res);
                $res['total'] = BbsReplyCache::getInstance($this->topicKey)->getTotal();
                $res['last_page'] = ceil($res['total']/$pageSize);

            } else {
                $count = BbsReplyModel::query()->where('tid',$tid)->count();
                if ($count >0) {
                    $pageSize = $param['page_size']??10;//getPageSize($param);
                    $res = BbsReplyModel::query()->from('bbs_reply as a')
                        ->leftJoin('members as b','a.member_id','=','b.id')
                        ->where(['a.tid'=>$tid])
                        ->selectRaw('a.rid,a.tid,a.member_id,a.message,a.likes,a.comments,a.createtime,b.icon,IFNULL(b.nickname,b.account) as nick_name ')
                        ->orderBy('a.rid','desc')
                        ->paginate($pageSize,['*'],'page_index')->toArray();
                    foreach ($res['data'] as &$v) {
                        $this->replyKey = $this->topicKey.'.'.$v['rid'];
                        //回复评论缓存
                        BbsReplyCache::getInstance($this->topicKey)->addBbs($v['rid'],strtotime($v['createtime']));
                        $has_like = 0;
                        $is_own = 0;
                        if (isset($param['uid']) && $param['uid']){
                            $uid = $param['uid'];
                            $has_like = BbsLogModel::query()->where(['re_id'=>$v['rid'],'type'=>1,'member_id'=>$uid,'re_table'=>'bbs_reply'])->count('id');
                            $is_own = $v['member_id'] == $uid ? 1:0;
                            if ($has_like) BbsReplyCache::getInstance($this->replyKey)->addLog($uid);
                        }
                        $v['avatar'] = !empty($v['icon'])? env('MEDIA_HOST').$v['icon']: env('MEDIA_HOST').env('DEFAULT_HEADER');
                        $v['nickname'] = $v['nick_name'];
                        $v['is_like']  = $has_like;
                        $v['is_own']  = $is_own;
                        $v['createtime'] = countDownTime(strtotime($v['createtime']));
                    }
                    unset($v);
                    $list = $res['data'];
                    $string_key = $this->key['BOOK_REPLAY'].':REPLAY_ID:'.$this->topicKey.':PAGE_SIZE:'.$pageSize.":pageIndex:".$pageIndex.':TOTAL:'.$count;
                    BbsReplyCache::getInstance($this->topicKey)->addTotal($res['total'],true);
                }
            }
        $data['list'] = $list??[];
        $data['count'] = $res['total']??0;
        $param['pageIndex'] = $pageIndex;
        $param['pageSize'] = $pageSize;
        $data['page'] = pageDeal($param,$res??[],'desc','createtime');
        $this->redis->set($string_key,json_encode($data));
        return $data;

    }

    /**
     * 提交评论
     * @param $param
     */
    public function send($param)
    {
        $uid = $param['uid'];
        $book_id = $param['book_id'];
        if (MembersModel::query()->where(['id'=>$uid])->value('bbs_status')) throw new ApiExceptions(1113);

        $find = BookModel::query()->where('status',1)->find($param['book_id']);
        if (empty($find)) throw new ApiExceptions(1105);
        $createTime = BbsTopicModel::query()->where('member_id',$uid)->orderBy('tid','desc')->value('createtime');
        if (!empty($createTime) && (time() - strtotime($createTime) < self::LIMIT_TIME)) throw new ApiExceptions(1109);
        //异步写入mysql与redis数据
        $param['data'] = [$uid,$book_id,$param['message']];
        $param['addOption'] = 'sendAsync';
        $task = new SaveBbsDbTask($param);
        Task::deliver($task);

      /*  以下改为异步写入
        $time = time();
        $data = array(
            "member_id" => $uid,
            "nickname"	=> '',
            "book_id"		=> $book_id,
            "message"	=> check_str_input($param['message']),
            'score' =>$param['score']??10,
            'title' =>isset($param['title'])?check_str_input($param['title']):'',
            "createtime"	=> date('Y-m-d H:i:s',$time),
            "lasttime"	=> date('Y-m-d H:i:s',$time)
        );
        $model = new BbsTopicModel();
        $res = $model->saveData($data);
        if (!$res->tid) throw new ApiExceptions(1106);
        if ($this->cache) {
            BbsCache::getInstance($book_id)->addBbs($res->tid,$time);
            BbsCache::getInstance($book_id)->addTotal();

        }*/
        return;
    }
    public function sendAsync($data)
    {
        list($uid,$book_id,$message) = $data['data'];
        $time = time();
        $data = array(
            "member_id" => $uid,
            "nickname"	=> '',
            "book_id"		=> $book_id,
            "message"	=> check_str_input($message),
            'score' =>$param['score']??10,
            'title' =>isset($param['title'])?check_str_input($param['title']):'',
            "createtime"	=> date('Y-m-d H:i:s',$time),
            "lasttime"	=> date('Y-m-d H:i:s',$time)
        );
        $model = new BbsTopicModel();
        $res = $model->saveData($data);
        if (!$res->tid) return;
        if ($this->cache) {
            BbsCache::getInstance($book_id)->addBbs($res->tid,$time);
            BbsCache::getInstance($book_id)->addTotal();
        }
    }

    /**
     * 回复消息
     * @param $param
     */
    public function reply($param)
    {
        $tid = $param['tid'];
        $uid = $param['uid'];
        $rid = $param['rid'];
        if (MembersModel::query()->where(['id'=>$uid])->value('bbs_status')) throw new ApiExceptions(1113);
        $topic = BbsTopicModel::query()->where('tid',$tid)->first(['tid','book_id','member_id','comments','message']);
        if (empty($topic)) throw new ApiExceptions(1104);
        $topic = $topic->toArray();
        $createTime = BbsReplyModel::query()->where(['tid'=>$tid,'member_id'=>$uid])->orderBy('rid','desc')->value('createtime');
        if (!empty($createTime) && (time() - strtotime($createTime) < self::LIMIT_TIME)) throw new ApiExceptions(1109);
        //异步写入mysql与redis数据
        $param['data'] = [$uid, $tid, $param['message'],$rid, $param['title']??'',$topic];
        $param['addOption'] = 'replyAsync';
        $task = new SaveBbsDbTask($param);
        Task::deliver($task);
        //以下数据异步写入
//        $time = time();
//        $bbs_member_id = $topic['member_id']; //楼主uid
//        $userInfo = MembersModel::query()->where('id',$uid)->first(['nickname','account']);
//        $data = array(
//            "member_id" => $uid,
//            "nickname"	=> !empty($userInfo->nickname)? $userInfo->nickname : $userInfo->account,
//            "tid"		=> $tid,
//            "message"	=> check_str_input($param['message']),
//            "title"	=> isset($param['title']) ? check_str_input($param['title']):'',
//            "parent_id" => $rid,
//            "createtime"	=> date('Y-m-d H:i:s',$time),
//            "lasttime"	=> date('Y-m-d H:i:s',$time)
//        );
//        try {
//            DB::beginTransaction();
//            $model = new BbsReplyModel();
//            $res  = $model->saveData($data);
//            if (!$res->rid) {
//                DB::rollBack();
//                throw new ApiExceptions(1106);
//            }
//            $updateArray['comments'] = $topic['comments'] +1;
//            $updateArray['lasttime'] = date('Y-m-d H:i:s',$time);
//            $res1 = BbsTopicModel::query()->where('tid',$tid)->update($updateArray);
//            if (!$res1) {
//                DB::rollBack();
//                throw new ApiExceptions(1106);
//            }
//            if ($rid) {
//                $res2 = BbsReplyModel::query()->where('rid',$rid)->update(['lasttime'=> date('Y-m-d H:i:s')]);
//                $res3 = BbsReplyModel::query()->where('rid',$rid)->increment('comments',1);
//                if (!$res2 || !$res3) throw new ApiExceptions(1106);
//                $reply = BbsReplyModel::query()->where('rid',$rid)->first(['member_id','message']);
//                $bbs_member_id = $reply->member_id;
//                $topic['message'] = $reply->message;
//                $topic['member_id'] = $bbs_member_id;
//            }
//            $icon = MembersModel::query()->where(['id'=>$uid])->value('icon');
//            $data['avatar'] = !empty($icon) ? $icon: '';
//            if ($bbs_member_id != $uid) { //自己不给自己推
//                $res4 = $this->writeNotification($data,$topic);
//                if (!$res4)  {
//                    DB::rollBack();
//                    throw new ApiExceptions(1106);
//                }
//            }
//
//            DB::commit();
//            //加入缓存
//            if ($this->cache) {
//                $this->topicKey = $topic['book_id'].'.'.$topic['tid'];
//                BbsReplyCache::getInstance($this->topicKey)->addBbs($res->rid,$time);
//                if ($rid)//回复评论详情
//                    BbsReplyCache::getInstance($this->topicKey.'.'.$rid)->incr('comments');
//                else//评论
//                    BbsCache::getInstance($this->topicKey)->incr('comments');
//
//
//                BbsReplyCache::getInstance($this->topicKey)->addTotal();
//
//                //BbsReplyCache::getInstance($this->topicKey.'.'.$res->rid)->getDetail();
//
//            }
//        }catch (QueryException $ex){
//            DB::rollBack();
//            throw new ApiExceptions(1007,'',$ex->getMessage());
//        }


           return;
    }
    public function replyAsync($data)
    {
        list($uid, $tid, $message,$rid,$title,$topic) = $data['data'];
        $time = time();
        $bbs_member_id = $topic['member_id']; //楼主uid
        $userInfo = MembersModel::query()->where('id',$uid)->first(['nickname','account']);
        $data = array(
            "member_id" => $uid,
            "nickname"	=> !empty($userInfo->nickname)? $userInfo->nickname : $userInfo->account,
            "tid"		=> $tid,
            "message"	=> check_str_input($message),
            "title"	=> check_str_input($title),
            "parent_id" => $rid,
            "createtime"	=> date('Y-m-d H:i:s',$time),
            "lasttime"	=> date('Y-m-d H:i:s',$time)
        );
        try {
            DB::beginTransaction();
            $model = new BbsReplyModel();
            $res  = $model->saveData($data);
            if (!$res->rid) {
                DB::rollBack();
            }
            $updateArray['comments'] = $topic['comments'] +1;
            $updateArray['lasttime'] = date('Y-m-d H:i:s',$time);
            $res1 = BbsTopicModel::query()->where('tid',$tid)->update($updateArray);
            if (!$res1) {
                DB::rollBack();
            }
            if ($rid) {
                $res2 = BbsReplyModel::query()->where('rid',$rid)->update(['lasttime'=> date('Y-m-d H:i:s')]);
                $res3 = BbsReplyModel::query()->where('rid',$rid)->increment('comments',1);
                if (!$res2 || !$res3) DB::rollBack();
                $reply = BbsReplyModel::query()->where('rid',$rid)->first(['member_id','message']);
                $bbs_member_id = $reply->member_id;
                $topic['message'] = $reply->message;
                $topic['member_id'] = $bbs_member_id;
            }
            $icon = MembersModel::query()->where(['id'=>$uid])->value('icon');
            $data['avatar'] = !empty($icon) ? $icon: '';
            if ($bbs_member_id != $uid) { //自己不给自己推
                $res4 = $this->writeNotification($data,$topic);
                if (!$res4)  {
                    DB::rollBack();
                }
            }

            DB::commit();
            //加入缓存
                $topicKey = $topic['book_id'].'.'.$topic['tid'];
                BbsReplyCache::getInstance($topicKey)->addBbs($res->rid,$time);
                if ($rid)//回复评论详情
                    BbsReplyCache::getInstance($topicKey.'.'.$rid)->incr('comments');
                else//评论
                    BbsCache::getInstance($topicKey)->incr('comments');


                BbsReplyCache::getInstance($topicKey)->addTotal();

                //BbsReplyCache::getInstance($this->topicKey.'.'.$res->rid)->getDetail();


        }catch (QueryException $ex){
            DB::rollBack();
        }


    }
    //推送通知
    public function writeNotification($data,$topic,$msg_type=2)
    {
        $book_id = $topic['book_id'];
        $book_name = BookModel::query()->where('id',$book_id)->value('book_name');
        $content['nickName'] = $data['nickname'];
        $content['fromText'] = str_resolve($topic['message']);//楼主原文（$message：评论详情中的原文； $topic['message']：评论原文）
        $content['bookName'] = $book_name??'';
        $reply_message = $msg_type ==2 && !empty($data['message'])? '回复了你: '.str_resolve($data['message']): '无';
        $content['ToText'] = $msg_type ==2 ? $reply_message:'赞了你的评论';//回复信息
        $array=[];
        $array['content'] = json_encode($content,JSON_UNESCAPED_UNICODE);
        $array['link_param'] = json_encode(['bookId'=>$book_id,'bbsId'=>$topic['tid']],JSON_UNESCAPED_UNICODE);
        $array['type'] = 1;
        $array['send_memberId'] = $data['member_id']??0;//发者
        $array['headImgUrl'] = $data['avatar'];
        $array['msg_type'] = $msg_type;
        $array['title'] = '评论消息';
        $array['createtime'] = date('Y-m-d H:i:s');
        $notify = NotifyMessageModel::query()->create($array);
        if (!$notify) return false;

        $notify_id = $notify->id;
        $res = NotifyUserModel::query()->create(['notify_message_id'=>$notify_id,'member_id'=>$topic['member_id'],'status'=>1]);
        if (!$res) return false;

        $pushData['id'] = $notify_id;

        //bbs消息推送
        MessageService::pushMessageTask($pushData);

        return true;

    }

    /**
     * 点赞
     * @param $param
     */
    public function likes($param)
    {
        $id = $param['id'];
        $uid = $param['uid'];
        if ($param['type']==1) {
            $table = BbsTopicModel::query()->where('tid',$id)->first(['book_id','tid','member_id','message']);
        } else {
            $table = BbsTopicModel::query()->from('bbs_topic as a')
                ->leftJoin('bbs_reply as b','a.tid','=','b.tid')
                ->where('b.rid',$id)
                ->first(['a.book_id','a.tid','b.member_id','b.message']);
        }
         if (empty($table)) throw new ApiExceptions(1104);
            $this->topicKey = $table->book_id .'.'.$table->tid;
            $this->replyKey = $this->topicKey.'.'.$id;
            $rd = $param['type']==1 ? BbsCache::getInstance($this->topicKey):BbsReplyCache::getInstance($this->replyKey);
            $has_like = $rd->is_like($uid);

        if (!empty($has_like)) throw new ApiExceptions(1107);
       //记入redis
            $rd->incr('likes');
            $rd->addLog($uid);
        //数据异步更新到数据库
        $data = [
                'type'=>1,
                'member_id'=>$uid,
                're_id'=> $id,
                "createtime"	=> date('Y-m-d H:i:s'),
            ];
        $da['data'] = $data;
        $da['param'] = $param;
        $da['table'] = $table;
        $da['addOption'] = 'likesSaveToDb';
        $task = new SaveBbsDbTask($da);
        Task::deliver($task);
        return;
    }
    //异步更新数据到数据库-点赞
    public function likesSaveToDb($da)
    {
        $table = $da['table'];
        $param = $da['param'];
        $data = $da['data'];
        $id = $param['id'];
        $uid = $param['uid'];
        $key = ( isset($param['type']) && $param['type'] == 1 ) ? "tid" : "rid";
        $re_table = ( isset($param['type']) && $param['type'] == 1 ) ? "bbs_topic" : "bbs_reply";
        $data['re_table'] = $re_table;
        try {
            DB::beginTransaction();
            $model = new BbsLogModel();
            $res = $model->saveData($data);
            if (!$res) {
                DB::rollBack();
            }
            $m =  $param['type'] ==1 ? new BbsTopicModel():new BbsReplyModel();
            $bbs = $m->where($key,$id)->first(['likes','member_id']);
            $bbs_member_id = $bbs->member_id;
            $updateArray['lasttime'] = date('Y-m-d H:i:s');
            $updateArray['likes'] = intval($bbs->likes) +1;
            $res2 = $m->where($key,$id)->update($updateArray);
            if (!$res2) {
                DB::rollBack();
            }
            $userInfo = MembersModel::query()->where('id',$uid)->first(['id','nickname','account','icon']);
            $data['nickname'] = $userInfo['nickname']??$userInfo['account'];
            $data['avatar'] = !empty($userInfo['icon'])? $userInfo['icon'] : '';
            if ($bbs_member_id != $uid) { //自己不给自己推
                $topic['book_id'] = $table->book_id;
                $topic['member_id'] = $table->member_id;
                $topic['tid'] = $table->tid;
                $topic['message'] = $table->message;
                $res3 = $this->writeNotification($data,$topic,3);
                if (!$res3)  {
                    DB::rollBack();
                    throw new ApiExceptions(1106);
                }
            }
            DB::commit();
        }catch (QueryException $ex){
            DB::rollBack();
        }
    }
    public function delete($param)
    {
        $id = $param['id'];
        $key = ( isset($param['type']) && $param['type'] == 1 ) ? "tid" : "rid";
        $m =  $param['type'] ==1 ? BbsTopicModel::query():BbsReplyModel::query();
        $find = $m->where(['member_id'=>$param['uid'],$key=>$id])->first();
        if (empty($find))  {
            DB::rollBack();
            throw new ApiExceptions(1112);
        }
        $tid = $find->tid;
        $parent_id = $find->parent_id ;
        $book_id = BbsTopicModel::query()->where('tid',$tid)->value('book_id');
        $r_key = $book_id.'.'.$tid;
        if ($param['type'] ==2){
            if ($parent_id) {
                //回复中
                BbsReplyCache::getInstance($r_key.'.'.$parent_id)->incr('comments',-1);
            } else {
                //评论列表中
                BbsCache::getInstance($r_key)->incr('comments',-1);
            }
            BbsReplyCache::getInstance($r_key)->rem($id);
            BbsReplyCache::getInstance($r_key)->decrTotal();
            $keyPrefix = $this->key['BOOK_REPLAY'].':REPLAY_ID:'.$r_key.'*';
        } else {
            BbsCache::getInstance($book_id)->rem($id);
            BbsCache::getInstance($book_id)->decrTotal();
            $keyPrefix  = $this->key['BOOK_TOPIC'].':BOOK:'.$book_id.'*';
        }
        $this->redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $iterator = null;
        $count = 1000;
        while ($arrKeys = $this->redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $keys)
            {
                $this->redis->del($keys);
            }
        }
        //数据异步同步到数据库
        $param['key'] = $key;
        $param['tid'] = $tid;
        $param['parent_id'] = $parent_id;
        $param['addOption'] = 'deleteSaveToDb';
        $task = new SaveBbsDbTask($param);
        Task::deliver($task);


    }
    //异步写数据到数据库-删除评论
    public function deleteSaveToDb($param)
    {
        $id = $param['id'];
        $parent_id = $param['parent_id'];
        $re_table = ( isset($param['type']) && $param['type'] == 1 ) ? "bbs_topic" : "bbs_reply";
        try {
            DB::beginTransaction();
            $m =  $param['type'] ==1 ? BbsTopicModel::query():BbsReplyModel::query();
            $res = $m->where($param['key'],$id)->delete();
            if (!$res) {
                DB::rollBack();
            }
            if ($param['type'] ==2) {
                $um = $parent_id ? BbsReplyModel::query()->where('rid',$parent_id):BbsTopicModel::query()->where('tid',$param['tid']);
                $res3 = $um->decrement('comments',1);
                if (!$res3) {
                    DB::rollBack();
                }
            }
            BbsLogModel::query()->where(['type'=>1,'re_id'=>$id,'re_table'=>$re_table])->delete();

            DB::commit();

        } catch (QueryException $ex){
            DB::rollBack();
        }
    }





}
