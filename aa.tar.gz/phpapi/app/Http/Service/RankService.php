<?php


namespace App\Http\Service;


use App\Cache\RankingBookCache;
use App\Cache\RankingCache;
use App\Cache\RankingClassifyCache;
use App\Exceptions\ApiExceptions;

class RankService
{


    public function getRanking(): array
    {

        if($re = RankingClassifyCache::getInstance(1)->getDetail()){
            return json_decode($re,true);
        }
        return [];

    }

    /**
     *
     * 获取排行榜下的分类
     * @param $classifyId
     * @return array
     */
    public function getRankingByClassId($classifyId): array
    {

        $result = RankingCache::getInstance($classifyId)->getDetail();
        $return = [];
        if ($result) {
            ksort($result);
            $return = array_map('json_decode', $result);
        }

        return $return;

    }

    /**
     * 获取排行榜下的书籍
     * @param $rankId
     * @param $pageIndex
     * @param $pageSize
     * @return array
     */
    public function getRankingBooks($rankId, $pageIndex, $pageSize)
    {
        $result = RankingBookCache::getInstance([$rankId, $pageIndex, $pageSize])->getDetail();
        $bookInfo = [];
        $bookService = new BookService();
        foreach ($result as $k => $v) {
            try {
                $bookInfo[] = $bookService->getBookById($v);
            } catch (ApiExceptions $e) {
                continue;
            }
        }
        return [
            'page_index' => (int)$pageIndex,
            'page_size' => (int)$pageSize,
            'grid_data' => $bookInfo
        ];

    }


}
