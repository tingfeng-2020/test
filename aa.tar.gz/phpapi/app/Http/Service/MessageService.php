<?php


namespace App\Http\Service;

use App\Cache\MemberCache;
use App\Exceptions\ApiExceptions;
use App\Model\BookShelfModel;
use App\Model\MemberGetuiModel;
use App\Model\NotifyMessageModel;
use App\Model\NotifyUserModel;
use App\Task\PushMessageTask;
use App\Tools\Redis;
use App\Traits\PushTrait;
use Cncal\Getui\Sdk\Exception\GetuiException;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Support\Facades\Log;


class MessageService extends BaseService
{
    use PushTrait;

    public function getNotifyMessage($param)
    {
        $map[] = ['a.status', '<', 3];
        $map['a.member_id'] = $param['uid'];
        $map['b.type'] = $param['type'];
        $page_size = getPageSize($param);
        $page_index = $param['page_index'] ?? 1;
        $model = NotifyMessageModel::query()->from('notify_message as b')
            ->leftJoin('notify_user as a', 'a.notify_message_id', '=', 'b.id')
            ->where($map)
            ->orWhereRaw('(`b`.`type` = ' . $param['type'] . ' AND b.msg_type IN (4,5,6))');
        $key = $this->key['USER_MSG_LIST'] . ':UID:' . $param['uid'] . ":TYPE:" . $param['type'] . ":PAGE:" . $page_index . ":PAGE_SIZE:" . $page_size . ":" . $model->count('b.id');
        if ($data = $this->redis->get($key)) return $data;

        $head = env('MEDIA_HOST') . env('DEFAULT_HEADER');
        $res = $model->selectRaw('a.status,b.id,b.type,b.msg_type,b.title,b.link_param,b.send_memberId,b.content,b.`createtime`,if(b.headImgUrl !=\'\',CONCAT("' . env('MEDIA_HOST') . '",b.headImgUrl),"' . $head . '") as headImgUrl')
            ->orderBy('b.createtime', 'desc')
            ->paginate($page_size, ['*'], 'page_index')->toArray();

        foreach ($res['data'] as &$v) {
            $v['createtime'] = countDownTime(strtotime($v['createtime']));
            if ($v['msg_type'] == 1) {
                $v['headImgUrl'] = env('MEDIA_HOST') . env('BOOK_UPDATE_HEADER');
            }
            if (in_array($v['msg_type'], [4, 5, 6])) {
                $has = MemberCache::getInstance($v['id'])->getReadUid($param['uid']);
                $v['status'] = $has ? 1 : 2;
            }
        }
        unset($v);
        $data = pageDeal($param, $res, 'desc', 'createtime');
        $data['count'] = $res['total'];
        $data['grid_data'] = $res['data'];
        $this->redis->setex($key, config('cache.ttl'), json_encode($data));
        return $data;
    }

    public function messageUpdate($param)
    {
        $notify_message_ids = is_array($param['id']) ? $param['id'] : [$param['id']];
        NotifyUserModel::query()->from('notify_user as a')
            ->leftJoin('notify_message as b', 'a.notify_message_id', '=', 'b.id')
            ->whereIn('b.id', $notify_message_ids)->update(['a.status' => $param['status']]);
        if ($param['status'] == 2) {
            MemberCache::getInstance($param['id'])->addReaduid($param['uid']);
        }
        $this->delMessageRedisKey($param['uid']);
        return;
    }

    public function messageUpdateByType($param)
    {
        $map['a.member_id'] = $param['uid'];
        if ($param['type'] != 3) {
            $map['b.type'] = $param['type'];
        }
        NotifyUserModel::query()->from('notify_user as a')
            ->leftJoin('notify_message as b', 'a.notify_message_id', '=', 'b.id')
            ->where($map)->update(['a.status' => $param['status']]);
        if ($param['type'] != 1) {
            //普推系统消息加入日志
            $dis = NotifyMessageModel::query()->where(['type' => 2])->whereIn('msg_type', [4, 5, 6])->pluck('id')->toArray();
            foreach ($dis as $id) {
                MemberCache::getInstance($id)->addReaduid($param['uid']);
            }
        }
        if (!isset($param['memberInit'])) $this->delMessageRedisKey($param['uid']);
        return;
    }

    protected function delMessageRedisKey($uid = 0)
    {
        if (!$uid) return;
        $redis = Redis::getInstance();
        $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $keyPrefix = $this->key['USER_MSG_COUNT'] . ':UID:' . $uid . ':COUNT:*';
        $iterator = null;
        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', 1000)) {
            foreach ($arrKeys as $key) {
                $redis->del($key);
            }
        }
        $iterator = null;
        $keyPrefix = $this->key['USER_MSG_LIST'] . ':UID:' . $uid . ":TYPE:";
        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', 1000)) {
            foreach ($arrKeys as $key) {
                $redis->del($key);
            }
        }

    }

    public function messageCount($uid)
    {
        $map[] = ['b.status', '<', 3];
        $map['b.member_id'] = $uid;
        $model = NotifyMessageModel::query()->from('notify_message as a')
            ->leftJoin('notify_user as b', 'a.id', '=', 'b.notify_message_id')
            ->where($map)
            ->orWhereRaw('(`a`.`type` = 2 AND a.msg_type IN (4,5,6))');//系统信息
        $key = $this->key['USER_MSG_COUNT'] . ':UID:' . $uid . ':COUNT:' . $model->count('a.id');
        if ($data = $this->redis->get($key)) return $data;
        $hd_count = 0;
        $sys_count = 0;
        $hd_unread_count = 0;
        $sys_unread_count = 0;
        $res = $model->orderBy('a.type', 'asc')->get();
        foreach ($res as $v) {
            if ($v['type'] == 1) $hd_count++;
            if ($v['type'] == 2) $sys_count++;
            if ($v['type'] == 1 && $v['status'] == 1) $hd_unread_count++;
            if ($v['type'] == 2) {
                if (in_array($v['msg_type'], [4, 5, 6])) {
                    //4,5,6为后台系统消息，与用户无关联已读未读写入redis
                    if ($v['id']) {
                        $has = MemberCache::getInstance($v['id'])->getReadUid($uid);
                        if (!$has) $sys_unread_count++;
                    }

                } elseif (isset($v['status']) && $v['status'] == 1) {
                    //1，书籍更新与用户有关联的(数据库直接有)
                    $sys_unread_count++;
                }

            }

        }
        $data = compact('hd_count', 'sys_count', 'hd_unread_count', 'sys_unread_count');
        $this->redis->setex($key, config('cache.ttl'), json_encode($data));

        return $data;

    }

    public function messageDetailed($id)
    {
        $res = NotifyUserModel::query()->from('notify_user as a')
            ->leftJoin('notify_message as b', 'a.notify_message_id', '=', 'b.id')
            ->where(['b.id' => $id])->selectRaw('a.status,b.*,if(b.headImgUrl !=\'\',CONCAT("' . env('MEDIA_HOST') . '",b.headImgUrl),"") as headImgUrl')->first();
        $data = [];
        if ($res && $data = $res->toArray()) {
            $data['createtime'] = countDownTime(strtotime($data['createtime']));
        }
        return $data;
    }

    /**
     * 消息推送投递任务
     */
    public static function pushMessageTask($data = [])
    {
        if (!empty($data['id'])) {
            $messageData = (new self())->getPushData($data['id']);

            if (!empty($messageData)) {
                $deviceId_ad = $messageData['deviceId_ad'];
                $deviceId_ios = $messageData['deviceId_ios'];
                if (!empty($deviceId_ad) && is_array($deviceId_ad)) {
                    $messageData['os'] = 1;
                    $messageData['deviceId'] = $deviceId_ad;
                    $task = new PushMessageTask($messageData);
                    $task->setTries(1);
                    $ret = Task::deliver($task);
                    if (!$ret) {
                        throw new ApiExceptions(1000);
                    }

                }
                if (!empty($deviceId_ios) && is_array($deviceId_ios)) {
                    $messageData['os'] = 2;
                    $messageData['deviceId'] = $deviceId_ios;
                    $task = new PushMessageTask($messageData);
                    $task->setTries(1);
                    $ret = Task::deliver($task);
                    if (!$ret) {
                        throw new ApiExceptions(1000);
                    }
                }

            }

        }

    }

    /**
     * 加入消息（推送）
     * @param $data
     * @return bool|int
     */
    public function messagePush($data)
    {
        return $this->redis->lPush(config('cache_key.bbs.PUSH_BBS'), json_encode($data));
    }

    public function runCountLog($key, $incr = 1)
    {
        return $this->redis->INCR($key, $incr);
    }

    /**
     * 获取消息（推送）
     */
    public function getMessage()
    {
        return $this->redis->rPop(config('cache_key.bbs.PUSH_BBS'));
    }

    /**
     * 定时任务补发
     */
    public function pushMessageBu()
    {
        try {
            //redis 里补发
            $server = new MessageService();
            $listData = $server->getMessage();
            $listData = !empty($listData) ? json_decode($listData, true) : [];
            if (!empty($listData)) {
                Log::info(date('m-d H:i') . 'redis补发推送 id=' . $listData['id']);
                $this->pushData($listData['id']);
            }
            //mysql补发
           /* $time = date('Y-m-d H:i:s', intval(time() - 60));//只补发1分钟之内的推送
            $res = NotifyUserModel::query()
                ->whereRaw('`createtime` > "' . $time . '"  and (`is_push` = 3 or `is_push_ios` = 3)')
                ->orderBy('createtime', 'desc')
                ->selectRaw('notify_message_id as id,is_push,is_push_ios')
                ->limit(10)
                ->get();
            $res = $res ? $res->toArray() : [];

            foreach ($res as $rd) {
                $this->pushData($rd['id']);
            }*/
        } catch (\Exception $e) {
            Log::info(date('m-d H:i') . '补发推送失败' . $e->getMessage());
        }
    }

    public function pushData($id = '')
    {
        if (empty($id)) return;
        $data = $this->getPushData($id);
        if (empty($data)) return;

        //安卓-cid
        $deviceId_ad = $data['deviceId_ad'];
        //ios-cid
        $deviceId_ios = $data['deviceId_ios'];
        unset($data['deviceId_ad'], $data['deviceId_ios']);
        $transmission_content = json_encode($data);
        $is_send = 1;
        $is_send_ios = 1;
        //安卓
        if (!empty($deviceId_ad) && is_array($deviceId_ad)) {
            $da = [
                'template_type' => 4,//安卓用1模版
                'template_data' => [
                    'is_ios' => true, // 是否支持 ios （默认不支持）
                    'title' => $data['title'], // 通知标题，string(40), 必填
                    'text' => $data['content'], // 通知内容，string(600), 必填
                    'logo' => 'pushImgUrl', // 通知图标名称，string(40), 必填
                    'logo_url' => env('PUSH_IMG') ? env('MEDIA_HOST') . env('PUSH_IMG') : 'https://rayman-read-book.oss-cn-hongkong.aliyuncs.com/media/defaults/push_icon.jpg', // 通知图标url地址，string(100), 必填
                    'transmission_type' => 2, // 是否立即启动应用：1 立即启动 2 等待客户端自启动，必填
                    'transmission_content' => $transmission_content, // 透传内容，不支持转义字符，string(2048), 必填
                ],
                'cid' => '', // 推送通知至指定用户时填写
                'cid_list' => $deviceId_ad, // 推送通知至指定用户列表时填写
            ];
            Log::info(date('m-d H:i') . '安卓推送data=', $da);

            try {
                //改为多端登录多端推送
                $res = self::pushToListUser($da);
                $is_send = 2;
                if (empty($res) || $res['result'] != 'ok') {
                    $is_send = 3;
                    Log::info(date('m-d H:i') . '推送失败00', $da);
                }

                Log::info(date('m-d H:i') . '补发推送成功', $res);
            } catch (\Exception $e) {
                $is_send = 3;
                Log::info(date('m-d H:i') . '补发推送失败01' . $e->getMessage(), $da);
            } catch (GetuiException $e) {
                $is_send = 3;
                Log::info(date('m-d H:i') . '补发推送失败02' . $e->getMessage(), $da);
            }
        }
        //ios
        if (!empty($deviceId_ios) && is_array($deviceId_ios)) {
            $da = [
                'template_type' => 4,//ios用4模版
                'template_data' => [
                    'is_ios' => true, // 是否支持 ios （默认不支持）
                    'title' => $data['title'], // 通知标题，string(40), 必填
                    'text' => $data['content'], // 通知内容，string(600), 必填
                    'logo' => 'pushImgUrl', // 通知图标名称，string(40), 必填
                    'logo_url' => env('PUSH_IMG') ? env('MEDIA_HOST') . env('PUSH_IMG') : 'https://rayman-read-book.oss-cn-hongkong.aliyuncs.com/media/defaults/push_icon.jpg', // 通知图标url地址，string(100), 必填
                    'transmission_type' => 2, // 是否立即启动应用：1 立即启动 2 等待客户端自启动，必填
                    'custom_msg' => ['data' => $data],
                    'transmission_content' => $transmission_content, // 透传内容，不支持转义字符，string(2048), 必填
                ],
                'cid' => '', // 推送通知至指定用户时填写
                'cid_list' => $deviceId_ios, // 推送通知至指定用户列表时填写
            ];
            Log::info(date('m-d H:i') . '补发ios推送data=', $da);
            try {
                //改为多端登录多端推送
                $res = self::pushToListUser($da);
                $is_send_ios = 2;
                if (empty($res) || $res['result'] != 'ok') {
                    Log::info(date('m-d H:i') . '补发推送失败00', $da);
                    //推送失败
                    $is_send_ios = 3;
                }

                Log::info(date('m-d H:i') . '补发推送成功', $res);
            } catch (\Exception $e) {
                Log::info(date('m-d H:i') . '补发推送失败01' . $e->getMessage(), $da);
                //推送失败
                $is_send_ios = 3;
            } catch (GetuiException $e) {
                Log::info(date('m-d H:i') . '补发推送失败02' . $e->getMessage(), $da);
                //推送失败
                $is_send_ios = 3;
            }


        }
        NotifyUserModel::query()->where('notify_message_id', $data['id'])->update(['is_push_ios' => $is_send_ios, 'is_push' => $is_send]);


    }

    public function getPushData($id = '')
    {
        if (empty($id)) return;
        $data = NotifyMessageModel::query()->from('notify_message as a')
            ->leftJoin('notify_user as b', 'a.id', '=', 'b.notify_message_id')
            ->where(['a.id' => $id])
            ->selectRaw('a.*,GROUP_CONCAT(b.member_id) as member_ids')
            ->groupBy('a.id')
            ->first();
        if (empty($data)) return;
        $data = $data->toArray();
        $conten = [];
        if (!empty($data['member_ids'])) {
            //安卓-cid
            $deviceId_ad = MemberGetuiModel::query()
                ->where(['status' => 0, 'os' => 1])
                ->where('exp', '>', time())
                ->whereIn('member_id', explode(',', $data['member_ids']))
                ->selectRaw('distinct getui_cid')->pluck('getui_cid')
                ->toArray();
            //ios-cid
            $deviceId_ios = MemberGetuiModel::query()
                ->where(['status' => 0, 'os' => 2])
                ->where('exp', '>', time())
                ->whereIn('member_id', explode(',', $data['member_ids']))
                ->selectRaw('distinct getui_cid')->pluck('getui_cid')
                ->toArray();

            $conten['id'] = $data['id'];
            $conten['deviceId_ad'] = $deviceId_ad;
            $conten['deviceId_ios'] = $deviceId_ios;
            $conten['createtime'] = $data['createtime'];
            $conten['type'] = $data['type'];
            $conten['msg_type'] = $data['msg_type'];
            $conten['title'] = $data['title'];
            $conten['link_param'] = $data['link_param'];
            $conten['send_memberId'] = $data['send_memberId'];
            $conten['headImgUrl'] = env('MEDIA_HOST') . $data['headImgUrl'];
            $conten['content'] = $data['type'] == 2 ? $data['content'] : json_decode($data['content'], true)['ToText'];
        }
        return $conten;

    }

    public function pushMessageTest()
    {
        // error_reporting(E_ALL ^ E_DEPRECATED);
        $deviceId = '6e3bf509a27a1f24c802a149b97134ff';
        $deviceId = '5fae53b7298a80a515ce4b2520a41d35';
        $data = [
            'template_type' => 1,
            'template_data' => [
                'title' => '泥菩萨 更新拉', // 通知标题，string(40), 必填
                'text' => '关注的书籍有新的章节更新啦，快去看看吧1', // 通知内容，string(600), 必填
                'logo' => 'headimgUrl', // 通知图标名称，string(40), 必填
                'logo_url' => 'http://47.115.81.54:9000/media/defaults/messageBlue@3x.png', // 通知图标url地址，string(100), 必填
                'transmission_type' => 2, // 是否立即启动应用：1 立即启动 2 等待客户端自启动，必填
                'transmission_content' => '关注的书籍有新的章节更新啦，快去看看吧1', // 透传内容，不支持转义字符，string(2048), 必填
            ],
            'cid' => '6e3bf509a27a1f24c802a149b97134ff', // 推送通知至指定用户时填写
            'cid_list' => [], // 推送通知至指定用户列表时填写
        ];
        //$data = json_decode('{"template_type":1,"template_data":{"title":"评论消息","text":"点赞了你的评论","logo":"headimgUrl","logo_url":"","transmission_type":2,"transmission_content":"test1"},"cid":"5fae53b7298a80a515ce4b2520a41d35","cid_list":[]}', true);
        try {
            Log::info('推送data', $data);
            $res = self::pushToUser($data);
            if (empty($res) || $res['result'] != 'ok') {
                Log::info('bbs0:推送失败messageID=' . $this->data['id']);
                throw new ApiExceptions(1007, '', '推送失败');
            }
            Log::info('bbs:推送成功');
        } catch (GetuiException $e) {
            Log::info('bbs1:推送失败,requestId=' . $e->getRequestId());
        } catch (\Exception $e) {
            //Log::info('bbs2:推送失败,error' . $e->getMessage());
        }
        return;

    }


    public function pushBookInfo($bookId)
    {

        $pageSize = 3000;
        $model = BookShelfModel::query()->where('book_Id', $bookId);
        $bookService = new BookService();

        try {
            $bookInfo = $bookService->getBookById($bookId);
            if (!$bookInfo) {
                return;
            }

            if ($model) {
                $count = BookShelfModel::query()->where('book_Id', $bookId)->count('member_id');
                $pageCount = ceil($count / $pageSize);
                for ($i = 0; $i < $pageCount; $i++) {
                    $result = BookShelfModel::query()->where('book_Id', $bookId)->offset($i * $pageSize)->limit($pageSize)->pluck('member_id')->toArray();
                    foreach ($result as $k => $v) {
                        $par['member_id'] = $v;
                        $redis = Redis::getInstance();
                        $key = 'SET_PUSH:MEMBER' . $v;
                        if ($redis->sCard($key) >= 3 || $redis->sIsMember($key, $bookId)) {
                            continue;
                        }

                        $redis->sAdd($key, $bookId);
                        $redis->expire($key, strtotime(date('Ymd') . '235959') - time() + 1);


                        $msgId = NotifyMessageModel::query()->insertGetId([
                            'type' => 2,
                            'msg_type' => 1,
                            'title' => sprintf(env('BOOK_UPDATE_PUSH_MSG_TITLE'), $bookInfo['book_name']),
                            'link_param' => json_encode(['bookId' => $bookId]),
                            'content' => env('BOOK_UPDATE_PUSH_MSG_CONTENT')
                        ]);

                        if ($msgId && NotifyUserModel::query()->insert([
                                'member_id' => $v,
                                'notify_message_id' => $msgId,
                                'status' => 1,
                            ])) {

                            $this->pushMessageTask(['id' => $msgId]);
                        }

                    }
                }

            }

        } catch (ApiExceptions $exception) {
            Log::info('推送失败' . $exception->getFile() . $exception->getLine() . $exception->getMessage());
            return;
        } catch (\Exception $exception) {
            Log::info('推送失败' . $exception->getFile() . $exception->getLine() . $exception->getMessage());
        }


    }

}

