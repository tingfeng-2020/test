<?php
namespace App\Http\Service;


use App\Exceptions\ApiExceptions;
use App\Tools\Oss;
use Aws\Laravel\AwsFacade;
use Illuminate\Support\Facades\Log;

class FileService
{

    /**
     * 文件mineType类型
     * @var array
     */
    private $mineTypeList = [];

    /**
     * 文件扩展名
     * @var array
     */
    private $fileExt = ['png','jpg','jpeg','gif'];

    /**
     * 文件扩展名
     * @var string
     */
    private $nowFileExt = '';

    /**
     * 文件限制大小,默认20M
     * @var int
     */
    private $limitSize = 1024 * 1024 * 200;

    /**
     * 保存的路径
     * @var string
     */
    private $basePath = './';
    /**
     * 设置文件路径
     * @var string
     */
    private $filePath = 'media';
    /**
     * 上传文件字段
     * @var string
     */
    private $fileField = 'file';

    public function __construct()
    {
        $this->basePath = base_path('public/');
    }

    /**
     * 获取本地路径
     * @param $file
     * @return string
     */
    public function getLocalPath($file = '')
    {
        return $this->basePath . $file;
    }
    /**
     * 上传文件(oss)
     * @param $request
     * @param string $fileField
     * @param array|string $fileExt
     * @param bool $isUploadOss//是否传云上
     * @return array
     */
    public function uploadOss($request, $fileField = 'file', $fileExt = ['jpg','png','gif','jpeg'], $isUploadOss = true)
    {
        //验证上传文件类型
        $this->fileField = $fileField;
        $this->setFileExt($fileExt);
        $this->validate($request);
        $basePath = $this->getLocalPath();
        if ($isUploadOss) {
            //上oss云
            $result = $this->save($request);
            $path = &$result['path'];
            $fileName = $result['originalName'];
            //oss服务
            $oss = new Oss();
            $ossUrl = $oss->uploadToOss($path, $fileName, md5_file($basePath.$result['path']) ,$type = 'common');
            $result['plainUrl']  = $ossUrl;
            @unlink($basePath.$path);
            $this->rm_empty_dir('./media/');
            unset($path);
        } else {
            //存本地
            $result = $this->save($request);
            $result['plainUrl'] = $request->root().$result['path'];

        }
        return $result;
    }
    /**
     * 上传文件(aws)
     * @param $request
     * @param string $fileField
     * @param array|string $fileExt
     * @param bool $isUploadAws//是否传云上
     * @return array
     */
    public function upload($request, $fileField = 'file', $fileExt = ['jpg','png','gif','jpeg'], $isUploadAws = true)
    {
        //验证上传文件类型
        $this->fileField = $fileField;
        $this->setFileExt($fileExt);
        $this->validate($request);
        $basePath = $this->getLocalPath();
        if ($isUploadAws) {
            //上aws云
            $result = $this->save($request);;
            $key = $result['path'];
            //aws服务
            $s3 = AwsFacade::createClient('s3');
            $res = $s3->putObject([
                'Bucket' =>'reader', //存储桶（我的理解就是文件系统中的目录）
                'Key'    => $key, //文件名（包括后缀名）
                'Body'   =>file_get_contents($basePath.$key), //要上传的文件
                'ContentType'=>'',
            ]);

            if($res['@metadata']['statusCode'] != 200){
               throw new ApiExceptions(1007,'','上传失败');
            }
            $result['plainUrl']  = $s3->getObjectUrl('reader', $key);
            @unlink($basePath.$key);
            $this->rm_empty_dir('./media/');

        }else{
            //存本地
            $result = $this->save($request);
            $result['plainUrl'] = $request->root().$result['path'];

        }
        return $result;
    }
    /** 删除所有空目录
     * @param String $path 目录路径
     */
    public function rm_empty_dir($path){
        if(is_dir($path) && ($handle = opendir($path))!==false){
            while(($file=readdir($handle))!==false){// 遍历文件夹
                if($file!='.' && $file!='..'){
                    $curfile = $path.'/'.$file;// 当前目录
                    if(is_dir($curfile)){// 目录
                        $this->rm_empty_dir($curfile);// 如果是目录则继续遍历
                        if(count(scandir($curfile))==2){//目录为空,=2是因为.和..存在
                            @rmdir($curfile);// 删除空目录
                        }
                    }
                }
            }
            closedir($handle);
        }
    }
    /**
     * 设置扩展名
     * @param array $fileExt
     * @return $this
     */
    public function setFileExt($fileExt)
    {
        if (empty($fileExt)) {
            return;
        }
        if (!is_array($fileExt)) {
            $fileExt = explode(',', $fileExt);
        }
        //处理后缀如果有.开头的
        foreach ($fileExt as &$f) {
            if (stristr($f, '.')) {
                $f = substr($f, strpos($f, '.')+1);
            }
        }
        $this->fileExt = $fileExt;
        return $this;
    }

    /**
     * 上传验证
     * @param $request
     * @return bool
     * @throws ApiExceptions
     */
    private function validate($request)
    {
        $fileInfo = $request->file($this->fileField);
        if (null == $fileInfo) {
            throw new ApiExceptions(1007,  '','文件不能为空');
        }
        if (!$request->hasFile($this->fileField) || !$fileInfo->isValid()) {
            throw new ApiExceptions(1007,  '','文件参数字段错误');
        }
        if (!$this->checkFileExt($fileInfo)) {
            throw new ApiExceptions(1007,'','不支持的文件类型');
        }
        if (!$this->checkLimitSize($fileInfo)) {
            $limit = floor($this->limitSize /(1024 * 1024)) . 'M';
            throw new ApiExceptions(1007, '','超过'.$limit.'文件大小限制');
        }
        $this->checkDirectory('/'.$this->filePath);
        return true;
    }

    /**
     * 检查文件扩展名
     * @param $fileInfo
     * @return bool
     */
    private function checkFileExt($fileInfo)
    {
        $fileType = $fileInfo->getClientOriginalExtension();
        if (!$fileType || !in_array(strtolower($fileType), $this->fileExt)) {
            return false;
        }
        $this->nowFileExt = $fileType;
        return true;
    }

    /**
     * 验证文件大小
     * @param $fileInfo
     * @return bool
     */
    private function checkLimitSize($fileInfo)
    {
        $clientSize = $fileInfo->getClientSize();

        if ($clientSize > $this->limitSize) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * 检验文件夹，不存在则创建
     * @param $path
     */
    private function checkDirectory($path)
    {
        $folders = explode('/', $path);
        $basePath = $this->getLocalPath();//$this->basePath;
        foreach ($folders as $item) {
            if (empty($item)) {
                continue;
            }
            if (strrpos($basePath, '/') !== strlen($basePath)-1) {
                $basePath .= '/';
            }
            $basePath .= $item;
            $this->makeDir($basePath);
        }
    }

    /**
     * 新增文件目录
     * @param $path
     * @return mixed
     */
    private function makeDir($path)
    {
        if (is_dir($path)) {
            return $path;
        } else {
            mkdir($path, 0777, true);
            return $path;
        }
    }

    /**
     * 上传保存到本地
     * @param $request
     * @return array
     */
    private function save($request)
    {
        $fileInfo = $request->file($this->fileField);
        //$date = date('Ymd');
        //$path =$this->filePath.'/'.$date.'/';
        $path = $this->filePath . "/common/" . date('Y') . "/" . date('md') . "/" ;
        $url_path = $this->getLocalPath().$path;
        $originalName = $fileInfo->getClientOriginalName();
        $fileSize = $fileInfo->getSize();
        $fileName = md5(uniqid(microtime(true),true)).'.'.$this->nowFileExt;
        $fileInfo->move($url_path, $fileName);
        return [
            'path'  => $path.$fileName,
            'size' => $fileSize,
            'originalName'=>$originalName,
            'ext'   => $this->nowFileExt,
        ];
    }

    /**
     * 获取文件名
     * @param $path
     * @return string
     */
    private function getFilename($path)
    {
        $fileName = date('YmdHis') . mt_rand(100, 999) . '.' . $this->nowFileExt;
        if (file_exists($path . $fileName)) {
            return $this->getFileName($path);
        }
        return $fileName;
    }

    /**
     * 设置文件路径
     * @param string $path
     * @return $this
     */
    public function setFilePath($path)
    {
        $this->filePath = $path;
        return $this;
    }

    /**
     * 设置文件大小
     * @param string $maxSize
     * @return $this
     */
    public function setMaxSize($maxSize = '')
    {
        if ($maxSize && is_numeric($maxSize)) {
            $this->limitSize = $maxSize;
        }
        return $this;
    }

    /**
     * 设置文件mineType
     * @param array $mineType
     * @return $this
     */
    public function setMineType($mineType = [])
    {
        if ($mineType) {
            $this->mineTypeList = $mineType;
        }
        return $this;
    }

    /**
     * 设置basePath
     */
    public function setBasePath($path)
    {
        if (rtrim($path, '/') == $path) {
            $this->basePath = $path.'/';
        } else {
            $this->basePath = $path;
        }
    }

    /**
     * 获取所有上传的文件数组 ['file_key'=> UploadedFile]
     * @param $request Request
     */
    public function getFilesArrWithKey($request)
    {
        $files = $request->file();
        $fileArr = [];
        $this->getFileAndKey($fileArr, $files);
        return $fileArr;
    }

    /**
     * 扁平化嵌套的上传字段
     * @param $fileArr
     * @param $value
     * @param null $upperKey
     * @throws \Exception
     */
    private function getFileAndKey(&$fileArr, &$value, $upperKey = null)
    {
        if (empty($value)) {
            return;
        }
        if ($value instanceof UploadedFile) {
            if (is_null($upperKey)) {
                throw new \Exception('get File Key Error');
            }
            $fileArr[$upperKey] = $value;
        } elseif (is_array($value)) {
            foreach ($value as $vk => &$v) {
                $newKey = $upperKey===null ? $vk : $upperKey.'.'.$vk;
                $this->getFileAndKey($fileArr, $v, $newKey);
            }
        }
    }

}
