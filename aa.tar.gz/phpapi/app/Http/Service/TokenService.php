<?php


namespace App\Http\Service;


use App\Cache\TokenCache;
use App\Exceptions\ApiExceptions;
use App\Task\LogTask;
use App\Tools\Redis;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\JWT;
use Firebase\JWT\SignatureInvalidException;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Support\Facades\Log;
use UnexpectedValueException;

class TokenService
{
    public static function checkToken($token)
    {
        try {
            $key = env('JWT_SECRET');
            return JWT::decode($token,$key,['HS256']);
        }catch (UnexpectedValueException $e) {
            throw new ApiExceptions(401);
        }catch (SignatureInvalidException $e){
            throw new ApiExceptions(402);
        }catch (ExpiredException $e){
            throw new ApiExceptions(403);
        }

    }
    public static function checkRefreshToken($token)
    {
        try {
            $key = env('JWT_SECRET');
            return JWT::decode($token,$key,['HS256']);
        }catch (UnexpectedValueException $e) {
            throw new ApiExceptions(401);
        }catch (SignatureInvalidException $e){
            throw new ApiExceptions(402);
        }catch (ExpiredException $e){
            throw new ApiExceptions(401);
        }


    }

    public static function setToken($phone,$uid){
        $key = env('JWT_SECRET');
        $content = [
            'phone' => $phone,
            'uid' => $uid,
            'iat' => time(),//签发时间
            'nbf' => time(),
            'exp' => time() + env('JWT_TTL',60000),
        ];
        $jwt = JWT::encode($content,$key);

        return $jwt;
    }

    public static function generateToken($uid)
    {
        $key = env('JWT_SECRET');

        $time = time();

        $accessTokenTtl = env('JWT_TTL',60000);
        $content = [
            'uid' => $uid,
            'iat' => $time,//签发时间
            'nbf' => $time,
            'exp' => $time + $accessTokenTtl,//access_token有效期
            'scopes' => 1 //token标识，请求接口的token
        ];

        //生成访问令牌access_token
        $accessToken = JWT::encode($content,$key);

        //生成刷新令牌refresh_token
        $refreshTokenTtl = env('JWT_REFRESH_TTL' , 2592000);
        $content['exp'] = $time + $refreshTokenTtl;//refresh_token有效期
        $content['scopes'] = 2;//token标识，刷新access_token

        $refreshToken = JWT::encode($content,$key);
        //TokenCache::setUserToken($uid , $accessToken , $accessTokenTtl , $refreshToken , $refreshTokenTtl);
        $data = compact('uid','accessToken','accessTokenTtl','refreshToken','refreshTokenTtl');
        $data['addOption'] = 'saveTokenAsync';
        $task = new LogTask($data);
        Task::deliver($task);
        return [$accessToken , $refreshToken];
    }

}
