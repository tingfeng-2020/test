<?php


namespace App\Http\Service;


use App\Cache\ChapterCache;
use Elasticsearch\ClientBuilder;

class ChapterService
{

    protected $client;


    public function __construct()
    {
        $host = [
            [
                'host' => env('ELASTIC_SEARCH_HOST'),
                'port' => env('ELASTIC_SEARCH_PORT'),
                'scheme' => 'http',
                'user' => env('ELASTIC_SEARCH_USER'),
                'pass' => env('ELASTIC_SEARCH_PASS'),
            ]
        ];
        $this->client = ClientBuilder::create()->setHosts($host)->build();
    }

    /**
     * 根据章节id 获取章节内容
     * @param $cid
     * @return array
     */
    public function getChapter($cid)
    {
        $params = [
            'index' => env('ELASTIC_SEARCH_INDEX'),
            'type' => env('ELASTIC_SEARCH_DOC'),
            'id' => $cid
        ];
        $result = $this->client->get($params);
        return [
            'name' => $result['_source']['name'],
            'content' => $result['_source']['content'],
            'sequence' => $result['_source']['sequence'],

        ];

    }


    /**
     *
     * 获取书籍目录
     * @param $bookId
     * @return mixed|null
     */
    public function getChapterList($bookId){
        $result = ChapterCache::getInstance($bookId)->getDetail();
        $return = [];
        if($result){
            ksort($result);
            foreach ($result as $k=>$v){
                $return[] = json_decode($v,true);
            }
        }

        return $return;
    }


    /**
     * 下载章节
     * @param $bookId
     * @param $start
     * @param $end
     * @return array
     */

    public function getChapterByNum($bookId,$start,$end){
        $book = [];
        for ($i=$start;$i<=$end;$i++){
            $cid = ChapterCache::getInstance($bookId)->field($i);
            if($id = json_decode($cid,true)){
                if($result = $this->getChapter($id['id'])){
                    $book[] = array_merge($result,['id'=>$id['id']]);
                }
            }
        }

        return $book;

    }

    /**
     * 上传章节
     * @param $id
     * @param $name
     * @param $sequence
     * @param $content
     * @return array
     */

    public function uploadChapter($id,$name,$sequence,$content){
        $params = [
            'index' => env('ELASTIC_SEARCH_INDEX'),
            'type' => env('ELASTIC_SEARCH_DOC'),
            'id' => $id,
            'body' => [
                'name' => $name,
                'sequence' => $sequence,
                'content' => $content,
            ]
        ];
        return  $this->client->index($params);
    }

}
