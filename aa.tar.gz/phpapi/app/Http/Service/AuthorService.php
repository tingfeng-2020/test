<?php


namespace App\Http\Service;


use App\Cache\AuthorCache;
use App\Cache\BookByClassCache;
use App\Cache\BookByOverCache;
use App\Cache\BookCache;
use App\Cache\BookInAuthorCache;
use App\Cache\BookInClassCache;
use App\Cache\BookTagCache;
use App\Cache\ClassifyCache;
use App\Cache\SearchCache;
use App\Exceptions\ApiExceptions;
use App\Model\BookModel;
use Yansongda\Pay\Log;


class AuthorService extends BaseService
{


    public function getAuthorInfo($authorId)
    {
        $result = AuthorCache::getInstance($authorId)->getDetail();
        if ($result) {
            $result['grid_data'] = [];
            $book = BookInAuthorCache::getInstance($authorId)->getDetail();
            if ($book) {
                $bookService = new BookService();
                foreach ($book as $k) {
                    try {
                        $result['grid_data'][] = $bookService->getBookById($k);

                    } catch (ApiExceptions $exception) {
                        continue;
                    }
                }
            }

        }
        return $result;
    }

}
