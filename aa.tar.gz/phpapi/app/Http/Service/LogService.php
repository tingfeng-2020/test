<?php


namespace App\Http\Service;
use App\Cache\MobileCache;
use App\Cache\ReadBookShelfCache;
use App\Cache\TokenCache;
use App\Exceptions\ApiExceptions;
use App\Model\Ad\AdModel;
use App\Model\BookModel;
use App\Model\BookShelfModel;
use App\Model\Log\LogActiveModel;
use App\Model\Log\LogAdvertModel;
use App\Model\Log\LogDeviceModel;
use App\Model\Log\LogListenModel;
use App\Model\Log\LogMemberModel;
use App\Model\Log\LogNewDeviceModel;
use App\Model\Log\LogNewRegModel;
use App\Model\Log\LogOpenModel;
use App\Model\Log\LogReadModel;
use App\Model\Log\LogSearchModel;
use App\Model\Log\LogShelfModel;
use App\Model\MemberGetuiModel;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;


class LogService extends BaseService
{
    const ACTIVETIME = 15;//活跃时间
    /**
     * 异步新增用户日志
     * @param $param
     */
    public static function addMember($param,$uid='')
    {
        $param['member_id'] = $uid;
        $param['createtime'] = date("Y-m-d H:i:s");
        LogNewRegModel::query()->create($param);

    }

    /**
     * 异步初始化用户其他信息
     * @param $member
     */
    public function dealMemberInit($member)
    {
        $info = $member['info'];
        $uid = $info['id'];
        if (isset($member['other']['getuiCid']) && !empty($member['other']['getuiCid'])) {
            $this->addMemberGetui($member['other']);
        }
        //记录新增日志
        self::addMember($member['other'],$uid);
        MobileCache::getInstance($info['account'])->setDetail($uid);
        //$server = new MessageService();
        //$server->messageUpdateByType(['uid'=>$uid,'type'=>3,'status'=>2,'memberInit'=>1]);
        //MemberCache::getInstance($uid)->setDetail($info);

    }

    /**
     * 异步个推设置
     * @param $member
     */
    public function addMemberGetui($member)
    {
        $os = $member['os']??0;
        $app_guid = $member['appGuid'] ?? '';
        $device_model = $member['deviceModel']??'';
        $date = date("Y-m-d H:i:s");
        $data['member_id'] = $map['member_id'] = $member['id'];
        $data['app_guid']  = $app_guid;
        if ($os ==1) {
            //安卓
            $map['app_guid']= $app_guid;
        }else{
            $map['getui_cid']= $member['getuiCid'];
        }
        $data['getui_cid'] = $member['getuiCid'];
        $data['os'] = $os;
        $data['device_model'] = $device_model;
        $data['last_time'] = $date;
        $data['status'] = 0;
        $data['exp'] = intval(time()+ env('JWT_REFRESH_TTL' , 2592000));
        $res = MemberGetuiModel::query()->updateOrCreate($map,$data);
        if (!$res) throw new ApiExceptions(1000);

    }

    /**
     * token异步写入缓存
     * @param $data
     */
    public function saveTokenAsync($data)
    {
        extract($data);
        TokenCache::setUserToken($uid , $accessToken , $accessTokenTtl , $refreshToken , $refreshTokenTtl);
    }

    /**
     * 新增设备
     * @param $param
     */
    public static function addDevice($param)
    {
        $exist = MemberGetuiModel::query()->where('app_guid',$param['device'])->value('id');
        if (!$exist) {
            $exist =  LogNewDeviceModel::query()->where(['device'=>$param['device'],'channel'=>$param['channel']])->value('id');
            if (!$exist) {
                $param['createtime'] = date("Y-m-d H:i:s");
                LogNewDeviceModel::query()->create($param);
            }
        }
    }
    /**
     * 打开或者关闭app 添加log
     * @param $param
     */
    public function openOrCloseApp($param)
    {
        $param['createtime'] = date('Y-m-d H:i:s');
        LogOpenModel::query()->create($param);
    }

    /**
     * 留存app数据（设备或用户）
     * @param $param
     */
    public function keepApp($param)
    {
        //$param['grade_day'] = 0;//新增天
        $param['createtime']= date('Y-m-d H:i:s');
        //新增设备记录
        (new self())->addDevice($param);
        //用户留存记录
        if (!empty($param['member_id'])) {
            $this->keepMemberApp($param);
        }
        //新增设备留存记录
        $this->keepDeviceApp($param);


    }

    /**
     * 用户留存
     * @param $param
     */
    public function keepMemberApp($param)
    {
         $daytime = LogMemberModel::query()->where(['member_id'=>$param['member_id']])
            ->whereBetween('createtime',[date('Y-m-d'),date('Y-m-d 23:59:59')])
            ->value('createtime');
        if (!$daytime){ //一天只记一次记录
            LogMemberModel::query()->create($param);
        }

    }
    public function keepDeviceApp($param)
    {
        $daytime = LogDeviceModel::query()->where(['device'=>$param['device']])
            ->whereBetween('createtime',[date('Y-m-d'),date('Y-m-d 23:59:59')])
            ->value('createtime');
        if (!$daytime) { //一天只记一次记录
            //时间间隔：按天来记录数据(一天只记一条数据)
            unset($param['member_id']);
            LogDeviceModel::query()->create($param);
        }
    }


    /**
     * app阅读数据上报
     * @param $param
     */
    public function readTime($param)
    {
        if(date('n.j',$param['end_time']) != date('n.j',$param['start_time'])) {
            //跨天情况
          $this->dealMoreDay($param);
        } else {
            $param['createtime']= date('Y-m-d H:i:s');
            $param['long_time'] = round(($param['end_time'] - $param['start_time'])/60);//分钟
            if ($param['long_time'] > self::ACTIVETIME && $param['os'] !=3) {
                //阅读时间超过15分钟的为活跃设备 h5不记录
                $daytime = LogActiveModel::query()->where(['device'=>$param['device']])
                    ->whereBetween('createtime',[date('Y-m-d'),date('Y-m-d 23:59:59')])
                    ->value('createtime');
                if (!$daytime) {
                    //活跃留存记录
                    LogActiveModel::query()->create($param);
                }
            }
            //阅读记录
            LogReadModel::query()->create($param);
        }

    }

    /**
     *跨天数据处理
     * @param $param
     */
    public function dealMoreDay($param)
    {
        $m_long = intval(($param['end_time'] - $param['start_time'])/3600/24);;
        $start_long = round(((strtotime(date('Y-m-d 23:59:59',$param['start_time'])) +1) - $param['start_time'])/60);
        $end_long = round(($param['end_time'] - (strtotime(date('Y-m-d',$param['end_time']))))/60);
        $times =[
            date('Y-m-d H:i:s',$param['start_time'])=>$start_long,
        ];
        if ($m_long >0){
            for ($i=$m_long; $i>0;$i--) {
                $time = $param['end_time'] - $i * 80000;
                $times[date('Y-m-d 23:59:59',$time)] = 1440;
            }
        }
        $times[date('Y-m-d H:i:s',$param['end_time'])] = $end_long;
        foreach ($times as $k=>$v) {
            $param['createtime'] = $k;
            $param['long_time'] = $v;
            LogReadModel::query()->create($param);
            if ($v >= self::ACTIVETIME && $param['os'] !=3) {
                //阅读时间超过15分钟的为活跃设备 h5不记录
                $date = date('Y-m-d',strtotime($k));
                $daytime = LogActiveModel::query()->where(['device'=>$param['device'],'channel'=>$param['channel']])
                    ->whereBetween('createtime',[$date,date('Y-m-d 23:59:59',strtotime($k))])
                    ->value('createtime');
                if (!$daytime) {
                    //活跃留存
                    LogActiveModel::query()->create($param);
                }
            }
        }
    }

    /**
     * 听书数据
     * @param $param
     */
    public function listenTime($param)
    {
        $data = $param;
        $data['start_time'] = date('Y-m-d H:i:s',$param['start_time']);
        $data['end_time'] = date('Y-m-d H:i:s',$param['end_time']);
        $data['createtime'] = date('Y-m-d H:i:s');
        $data['long_time'] = round(($param['end_time'] - $param['start_time'])/60);
        LogListenModel::query()->create($data);
    }

    /**
     * 搜索记录
     * @param string $keyname
     */
    public function searchLog($param)
    {
        $param['createtime'] = date('Y-m-d H:i:s');
        $param['content'] = substr($param['search'],0,225);
        LogSearchModel::query()->create($param);
    }
    /**
     * 浏览书籍详情记录
     * @param string $keyname
     */
    public function lookLog($param)
    {
        $book_id = $param['book_id'];
        if (empty($book_id)) return;
        //计入redis存储 人气值 （每2小时更新数据库一次）
        $hash_book_id = getHashTable($book_id,'HASH_BOOK',100);
        $key = $this->key['BOOK_ID_READ_DETAIL'].':'.$hash_book_id;
        $this->redis->hIncrBy($key, $book_id, 1);
        //浏览具体详情记录数据库日志表
        $table = getHashTable($param['book_id']);
        $member_id = $param['member_id']?? 0;
        $device = isset($param['device'])? check_str_input($param['device']) :'';
        $device_model = isset($param['device_model'])? check_str_input($param['device_model']):'';
        $area = isset($param['area'])? check_str_input($param['area']):'';
        $channel = $param['channel']??0;
        $os = $param['os']??0;
        $createtime = date('Y-m-d H:i:s');
        $id = substr(md5(uniqid(microtime(true),true)),0,20);
        $sql = "INSERT INTO $table ".
            "(id,book_id, member_id,os,channel,device,device_model,area,createtime) ".
            "VALUES ".
            "('$id','$book_id','$member_id','$os','$channel','$device','$device_model','$area','$createtime')";
        try {
            DB::connection('log')->select($sql);
        }catch (QueryException $e){
            Log::info('LOOK_LOG_SQL='.$sql.': ERROR='.$e->getMessage());
        }

    }
    /**
     * 添加书架记录
     * @param string $keyname
     */
    public function shelfLog($param)
    {
        $book_id = $param['book_id'];
        if (empty($book_id)) return;
        //计入redis存储 在读人数 （每2小时更新数据库一次）
        $hash_book_id = getHashTable($book_id,'HASH_BOOK',100);
        $key = $this->key['BOOK_ID_ADD_SHELF'].':'.$hash_book_id;
        $this->redis->hIncrBy($key,$book_id,1);
        //具体详情记录数据库日志表
        $param['createtime'] = date('Y-m-d H:i:s');
        LogShelfModel::query()->create($param);
    }

    /**
     * 更新书籍人气值与在读人数值（2小时更新一次）
     */
    public function updateBookHotAndRead()
    {
        ini_set('max_execution_time', 60);

        $keyPrefix  = $this->key['BOOK_ID_READ_DETAIL'];

        $this->redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $iterator = null;
        $count = 1000;
        while ($arrKeys = $this->redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $books = $this->redis->hGetAll($key);
                if ($books){
                    foreach ($books as $book=>$v) {
                      BookModel::query()->where('id',$book)->increment('hot',$v);
                    }
                }

                $this->redis->del($key);
            }
        }
        $keyPrefix  = $this->key['BOOK_ID_ADD_SHELF'];
        $iterator = null;
        while ($arrKeys = $this->redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $shelf = $this->redis->hGetAll($key);
                if ($shelf){
                    foreach ($shelf as $shelf_book=>$v) {
                        $v = (int)$v;
                        BookModel::query()->where('id',$shelf_book)->increment('on_read',$v);

                    }
                }

                $this->redis->del($key);
            }
        }

    }

    /**
     * 点击广告记录
     * @param $param
     */
    public function advertClick($param)
    {
        $this->advertDataSave($param);
    }
    /**
     * 曝光广告记录
     * @param $param
     */
    public function advertExpo($param)
    {
        $this->advertDataSave($param,'exposure');
    }
    public function advertDataSave($param, $field = 'click')
    {
        if (empty($param['ad_id'])) throw new ApiExceptions(1007,'',['ad_id 不能为空']);
        $param['createtime'] = date('Y-m-d H:i:s');
            //多个广告
            foreach ($param['ad_id'] as $v) {
                unset($param['ad_id']);
                $material_id = AdModel::query()->where('id',$v)->value('material_id');
                $res  = LogAdvertModel::query()
                    ->where(['ad_id'=>$v, 'material_id'=>$material_id])
                    ->whereDate('createtime','=',date('Y-m-d'))
                    ->increment($field);
                if (!$res) {
                    $param[$field] = 1;
                    $param['material_id'] = $material_id;
                    LogAdvertModel::query()->whereDate('createtime','=',date('Y-m-d'))
                        ->updateOrCreate(
                            [
                                'createtime'=>date('Y-m-d'),
                                'ad_id'=>$v,
                                'material_id'=>$material_id,
                            ],
                            $param
                        );
                }
            }
    }
    /**
     * 每天凌晨零点定时计算一次存在redis缓存中；
     * 计算每本书的被加入书架中的用户 还有加入其他书的占比
     */
    public function dealShelfData()
    {
        ini_set('max_execution_time', 3600);
        ReadBookShelfCache::clearAll();
        $books = BookShelfModel::query()->selectRaw('DISTINCT book_Id ')->get();
        foreach ($books as $v) {
            $book_id = $v['book_Id'];
            $id = BookModel::query()->where(['id'=>$book_id,'status'=>1])->value('id');
            if (empty($id)) continue;
            $res = BookShelfModel::query()->from('book_shelf as a')
                ->leftJoin('book_shelf as b','a.member_id','=','b.member_id')
                ->leftJoin('book as c','c.id','=','a.book_Id')
                ->where(['b.book_Id'=>$book_id,'c.status'=>1])->where('a.book_Id','!=',$book_id)
                ->selectRaw('COUNT(a.id) as nums, a.book_Id as book_id')
                ->groupBy('a.book_Id')->orderBy('nums','desc')->get();
            $book_shelf = $res ? $res->toArray():[];
            $book_shelf =  array_column($book_shelf,'book_id');
            $nums = count($book_shelf);
            if ( $nums < 51) {
                $limit = 50 - $nums;
                $bu_books = BookModel::query()->where('status',1)->orderByRaw('RAND()')->limit($limit)->pluck('id')->toArray();
                $book_shelf = array_merge($book_shelf,$bu_books);
            }
            foreach ($book_shelf as $k=>$v) {
               /* $percent = round($v['nums'] / $members,2);
                if ($percent > 0){
                    $v['percent'] = $percent;
                    ReadBookShelfCache::getInstance($book_id)->addBookPercent($v,$percent);
                }*/
               //百分比改为 75～85 随机取
                $info = $v.':'.mt_rand(75,85);
                ReadBookShelfCache::getInstance($book_id)->addBookPercent($k,$info);

            }
        }

    }

    /**
     * 获取该本书的书友还在读书籍
     * @param $book_id
     * @return array
     */

    public function getReadPercentList($param)
    {
        $book_id = $param['book_id'];
        $row = $param['page_size'] ?? 8;
        $page = $param['page_index'] ?? 1;
        $startRow = ($page - 1) * $row;
        $date = date('Y-m-d');
        $key = $this->key['BOOK_ID_READ_PERCENT'].':date:'.$date.':'.$page.':'.$row.':'.$book_id;
        if ($rd = $this->redis->get($key)) return json_decode($rd,true);
        $res =  ReadBookShelfCache::getInstance($book_id)->getReadPercentList($startRow,$row);
        $total =  ReadBookShelfCache::getInstance($book_id)->getCount();
        $books = [];
        $bs = new BasicsService();
        $ttl = 80000;
        if ($total > 0 ) {
            //书架有的书籍从缓存中前一天统计的数据中取出
            foreach ($res as $book) {
                try {
                    $info = explode(':',$book);
                    $bookId = $info[0];
                    $person = $info[1];
                    $b_server = $bs->getBookInfo($bookId);
                    $b_server['percent'] = $person.'%';
                    $books[]  = $b_server;
                }catch (ApiExceptions $e){
                    continue;
                }

            }
        } else {
            //书架中一本都没有的情况,从书库中随机抽取50条
            $total = 50;
            $book_ids = BookModel::query()->where('status',1)
                ->orderByRaw('RAND()')->limit($total)->pluck('id')->toArray();
            foreach ($book_ids as $k=>$v) {
                //百分比改为 75～85 随机取
                    $per = $v.':'.mt_rand(75,85);
                    ReadBookShelfCache::getInstance($book_id)->addBookPercent($k,$per);
                    if ($row > $k){
                        $b_server = $bs->getBookInfo($v);
                        $b_server['percent'] =  mt_rand(75,85).'%';
                        $books[]  = $b_server;
                    }
            }

        }

        $data['grid_data'] = $books;
        $data['page'] = pageDeal($param,['total'=>$total,'last_page'=>ceil($total/$row)],'desc','percent');
        $this->redis->setex($key,$ttl,json_encode($data));
       return $data;

    }












}
