<?php


namespace App\Http\Service;


use App\Cache\BookByOverCache;
use App\Cache\BookOverHotCache;
use App\Cache\BookOverNewsCache;
use App\Cache\BookOverRecommendCache;
use App\Exceptions\ApiExceptions;
use JsonException as JsonExceptionAlias;

class BookByOverService extends BookService
{
    /**
     * 获取全部完本
     * @param $pageIndex
     * @param $pageSize
     * @return array
     */
    public function getBookByOver($pageIndex = 1, $pageSize = 10): array
    {
        $return = [
            'page_index' => $pageIndex,
            'page_size' => $pageSize,
            'grid_data' => []
        ];
        $result = BookByOverCache::getInstance(['OVER', $pageIndex, $pageSize])->getDetail();
        foreach ($result as $k) {
            try {
                $return['grid_data'][] = $this->getBookById($k);

            } catch (ApiExceptions $e) {
                continue;
            }
        }

        return $return;
    }

    /**
     * 获取完本推荐
     * @param int $pageIndex
     * @param int $pageSize
     * @return array
     * @throws ApiExceptions|JsonExceptionAlias
     */
    public function getOverRecommend($pageIndex = 1, $pageSize = 10): array
    {
        $return = [
            'page_index' => $pageIndex,
            'page_size' => $pageSize,
            'grid_data' => []
        ];
        $result = BookOverRecommendCache::getInstance(['RECOMMEND', $pageIndex, $pageSize])->getDetail();
        if ($result) {
            $result = array_slice($result, 0, $pageSize);
            foreach ($result as $k) {
                try {
                    $return['grid_data'][] = $this->getBookById($k);
                } catch (ApiExceptions $e) {
                    continue;
                }
            }
        }


        return $return;
    }

    /**
     * 最新完本书籍
     * @param int $pageIndex
     * @param int $pageSize
     * @return array
     */
    public function overBookByNews($pageIndex = 1, $pageSize = 10): array
    {
        $return = [
            'page_index' => $pageIndex,
            'page_size' => $pageSize,
            'grid_data' => []
        ];
        $result = BookOverNewsCache::getInstance(['NEWS', $pageIndex, $pageSize])->getDetail();
        foreach ($result as $k) {
            try {
                $return['grid_data'][] = $this->getBookById($k);
            } catch (ApiExceptions $e) {
                continue;
            }
        }

        return $return;
    }

    /**
     * 人气完本数据
     * @param int $pageIndex
     * @param int $pageSize
     * @return array
     */
    public function overBookByHot($pageIndex = 1, $pageSize = 10): array
    {
        $return = [
            'page_index' => $pageIndex,
            'page_size' => $pageSize,
            'grid_data' => []
        ];
        $result = BookOverHotCache::getInstance(['HOT', $pageIndex, $pageSize])->getDetail();
        foreach ($result as $k) {
            try {
                $return['grid_data'][] = $this->getBookById($k);
            } catch (ApiExceptions $e) {
                continue;
            }
        }

        return $return;
    }

}
