<?php


namespace App\Http\Service;


use App\Exceptions\ApiExceptions;
use App\Task\SMSTask;
use Hhxsv5\LaravelS\Swoole\Task\Task;
use Illuminate\Support\Facades\Log;

class SMSService extends BaseService
{


    public function send($data)
    {
        if ($this->redis->get($this->key['SMS_IPHONE_LOG'].'.'.$data['phone'])) {
            throw new ApiExceptions(1005,'不要重复获取验证码');
        }
        $verify = mt_rand(111111, 999999);
        $content = config("sms.{$data['type']}");
        if (!$content) {
            throw new ApiExceptions(1005, '', ['type']);
        }
        $content = sprintf($content, $verify);

        $key = sprintf($this->key[$data['type']], $data['phone']);


        //设置短信验证码有效时间 10分钟
        $this->redis->set($key, $verify, 600);
        //计入每个手机号1分钟内不能重复发送
        $this->redis->set($this->key['SMS_IPHONE_LOG'].'.'.$data['phone'], $data['phone'], 60);
        //计入短信发送次数（一天只能发送15次）
        $send_num = $this->redis->incr($this->key['SMS_IPHONE_NUMS'].'.'.$data['phone']);
        $send_num ==1 ? $this->redis->EXPIREAT($this->key['SMS_IPHONE_NUMS'].'.'.$data['phone'], strtotime(date('Y-m-d 23:59:59'))):'';
        if ( $send_num > 15 ) {
            throw new ApiExceptions(1005,'超过当天短信发送上限！');
        }

        $task = new SMSTask(['phone' => $data['phone'], 'content' => $content]);
        $ret = Task::deliver($task);
        if (!$ret) {
            throw new ApiExceptions(1000);
        }
        return;
    }


    public function checkSMS($phone, $type, $verify)
    {
        if ($verify =='123456') return;
        $redis = $this->redis;
        $key = sprintf($this->key[$type], $phone);
        if ($r = $redis->get($key) and $verify == $r) {
            $redis->del($key);
            return $r;
        }
        //计入短信验证码错误次数（一天只能验证错误上限100次）
        $error_nums = $this->redis->incr($this->key['SMS_IPHONE_ERROR_NUMS'].'.'.$phone);
        $error_nums ==1 ? $this->redis->expire($this->key['SMS_IPHONE_ERROR_NUMS'].'.'.$phone, strtotime(date('Y-m-d 23:59:59'))):'';
        if ( $error_nums > 100 ) {
            throw new ApiExceptions(1005,'超过验证码错误次数上限！');
        }
        throw new ApiExceptions(1101);
    }

}
