<?php

namespace App\Http\Operate\Common;

use App\Cache\TokenCache;
use App\Exceptions\ApiExceptions;
use App\Http\Operate\BaseOperate;
use App\Http\Service\TokenService;
use App\Model\MemberGetuiModel;
use Illuminate\Support\Facades\Log;

/**
 * 刷新token
 * Class RefreshToken
 * @package App\Http\Operate\Common
 */
class RefreshToken extends BaseOperate
{
    private $uid;
    protected function check()
    {
        if(!$this->request->header('RefreshToken'))
        {
            throw new ApiExceptions(401);
        }
        $uid = TokenCache::getRefreshToken($this->request->header('RefreshToken'));

        if(!$uid)
        {
            TokenCache::delRefreshToken($this->request->header('RefreshToken'));
            throw new ApiExceptions(401);//
        }


        $result = TokenService::checkRefreshToken($this->request->header('RefreshToken'));

        if(!$result)
        {
            TokenCache::delRefreshToken($this->request->header('RefreshToken'));
            throw new ApiExceptions(401);//
        }

        //权限判断
        if($result->scopes != 2)
        {
            throw new ApiExceptions(401);//
        }

        if(!$result->uid)
        {
            TokenCache::delRefreshToken($this->request->header('RefreshToken'));
            throw new ApiExceptions(401);//
        }

        $this->uid = $result->uid;
    }

    protected function doBusiness()
    {
        // TODO: Implement doBusiness() method.
        //生成token
        list($accessToken , $refreshToken) = TokenService::generateToken($this->uid);
             $appGuid = $this->request->get('appGuid',0);
             $getuiCid=$this->request->get('getuiCid',0);
             $os = $this->request->get('os',0);
             if ( $os ==1 && $appGuid) {
                 //安卓
                 MemberGetuiModel::query()
                     ->where(['member_id'=>$this->uid,'app_guid'=>trim($appGuid)])
                     ->update(['status'=>0,'exp'=>intval(time()+ env('JWT_REFRESH_TTL' , 2592000))]);
             } elseif($getuiCid) { //ios
                 MemberGetuiModel::query()
                     ->where(['member_id'=>$this->uid,'getui_cid'=>trim($getuiCid)])
                     ->update(['status'=>0,'exp'=>intval(time()+ env('JWT_REFRESH_TTL' , 2592000))]);
             }

        return [
            'authorization' => $accessToken,//访问接口的令牌
            'refreshToken' => $refreshToken,//刷新令牌
        ];
    }
}
