<?php

namespace App\Http\Operate\Mine;

use App\Cache\MemberCache;
use App\Cache\ShelfCache;
use App\Exceptions\ApiExceptions;
use App\Model\BookModel;
use App\Tools\Redis;
use Illuminate\Support\Facades\DB;

/**
 * 删除书架
 * Class DelBookShelf
 * @package App\Http\Operate\Mine
 */
class DelBookShelf extends AddBookShelf
{
    protected function check()
    {
        if(empty($this->bookIdArr))
        {
            throw new ApiExceptions(1005 , '书籍ID不能为空！');
        }
    }

    protected function doBusiness()
    {
        $uid = $this->request->uid;
        $res = DB::table('book_shelf')->whereIn('book_Id' , $this->bookIdArr)
            ->where('member_id', $uid)
            ->delete();

        if(!$res) throw new ApiExceptions(1000);

        foreach ($this->bookIdArr as $bookId)
        {
            ShelfCache::getInstance($uid)->removeBookShelf($bookId);
            $hash_book_id = getHashTable($bookId,'HASH_BOOK',100);
            $key = config('cache_key.log.BOOK_ID_ADD_SHELF').':'.$hash_book_id;
            $redis = Redis::getInstance();
            $redis->hIncrBy($key,$bookId,-1);
        }
       //删除书架字符序列化缓存
        Redis::getInstance()->del(config('cache_key.shelf.BOOK_SHELF_STRING').":UID:".$uid);
        return;
    }
}
