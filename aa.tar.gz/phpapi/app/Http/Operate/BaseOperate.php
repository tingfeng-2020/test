<?php

namespace App\Http\Operate;

//use App\Traits\CommonTrait;
use Illuminate\Http\Request;
use Laravel\Lumen\Routing\ProvidesConvenienceMethods;

/**
 * Class BaseOperate
 * @package App\Http\Operate
 */
abstract class BaseOperate
{
    use ProvidesConvenienceMethods;
    //use CommonTrait;
    /**
     * @var Request $request
     */
    protected $request;
    /**
     * @var array|mixed 请求数据
     */
    //protected $data;

    public function __construct(Request $request)
    {
        //$this->data = json_decode($request->getContent() , true);

        $this->request = $request;

        //var_dump($this->data);exit;
    }

    protected function check(){}

    public function done()
    {
        $this->check();
        return $this->doBusiness();
    }

    abstract protected function doBusiness();

    public function __get($name)
    {
        // TODO: Implement __get() method.
        return isset($this->data[$name]) ? $this->data[$name] : null;
    }
}