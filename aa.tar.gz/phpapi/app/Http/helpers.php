<?php

use Illuminate\Support\Facades\DB;

if ( ! function_exists('mediaHost'))
{
    /**
     * Get the configuration path.
     *
     * @param  string $path
     * @return string
     */
    function mediaHost($path = '')
    {
        return config('app_base.media_host');
    }
}
/**
 * 获取分页行数
 * @param $data
 * @return int
 */
 function getPageSize($data)
{
    return $data['page_size']??config('app_base.pageSize');
}
/**
 * 分类树
 * @param $array
 * @param string $parent_field
 * @param string $sub_name
 * @return array
 */
if ( ! function_exists('getTree')) {
    function getTree($array, $parent_field = 'parentId', $sub_name = 'sub_cate',$id ='id')
    {
        $items = array();
        foreach($array as $value){
            $items[$value[$id]] = $value;
        }
        $tree = array();
        foreach($items as $key => $value){
            if(isset($items[$value[$parent_field]])){
                $items[$value[$parent_field]][$sub_name][] = &$items[$key];
            }else{
                $tree[] = &$items[$key];
            }
        }
        unset($items);
        return $tree;

    }
}
/**
 * 分页格式封装（为和kevin之前返回的格式保持一致）
 */
if ( ! function_exists('pageDeal')) {
    function pageDeal($param, $res, $orderType= 'desc', $orderField = 'id')
    {
        $data['page_index'] = $param['page_index']??1;
        $data['page_size'] = $param['page_size']??10;
        $data['total_count'] = $res['total']??0;
        $data['page_count'] = $res['last_page']??1;
        $data['order_type'] = $orderType;
        $data['order_field'] = $orderField;
       return $data;
    }
}
/**
 * 评论时间处理
 * @param $unixTime
 * @return false|string
 */
function countDownTime($unixTime)
{
    if( $unixTime == 0 )
    {
        return "";
    }
    if( date('Y',$unixTime) == date('Y') ) {
        if( date('n.j',$unixTime) == date('n.j') )
        {//今天的
            return date('H:i',$unixTime);
        }else{
            return date('m-d H:i',$unixTime);
        }
    } else {
        return date('Y m-d H:i',$unixTime);
    }



    /* //以下为旧的 比较的时间格式化
     $showTime = date('Y',$unixTime)."年".date('n',$unixTime)."月".date('j',$unixTime)."日 ".date('H:i',$unixTime);

    if( date('Y',$unixTime) == date('Y') )
    {
        $showTime = date('n',$unixTime)."月".date('j',$unixTime)."日 ".date('H:i',$unixTime);

        if( date('n.j',$unixTime) == date('n.j') )
        {
            $timeDifference = time() - $unixTime + 1;

            if( $timeDifference < 60 )
            {
                return $timeDifference."秒前";
            }

            if( $timeDifference >= 60 && $timeDifference < 3600 )
            {
                return floor($timeDifference/60)."分钟前";
            }

            return date('H:i',$unixTime);
        }

        if( date('n.j',($unixTime+86400)) == date('n.j') )
        {
            return "昨天 ".date('H:i',$unixTime);
        }
    }

    return $showTime;
    */
}
function redisRowDeal($param)
{
    $page = $param['page_index']??1;
    $page_size = getPageSize($param);
    $startRow = ($page-1) * $page_size;
    $endRow = $startRow + $page_size -1;
   return compact('startRow','endRow');
}
if (! function_exists('config_path')) {
    /**
     * Get the configuration path.
     *
     * This is a polyfill for the missing shorthand function in lumen.
     *
     * @param  string  $path
     * @return string
     */
    function config_path($path = '')
    {
        return app()->basePath('config').($path ? DIRECTORY_SEPARATOR.$path : $path);
    }
}
function getFilePath($url='')
{
    if (empty($url)) return $url;
      $pos = stripos($url,'media');
     $url = substr($url,$pos);
    return $url;
}
//隐藏手机号
function hidePhone($phone){
    return substr_replace($phone,'****',3,4);
}
//字符js\sql 防注入
function check_str_input($str='')
{
    if (empty($str)) return $str;
    $str = htmlspecialchars(addslashes(trim($str)));
    return $str;
}
//字符转义反解析
function str_resolve($str='')
{
    if (empty($str)) return $str;
    $str = stripcslashes(htmlspecialchars_decode($str));
    return $str;
}
//默认昵称
function defaultNickname($account)
{
    return '书友'.substr($account,1,2).substr($account,7);
}
//字节转换
function formatBytes($size) {

    $units = array('B', 'KB', 'MB', 'GB', 'TB');

    for ($i = 0; $size >= 1024 && $i < 4; $i++) {

        $size /= 1024;

    }
    return round($size, 1).$units[$i];

}

/**
 * hash散裂数据库表规则
 * @param $code //参与散裂计算参数
 * @param string $table //表前缀
 * @param int $s //表数量-1
 * @return string
 */
function getHashTable($code,$table ='log_look',$s=9){
    $hash = sprintf("%u", crc32($code));
    $hash1 = intval(fmod($hash, $s));
    return $table."_".$hash1;
}
/**
 * 调试sql语句
 */
function sqlDump()
{
    DB::listen(function ($query) {
        $i = 0;
        $rawSql = preg_replace_callback('/\?/', function ($matches) use ($query, &$i) {
            $item = isset($query->bindings[$i]) ? $query->bindings[$i] : $matches[0];
            $i++;
            return gettype($item) == 'string' ? "'$item'" : $item;
        }, $query->sql);
        unset($i);
        echo $rawSql, "\n\n";
    });
}

