<?php

namespace App\Http\Controllers\V1_1\Mine;

use App\Cache\MemberCache;
use App\Cache\ShelfCache;
use App\Exceptions\ApiExceptions;
use App\Http\Controllers\Controller;
use App\Http\Operate\Mine\AddBookShelf;
use App\Http\Operate\Mine\DelBookShelf;
use App\Http\Service\BasicsService;
use App\Http\Service\BookService;
use App\Model\BookChapterModel;
use App\Model\BookModel;
use App\Model\BookShelfModel;
use App\Tools\Redis;
use Illuminate\Http\Request;


/**
 * 我的书架
 * Class ShelfController
 * @package App\Http\Controllers\V1_1\Mine
 */
class ShelfController extends Controller
{
    /**
     * 添加书架
     * @param Request $request
     * @return mixed
     */
    public function add(Request $request)
    {
        $obj = new AddBookShelf($request);
        return $obj->done();
    }

    /**
     * 删除书架
     * @param Request $request
     * @return mixed
     */
    public function del(Request $request)
    {
        $obj = new DelBookShelf($request);
        return $obj->done();
    }

    /**
     * 获取书架列表
     * @param Request $request
     * @return mixed
     */
    public function index(Request $request)
    {
        $uid = $request->uid;
        $bookIdArr = ShelfCache::getInstance($uid)->getBookShelfList();
        $data = [];
        $redis = Redis::getInstance();
        $key = config('cache_key.shelf.BOOK_SHELF_STRING').":UID:".$uid;
        if ($rd = $redis->get($key)) return json_decode($rd,true);
        $bs = new BasicsService();
            foreach ($bookIdArr as $bookId)
            {
                    try {
                        $shelf = ShelfCache::getInstance(['book_id'=>$bookId,'uid'=>$uid]);
                        $b_server = $bs->getBookInfo($bookId);
                        $b_server['status'] = 1;
                        $b_server['book_update_time'] = $shelf->book_last_time;
                        $b_server['minute'] = round((time() - strtotime($b_server['last_time']))/60);
                        $data[]  = $b_server;
                    } catch (ApiExceptions $e){

                    }
            }

        $redis->setex($key,config('cache.ttl'),json_encode($data));
        return $data;
    }
    /**
     * 没登录状态获取书籍更新时间
     */
    public function updateLastTime(Request $request)
    {
        $bookIdArr = json_decode($request->getContent(), true);
        if (!empty($bookIdArr)) {
            $redis = Redis::getInstance();
            $key = config('cache_key.shelf.BOOK_SHELF_UPDATE').':BOOK_IDS:'.json_encode($bookIdArr);
            if ($rd = $redis->get($key)) return json_decode($rd,true);
            $books = BookModel::query()->whereIn('id', $bookIdArr)->get(['id', 'last_time', 'status', 'book_status']);
            foreach ($books as &$v) {
                $chapter_name = BookChapterModel::query()->where('book_id', $v['id'])->orderBy('sequence', 'desc')->value('name');
                $v['book_chapter_name'] = $chapter_name;
                $v['minute'] = round((time() - strtotime($v['last_time'])) / 60);
            }
            unset($v);
            $redis->setex($key,config('cache.ttl'),json_encode($books));
            return $books;
        }


    }
    /**
     *当我的书架里的书有小红点的时候，点击查看时系统自动同步最新书箱时间
     */
    public function bookLastTime(Request $request)
    {
        $this->validate($request, [
            'book_id' => 'required|integer'
        ]);
        $book_id = $request->get('book_id');
        $uid = $request->get('uid');
        $last_time = BookModel::query()->where('id', $book_id)->value('last_time');
        BookShelfModel::query()->where(['book_Id'=>$book_id,'member_id'=>$uid])->update(['book_last_time' => $last_time]);
        ShelfCache::getInstance(['book_id'=>$book_id,'uid'=>$uid])->updateFieldCache('book_last_time',$last_time);
        Redis::getInstance()->del(config('cache_key.shelf.BOOK_SHELF_STRING').":UID:".$uid);
    }


    public function memberByLike(Request $request)
    {
        $this->validate($request, [
            'page_index' => 'integer',
            'page_size' => 'integer|max:10',
        ]);
        $bookService = new BookService();
        return $bookService->getBookByLike($request->get('device'), $request->get('page_index', 1), $request->get('page_size', 10), $request->get('uid'), $request->get('class_id'));

    }

}
