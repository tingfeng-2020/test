<?php

namespace App\Http\Controllers\V1_1\Mine;

use App\Http\Controllers\Controller;
use App\Model\ReflectModel;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;


/**
 * 举报
 * Class ReflectController
 * @package App\Http\Controllers\V1_1\Mine
 */
class ReflectController extends Controller
{
    /**
     * 提交举报
     * @param Request $request
     * @return mixed
     * @throws ValidationException
     */
    public function index(Request $request)
    {
        $this->validate($request , [
            'type' => 'required|in:1,2,3,4,5,6,7',
            'book_id' => 'required|integer',
            'tid'=>'required_if:type,7',
            'rid'=>'required_if:type,7'

        ]);

        $reflect = new ReflectModel();
        $reflect->member_id = $request->uid;
        $reflect->book_id = $request->book_id;
        $reflect->type = $request->type;
        $reflect->createtime = date('Y-m-d H:i:s');
        if ($request->type ==7) {
            $reflect->tid = $request->get('tid',0);
            $reflect->rid = $request->get('rid',0);
        }
        $reflect->content = $request->get('content','');
        $reflect->save();

        return;
    }
}
