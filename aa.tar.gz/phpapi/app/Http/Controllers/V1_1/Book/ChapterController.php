<?php


namespace App\Http\Controllers\V1_1\Book;


use App\Exceptions\ApiExceptions;
use App\Http\Controllers\Controller;
use App\Http\Service\ChapterService;
use Illuminate\Http\Request;

class ChapterController extends Controller
{


    public function getBookCatalogue(Request $request){
        $this->validate($request, [
            'book_id' => 'required|int',
        ]);
        $service = new ChapterService();
        return $service->getChapterList($request->get('book_id'));

    }


    public function getChapter(Request $request){
        $this->validate($request, [
            'chapter_id' => 'required|int',
        ]);

        $service = new ChapterService();
        return $service->getChapter($request->get('chapter_id'));
    }

    public function getBookByNum (Request $request) {
        $this->validate($request, [
            'book_id' => 'required|int',
            'start_sequence' => 'required|int',
            'end_sequence' => 'required|int',
        ]);
        if($request->get('end_sequence')-$request->get('start_sequence') > 100){
            throw new ApiExceptions(1110);
        }
        $service = new ChapterService();
        return $service->getChapterByNum($request->get('book_id'),$request->get('start_sequence'),$request->get('end_sequence'));
    }






}
