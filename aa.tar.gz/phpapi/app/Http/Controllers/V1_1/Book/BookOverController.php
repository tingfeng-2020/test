<?php
/**
 * 完本书籍
 */

namespace App\Http\Controllers\V1_1\Book;


use App\Http\Controllers\Controller;

use App\Http\Service\BookByOverService;
use Illuminate\Http\Request;

class BookOverController extends Controller
{


    public function getBookByOver(Request $request): array
    {
        $this->validate($request, [
            'page_index' => 'integer',
            'page_size' => 'integer|max:20',
        ]);
        $service = new BookByOverService();
        return $service->getBookByOver($request->get('page_index', 1), $request->get('page_size', 10));

    }

    public function recommend(Request $request): array
    {
        $this->validate($request, [
            'page_index' => 'integer',
            'page_size' => 'integer|max:20',
        ]);
        $service = new BookByOverService();
        return $service->getOverRecommend($request->get('page_index'), $request->get('page_size'));
    }


    public function overBookByNews(Request $request): array
    {
        $this->validate($request, [
            'page_index' => 'integer',
            'page_size' => 'integer|max:20',
        ]);
        $service = new BookByOverService();
        return $service->overBookByNews($request->get('page_index'), $request->get('page_size'));
    }

    public function overBookByHot(Request $request): array
    {
        $this->validate($request, [
            'page_index' => 'integer',
            'page_size' => 'integer|max:20',
        ]);
        $service = new BookByOverService();
        return $service->overBookByHot($request->get('page_index'), $request->get('page_size'));
    }
}
