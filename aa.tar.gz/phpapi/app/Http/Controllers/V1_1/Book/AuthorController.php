<?php


namespace App\Http\Controllers\V1_1\Book;


use App\Http\Controllers\Controller;

use App\Http\Service\AuthorService;
use Illuminate\Http\Request;

class AuthorController extends Controller
{


    /**
     * 获取作者信息
     * @param Request $request
     * @throws \Illuminate\Validation\ValidationException
     */
    public function getAuthorInfo(Request $request)
    {
        $this->validate($request, [
            'author_id' => 'required|int',
        ]);

        $service = new AuthorService();

        return $service->getAuthorInfo($request->get('author_id'));


    }


}
