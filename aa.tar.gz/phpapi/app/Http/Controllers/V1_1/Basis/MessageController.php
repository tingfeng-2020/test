<?php

namespace App\Http\Controllers\V1_1\Basis;

use App\Http\Controllers\Controller;
use App\Http\Service\MessageService;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class MessageController extends Controller
{
    protected $service;

    public function __construct(MessageService $messageService)
    {
        $this->service = $messageService;
    }

    /**
     * @param Request $request
     * @return bool|mixed|string
     * @throws ValidationException
     */
    public function getNotifyMessage(Request $request)
    {
        $this->validate($request,[
            'type'=>'required|integer',
            'page_index'=>'integer',
            'page_size'=>'integer|max:20'
        ]);
        return $this->service->getNotifyMessage($request->all());
    }

    /**
     * 更新消息状态(根据消息id)
     * @param Request $request
     * @throws ValidationException
     */
    public function messageUpdate(Request $request)
    {
        $this->validate($request,[
            'id'=>'required',
            'status'=>'required|integer',
        ]);
        return $this->service->messageUpdate($request->all());
    }

    /**
     * 更新消息状态(根据消息类型)
     * @param Request $request
     * @throws ValidationException
     */
    public function messageUpdateByType(Request $request)
    {
        $this->validate($request,[
            'type'=>'required',
            'status'=>'required|integer',
        ]);
        return $this->service->messageUpdateByType($request->all());
    }

    /**
     * 消息数量
     * @param Request $request
     * @return array|bool|mixed|string
     */

    public function messageCount(Request $request)
    {
        return $this->service->messageCount($request->get('uid'));
    }

    /**
     * 消息详情
     * @param Request $request
     * @return array
     * @throws ValidationException
     */
    public function messageDetailed(Request $request)
    {
        $this->validate($request,[
            'id'=>'required|integer',
        ]);
        return $this->service->messageDetailed($request->get('id'));
    }
    public function pushMessage()
    {
        return $this->service->pushMessageTest();
    }
    public function pushMessageBu()
    {
        return $this->service->pushMessageBu();
    }

}
