<?php

namespace App\Http\Controllers\V1_1\UploadFile;

use App\Http\Controllers\Controller;
use App\Http\Service\FileService;
use Illuminate\Http\Request;

class FileController extends Controller
{
    protected $service;

    public function __construct(FileService $fileService)
    {
        $this->service = $fileService;
    }
    public function upload(Request $request)
    {
        ini_set('max_execution_time',60);
        //return $this->service->upload($request,'formFile');
        return $this->service->uploadOss($request,'formFile');
    }

}

