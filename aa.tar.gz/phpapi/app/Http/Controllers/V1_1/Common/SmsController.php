<?php

namespace App\Http\Controllers\V1_1\Common;

use App\Http\Controllers\Controller;
use App\Http\Operate\Common\GetSmsCode;
use Illuminate\Http\Request;

/**
 * 短信控制器
 * Class SmsController
 * @package App\Http\Controllers\V1_1\Common
 */
class SmsController extends Controller
{
    /**
     * 获取验短信证码
     * @param Request $request
     */
    public function get(Request $request)
    {
        $operate = new GetSmsCode($request);
        return $operate->done();
    }
}
