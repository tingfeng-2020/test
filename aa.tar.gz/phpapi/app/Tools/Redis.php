<?php


namespace App\Tools;


use Illuminate\Support\Facades\Log;

class Redis
{
    private static $instance;

    private function __construct()
    {

        $redis = app('redis');

        self::$instance = $redis;
    }

    public static function getInstance()
    {
//        try {
//            if (!(self::$instance instanceof self)) {
//                new self;
//                // self::$instance = Redis::connection();
//            }
//        } catch (\Exception $exception) {
//            Log::info($exception->getMessage());
//            new  self();
//        }
        return app('redis');
    }


}
