<?php

/**
 * 统一返回json
 * @param $result
 * @return \Illuminate\Http\JsonResponse
 */
function json($result = [])
{
    $code = isset($result['code']) ? $result['code'] : 200;
    return response()->json($result, $code);
}

/**
 * 统一返回array
 * @param int $code
 * @param $msg
 * @param array $data
 * @return array
 */
function back($code = 200, $msg = '', $data = [])
{
    return [
        'code' => $code,
        'msg'  => $msg,
        'data' => $data
    ];
}

/**
 * 可以统计中文字符串长度的函数
 * @param string $str 要计算长度的字符串
 * @return int
 *
 */
function abslength($str)
{
    if(empty($str)){
        return 0;
    }
    if(function_exists('mb_strlen')){
        return mb_strlen($str,'utf-8');
    }
    else {
        preg_match_all("/./u", $str, $ar);
        return count($ar[0]);
    }
}
