<?php

namespace App\Cache;

use App\Model\Bbs\BbsTopicModel;
use App\Tools\Redis;
use Illuminate\Support\Facades\Log;

/**
 * 评论缓存
 * Class BookCache
 * @package App\Cache
 */
class BbsCache extends BaseCache
{
    /**
     * @var string 用户的书架列表缓存键
     */
    private $bbsKey;
    private $tLikeKey;
    private $pushKey;
    private $commentsKey;
    private $tLikeNumKey;
    private $tTotal;

    protected function setDetailKey()
    {
        // TODO: Implement setDetailKey() method.
        $this->detailKey = config('cache_key.bbs.TID').'.'.$this->pk;
        $this->bbsKey = config('cache_key.bbs.BOOK').'.'.$this->pk;
        $this->tLikeKey = config('cache_key.bbs.TOPIC_LIKE').'.'.$this->pk;
        $this->pushKey = config('cache_key.bbs.PUSH_BBS');
        $this->commentsKey = config('cache_key.bbs.TOPIC_COMMENTS').'.'.$this->pk;
        $this->tLikeNumKey = config('cache_key.bbs.TOPIC_LIKE_NUM').'.'.$this->pk;
        $this->tTotal = config('cache_key.bbs.TOPIC_TOTAL').'.'.$this->pk;
    }

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        $tid = explode('.',$this->pk)[1];
       return BbsTopicModel::query()->from('bbs_topic as a')
            ->leftJoin('members as b','b.id','=','a.member_id')
            ->where('a.tid',$tid)
            ->selectRaw('a.tid,a.book_id,a.member_id,a.comments,a.likes,a.message,a.title,a.createtime,b.icon,IFNULL(b.nickname,b.account) as nick_name')
            ->first();

    }
    /**
     * 添加评论
     * @param int $bbsId 评论ID
     * @param bool $time 加入时间｜最近阅读时间
     * @return bool|int
     */
    public function addBbs($bbsId , $time = false)
    {
        if(empty($bbsId)) return false;
        !$time && $time = time();
        return Redis::getInstance()->zAdd($this->bbsKey ,$time , $bbsId);
    }

    /**
     * 添加条数
     * @param $nums
     * @param bool $set
     * @return bool|int
     */
    public function addTotal($nums=1, $set =false)
    {
        if ($set)
            return Redis::getInstance()->set($this->tTotal,$nums);
        else
            return Redis::getInstance()->incr($this->tTotal);
    }

    /**
     * 减数量
     * @return int
     */
    public function decrTotal()
    {
        return Redis::getInstance()->decr($this->tTotal);
    }

    /**
     * 获取总条数
     * @return bool|int|mixed|string
     */
    public function getTotal()
    {
        $count = Redis::getInstance()->get($this->tTotal);
        return empty($count)?0:$count;
    }
    /**
     * 获取评论列表，按照时间倒序
     * @return array
     */
    public function getBbsList($startRow=0, $row = 20)
    {
        return self::getSortedListKey($this->bbsKey , $startRow , $row);
    }
    /**
     * 移除
     * @param int $id 标识ID
     * @return bool|int
     */
    public function rem($id)
    {
        if(empty($id)) return false;
        return Redis::getInstance()->zRem($this->bbsKey , $id);
    }

    /**
     * 获取数量
     * @return int
     */
    public function getCount()
    {
        return self::getSortedListLen($this->bbsKey);
    }

    /**
     * 加入
     * @param int $uid
     * @return bool|int
     */
    public function addLog($uid=0)
    {
        if(empty($uid)) return false;
        return Redis::getInstance()->sAdd($this->tLikeKey,$uid);
    }


    /**
     * 是否点过赞
     * @param $uid
     * @return bool
     */
    public function is_like($uid)
    {
        $has_like = Redis::getInstance()->SISMEMBER($this->tLikeKey,$uid);
         return empty($has_like)? 0 :1;
    }

    /**
     * 添加评论条数
     * @return int
     */
    public function addComments($nums=0, $set=false)
    {
        if ($set)
            return Redis::getInstance()->set($this->commentsKey,$nums);
        else
            return Redis::getInstance()->incr($this->commentsKey);
    }

    /**
     * 递减评论条数
     * @return int
     */
    public function decrComments()
    {
        return Redis::getInstance()->decr($this->commentsKey);
    }

    /**
     * 获取评论条数
     * @return bool|mixed|string
     */
    public function getComments()
    {
        $num = Redis::getInstance()->get($this->commentsKey);
        return empty($num)?0:$num;
    }
    /**
     * 添加点赞条数
     * @return int
     */
    public function addLikes($nums = 1,$set=false)
    {
        if ($set)
            return Redis::getInstance()->set($this->tLikeNumKey,$nums);
        else
            return Redis::getInstance()->incr($this->tLikeNumKey);
    }

    /**
     * 递减点赞条数
     * @return int
     */
    public function decrLikes()
    {
        return Redis::getInstance()->decr($this->tLikeNumKey);
    }

    /**
     * 获取点赞条数
     * @return bool|mixed|string
     */
    public function getLikes()
    {
        $num = Redis::getInstance()->get($this->tLikeNumKey);
        return empty($num)?0:$num;

    }
    /**
     * 字段增长（整型增长）
     * @param string $field 字段
     * @param int $incr
     * @return bool|mixed
     */
    public function incr($field, $incr = 1)
    {
        $this->redis->hIncrBy($this->detailKey, $field, $incr);
    }


    /**
     * 清除评论相关缓存
     */
    public static function clearAll()
    {
        $keyPrefix = config('cache_key.bbs.TID').'.';

        $redis = Redis::getInstance();

        $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $iterator = null;
        $count = 1000;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }

        $keyPrefix = config('cache_key.bbs.TOPIC').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.TOPIC_LIKE').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.BOOK').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.TOPIC_COMMENTS').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.TOPIC_LIKE_NUM').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.TOPIC_TOTAL');
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.BOOK_TOPIC');
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
    }



}
