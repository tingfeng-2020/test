<?php


namespace App\Cache;


use App\Model\BookRecommendModel;

/**
 * 分类中所属书籍缓存
 * Class BookInClassCache
 * @package App\Cache
 */
class BookOverRecommendCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        //完本推荐直接查完书籍
        return BookRecommendModel::query()->orderBy('sort')->pluck('book_id')->toArray();


    }

    /**
     * 设置key值
     */
    protected function setKey(): void
    {

        $this->detailKey = $this->cacheConfig['key'] . $this->pk[0];
    }

    protected function saveCache(): void
    {
        foreach ($this->detail as $k => $v) {
            $this->redis->zAdd($this->detailKey, $k, $v);
        }
        $this->ttl();

    }


    protected function getCache(): void
    {

        [, $page, $pageSize] = $this->pk;
        $start = ($page - 1) * $pageSize;
        $end = $start + $pageSize;
        $max = $this->redis->zcard($this->detailKey);
        $pageCount = ceil($max / $pageSize);
        if ($max) {
            if ($page > $pageCount) {
                $this->detail = null;
            } else {
                $this->detail = $this->redis->ZRANGEBYSCORE($this->detailKey, $start, $end);

            }
        }


    }


}
