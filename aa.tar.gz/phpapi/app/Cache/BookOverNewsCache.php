<?php


namespace App\Cache;


use App\Model\BookModel;

/**
 * 分类中所属书籍缓存
 * Class BookInClassCache
 * @package App\Cache
 */
class BookOverNewsCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        return BookModel::query()->where('book_status', '1')->orderBy('last_time', 'desc')->limit(50)->pluck('id')->toArray();


    }

    /**
     * 设置key值
     */
    protected function setKey(): void
    {

        $this->detailKey = $this->cacheConfig['key'] . $this->pk[0];
    }

    protected function saveCache(): void
    {
        foreach ($this->detail as $k => $v) {
            $this->redis->zAdd($this->detailKey, $k, $v);
        }
        $this->ttl();
    }


    protected function getCache(): void
    {
        [, $page, $pageSize] = $this->pk;
        $start = ($page - 1) * $pageSize;
        $end = $start + $pageSize - 1;
        $max = $this->redis->zcard($this->detailKey);
        $pageCount = ceil($max / $pageSize);
        if ($max) {
            if ($page > $pageCount) {
                $this->detail = null;
            } else {
                $this->detail = $this->redis->ZRANGEBYSCORE($this->detailKey, $start, $end);
            }
        }
    }


}
