<?php

namespace App\Cache;

use App\Exceptions\ApiExceptions;
use App\Model\BookChapterModel;
use App\Model\BookModel;

/**
 * 书籍缓存
 * Class BookCache
 * @package App\Cache
 */
class BookCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        // TODO: Implement fromDb() method.
        $re = BookModel::query()->where('status', 1)->find($this->pk, ['id', 'book_name', 'word_quantity', 'author_id', 'chapter_quantity', 'book_imgurl', 'book_des', 'hot', 'on_read', 'last_time', 'book_status']);
        if($re){
            $result = $re->toArray();
            $chapter_quantity = BookChapterModel::query()->where('book_id', $this->pk)->count('id');
            $result['chapter_quantity'] = $chapter_quantity;
            $result['book_chapter_name'] = BookChapterModel::query()->orderBy('sequence', 'desc')->where('book_id', $this->pk)->first('name')->name ?? '';
            return $result;
        }

        throw new ApiExceptions(1105);
    }



}
