<?php

namespace App\Cache;

use App\Model\BookShelfModel;
use App\Model\MembersModel;
use App\Tools\Redis;
use Illuminate\Support\Facades\DB;

/**
 * 书架缓存类
 * Class MemberCache
 * @package App\Cache
 */
class ShelfCache extends BaseCache
{
    /**
     * @var string 用户的书架列表缓存键
     */
    private $bookShelfKey;

    protected function setDetailKey()
    {
        // TODO: Implement setDetailKey() method.
        $pk = is_array($this->pk) ? json_encode($this->pk) : $this->pk;
        $this->detailKey = config('cache_key.shelf.SHELF_INFO').'.'.$pk;
        $this->bookShelfKey = config('cache_key.shelf.BOOK_SHELF').'.'.$pk;
    }

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        // TODO: Implement fromDb() method.
        return BookShelfModel::where(['book_Id'=>$this->pk['book_id'],'member_id'=>$this->pk['uid']])->first(['book_Id','book_last_time']);
    }

    /**
     * 添加书架
     * @param int $bookId 书籍标识ID
     * @param bool $time 加入时间｜最近阅读时间
     * @return bool|int
     */
    public function addBookShelf($bookId , $time = false)
    {
        if(empty($bookId)) return false;
        !$time && $time = time();

        return Redis::getInstance()->zAdd($this->bookShelfKey , $time , $bookId);
    }

    /**
     * 判断书架中是否存在某书籍
     * @param int $bookId
     * @return bool
     */
    public function hasBook($bookId)
    {
        if(empty($bookId)) return false;

        return self::hasInSortedList($this->bookShelfKey , $bookId);
    }

    /**
     * 移除书架中的书籍
     * @param int $bookId 书籍标识ID
     * @return bool|int
     */
    public function removeBookShelf($bookId)
    {
        if(empty($bookId)) return false;
        return Redis::getInstance()->zRem($this->bookShelfKey , $bookId);
    }

    /**
     * 清除书架列表
     * @return int
     */
    public function delBookShelfList()
    {
        return Redis::getInstance()->del($this->bookShelfKey);
    }

    /**
     * 获取我的书架列表，按照时间倒序
     * @return array
     */
    public function getBookShelfList()
    {
        $res = self::getSortedListKey($this->bookShelfKey , 0 , -1);
        if (!empty($res)) return $res;
        $books = BookShelfModel::query()->where(['member_id'=>$this->pk])
            ->get(['createtime','book_Id']);
        if (empty($books->toArray())) return [];
        foreach ($books as $shelf) {
            $this->addBookShelf($shelf->book_Id , $shelf->createtime);
        }
      return  $this->getBookShelfList();

    }


    /**
     * 清除会员详情相关缓存
     */
    public static function clearAll()
    {
        $keyPrefix = config('cache_key.shelf.UID').'.';

        $redis = Redis::getInstance();

        $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $iterator = null;
        $count = 1000; // 测试时redis中大概有20w个key，用时约2s，当count为500时用时约4s，count越大时扫描用时越短（当然需要根据你的业务需要来定）

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }

        $keyPrefix = config('cache_key.shelf.BOOK_SHELF').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.shelf.SHELF_INFO').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
    }

    public static function reset()
    {
        self::clearAll();
        $list = MembersModel::all();
        if(empty($list))  return;

        foreach ($list as $member)
        {
            $cacheObj = new self($member->id);

            //书架列表
            $bookList = DB::table('book_shelf')->where('member_id' , $member->id)
                ->get(['book_Id' , 'book_last_time']);

            foreach($bookList as $book)
            {
                $cacheObj->addBookShelf($book->book_Id , $book->book_last_time);
            }
        }
    }
}
