<?php


namespace App\Cache;


use App\Model\BookListBookModel;

/**
 * 书单中的书籍
 * Class BookInClassCache
 * @package App\Cache
 */
class BookListBookCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        $re = BookListBookModel::query()->where('book_list_id', $this->pk);
        return $re ? $re->pluck('book_id') : '';


    }


}
