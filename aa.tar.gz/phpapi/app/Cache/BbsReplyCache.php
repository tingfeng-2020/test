<?php

namespace App\Cache;

use App\Model\Bbs\BbsReplyModel;
use App\Model\Bbs\BbsTopicModel;
use App\Tools\Redis;
use Illuminate\Support\Facades\Log;

/**
 * 评论详情缓存
 * Class BookCache
 * @package App\Cache
 */
class BbsReplyCache extends BaseCache
{
    /**
     * @var string 用户的书架列表缓存键
     */
    private $bbsKey;
    private $rLikeKey;
    private $rCommentsKey;
    private $rLikeNumKey;
    private $rTotal;

    protected function setDetailKey()
    {
        // TODO: Implement setDetailKey() method.
        $this->detailKey = config('cache_key.bbs.RID').'.'.$this->pk;
        $this->bbsKey = config('cache_key.bbs.REPLY').'.'.$this->pk;
        $this->rLikeKey = config('cache_key.bbs.REPLY_LIKE').'.'.$this->pk;
        $this->rCommentsKey = config('cache_key.bbs.REPLY_COMMENTS').'.'.$this->pk;
        $this->rLikeNumKey = config('cache_key.bbs.REPLY_LIKE_NUM').'.'.$this->pk;
        $this->rTotal = config('cache_key.bbs.REPLY_TOTAL').'.'.$this->pk;
    }

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        $rid = explode('.',$this->pk)[2];
       return BbsReplyModel::query()->from('bbs_reply as a')
            ->leftJoin('members as b','b.id','=','a.member_id')
            ->where('a.rid',$rid)
            ->selectRaw('a.rid,a.tid,a.member_id,a.comments,a.likes,a.message,a.createtime,b.icon,IFNULL(b.nickname,b.account) as nick_name,a.title')
            ->first();

    }
    /**
     * 回复评论
     * @param int $bbsId 评论ID
     * @param bool $time 加入时间｜最近阅读时间
     * @return bool|int
     */
    public function addBbs($bbsId , $time = false)
    {
        if(empty($bbsId)) return false;
        !$time && $time = time();
        return Redis::getInstance()->zAdd($this->bbsKey ,$time , $bbsId);
    }
    /**
     * 添加条数
     * @param $nums
     * @param bool $set
     * @return bool|int
     */
    public function addTotal($nums=1, $set =false)
    {
        if ($set)
            return Redis::getInstance()->set($this->rTotal,$nums);
        else
            return Redis::getInstance()->incr($this->rTotal);
    }

    /**
     * 减数量
     * @return int
     */
    public function decrTotal()
    {
        return Redis::getInstance()->decr($this->rTotal);
    }

    /**
     * 获取总条数
     * @return bool|int|mixed|string
     */
    public function getTotal()
    {
        $count = Redis::getInstance()->get($this->rTotal);
        return empty($count)?0:$count;
    }
    /**
     * 获取评论列表，按照时间倒序
     * @return array
     */
    public function getBbsList($startRow=0, $row = 20)
    {
        return self::getSortedListKey($this->bbsKey , $startRow , $row);
    }
    /**
     * 移除
     * @param int $id 标识ID
     * @return bool|int
     */
    public function rem($id)
    {
        if(empty($id)) return false;
        return Redis::getInstance()->zRem($this->bbsKey , $id);
    }
    public function getCount()
    {
        return self::getSortedListLen($this->bbsKey);
    }
    public function addLog($uid=0)
    {
        if(empty($uid)) return false;
        return Redis::getInstance()->sAdd($this->rLikeKey,$uid);
    }
    public function is_like($uid)
    {
        $has_like =  Redis::getInstance()->SISMEMBER($this->rLikeKey,$uid);
        return empty($has_like)?0:1;
    }

    /**
     * 添加评论条数
     * @return int
     */
    public function addComments($nums=0, $set =false)
    {
        if ($set)
            return Redis::getInstance()->set($this->rCommentsKey,$nums);
        else
            return Redis::getInstance()->incr($this->rCommentsKey);


    }

    /**
     * 递减评论条数
     * @return int
     */
    public function decrComments()
    {
        return Redis::getInstance()->decr($this->rCommentsKey);
    }

    /**
     * 获取评论条数
     * @return bool|mixed|string
     */
    public function getComments()
    {
        $num =  Redis::getInstance()->get($this->rCommentsKey);
        return empty($num)?0:$num;
    }

    /**
     * 添加点赞条数
     * @return int
     */
    public function addLikes($nums = 1, $set = false)
    {
        if ($set)
            return Redis::getInstance()->set($this->rLikeNumKey,$nums);
        else {
            return Redis::getInstance()->incr($this->rLikeNumKey);
        }


    }
    /**
     * 递减点赞条数
     * @return int
     */
    public function decrLikes()
    {
        return Redis::getInstance()->decr($this->rLikeNumKey);
    }

    /**
     * 获取点赞条数
     * @return bool|mixed|string
     */
    public function getLikes()
    {
        $num =  Redis::getInstance()->get($this->rLikeNumKey);
        return empty($num)?0:$num;
    }
    /**
     * 字段增长（整型增长）
     * @param string $field 字段
     * @param int $incr
     * @return bool|mixed
     */
    public function incr($field, $incr = 1)
    {
        $this->redis->hIncrBy($this->detailKey, $field, $incr);
    }
    /**
     * 清除评论相关缓存
     */
    public static function clearAll()
    {
        $keyPrefix = config('cache_key.bbs.RID').'.';

        $redis = Redis::getInstance();

        $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);
        $iterator = null;
        $count = 1000;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }

        $keyPrefix = config('cache_key.bbs.REPLY').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.REPLY_LIKE').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.REPLY_COMMENTS').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.REPLY_LIKE_NUM').'.';
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.REPLY_TOTAL');
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
        $keyPrefix = config('cache_key.bbs.BOOK_REPLAY');
        $iterator = null;

        while ($arrKeys = $redis->scan($iterator, $keyPrefix . '*', $count)) {
            foreach ($arrKeys as $key)
            {
                $redis->del($key);
            }
        }
    }



}
