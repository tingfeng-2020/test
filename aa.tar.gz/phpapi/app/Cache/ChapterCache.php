<?php

namespace App\Cache;

use App\Exceptions\ApiExceptions;
use App\Model\BookChapterModel;

/**
 * 书籍缓存
 * Class BookCache
 * @package App\Cache
 */
class ChapterCache extends BaseCache
{


    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        // TODO: Implement fromDb() method.
        $re = BookChapterModel::query()->where(['book_id' => $this->pk])->orderBy('sequence');


        if ($re) {
            return $re->get(['id', 'name', 'sequence', 'createtime'])->keyBy('sequence')->toArray();
        }
        throw new ApiExceptions(1105);
    }

    protected function dealUpdateCacheExt($data)
    {
        $this->detail = '';
        if ($data) {
            foreach ($data as $k => $v) {
                $data[$k] = json_encode($v);
            }
            $this->detail = $data;

        }


    }


}
