<?php


namespace App\Cache;


use App\Model\BookListClassifyModel;
use App\Model\BookListModel;

/**
 * 书单分类缓存
 * Class BookInClassCache
 * @package App\Cache
 */
class BookListCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        return BookListModel::query()->orderBy('sort')->where(['status' => 1])
            ->get(['id', 'name', 'img_url'])->toArray();

    }


    protected function dealUpdateCacheExt($data)
    {
        $this->detail = [];
        if($data){
            foreach ($data as $k=>$v){
                $this->detail[] = json_encode($v);
            }
        }



    }
}
