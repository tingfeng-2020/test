<?php


namespace App\Cache;


use App\Model\ClassifyModel;

/**
 *
 * 书籍分类缓存
 * Class ClassifyCache
 * @package App\Cache
 */
class ClassifyInParentCache extends BaseCache
{


    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        return ClassifyModel::query()->where(['parent_id' => $this->pk, 'status' => 1])->orderBy('sort')->get(['id', 'name', 'related_name', 'icon']);
    }

    protected function dealUpdateCacheExt($data): void
    {

        $arr = [];
        foreach ($data as $k => $v) {
            $arr[] = json_encode($v);
        }

        $this->detail = $arr;

    }


}
