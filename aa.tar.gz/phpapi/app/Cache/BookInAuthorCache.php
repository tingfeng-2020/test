<?php

namespace App\Cache;

use App\Model\BookModel;
use App\Tools\Redis;

/**
 * 书籍缓存
 * Class BookCache
 * @package App\Cache
 */
class BookInAuthorCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        return BookModel::query()->where('author_id', $this->pk)->pluck('id')->toArray();

    }

    protected function saveCache()
    {
        if ($this->detail) {
            Redis::getInstance()->set($this->detailKey, $this->detail);
            $this->ttl();
        }

    }


}
