<?php


namespace App\Cache;


use App\Http\Service\ClassService;
use App\Model\BookClassModel;
use App\Model\Log\LogReadModel;

/**
 * 用户阅读记录
 * Class BookInClassCache
 * @package App\Cache
 */
class BookRedCache extends BaseCache
{


    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        //根据uid去取用户阅读记录
        [$key, $type] = $this->pk;
        $model = LogReadModel::query();
        if ($type === 1) {
            $result = $model->where('uid', $key);
        } else {
            $result = $model->where('device', $key);
        }

        return $result->distinct()->pluck('book_id')->toArray();
    }


    /**
     * 设置key值
     */
    protected function setKey(): void
    {

        $this->detailKey = $this->cacheConfig['key'] . $this->pk[0];
    }


}
