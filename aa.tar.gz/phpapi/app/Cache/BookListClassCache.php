<?php


namespace App\Cache;


use App\Model\BookListClassifyModel;

/**
 * 书单分类缓存
 * Class BookInClassCache
 * @package App\Cache
 */
class BookListClassCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        $return = [];
        $model =  BookListClassifyModel::query()->orderBy('sort')->get(['name','id']);
        if($model){
            $return = array_map('json_encode',$model->toArray());
        }
        return $return;

    }


}
