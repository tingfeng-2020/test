<?php

namespace App\Cache;

use App\Exceptions\ApiExceptions;
use App\Model\BookAuthorModel;
use App\Model\BookChapterModel;
use App\Model\BookModel;

/**
 * 书籍缓存
 * Class BookCache
 * @package App\Cache
 */
class AuthorCache extends BaseCache
{

    /**
     * @inheritDoc
     */
    protected function fromDb()
    {

        $re = BookAuthorModel::query()->where('id', $this->pk)->first(['name', 'avatar', 'intro', 'id']);
        if ($re) {
            return $re->toArray();
        }
        return [];


    }


}
