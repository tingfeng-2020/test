<?php

namespace App\Cache;


use App\Model\RankingClassifyBookModel;
use App\Tools\Redis;

/**
 * 1.1 已弃用
 * 排行榜
 * Class BookCache
 * @package App\Cache
 */
class RankingClassifyCache extends BaseCache
{


    /**
     * @inheritDoc
     */
    protected function fromDb()
    {
        $result = RankingClassifyBookModel::query()->orderBy('sort')->where('status', 1);
        if ($result) {
            return $result->get(['name', 'id'])->toArray();
        }
        return [];
    }

    /**
     * 保存数据到缓存中
     */
    protected function saveCache()
    {
        if($this->detail){
            Redis::getInstance()->set($this->detailKey,json_encode($this->detail),$this->ttl);
        }

    }


    protected function getCache()
    {
        $this->detail = Redis::getInstance()->get($this->detailKey);
    }




}
