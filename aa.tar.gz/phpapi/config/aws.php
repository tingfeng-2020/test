<?php

return [
    'version' =>'latest',
    'region'  => env('AWS_REGION', 'cn-north-1'),
    'endpoint' => env('AWS_ENDPOINT', 'http://10.1.7.10:8080/'),
    'use_path_style_endpoint' =>true,
    'credentials' => [
        'key'    => env('AWS_KEY', 'minio'),
        'secret' => env('AWS_SECRET', 'minio123'),
    ],
    // You can override settings for specific services
    'Ses' => [
        'region' => env('AWS_SES_REGION', 'cn-north-1'),
    ],
];
