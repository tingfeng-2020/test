<?php
return[
    'pageSize' => 10,//每页默认条数
    'media_host' => env('MEDIA_HOST','http://47.115.81.54:9000/'),//文件资源域名
    'es_index'=>[ //es 索引
        'openOrCloseApp'=>'reader_option_log',//打开或关闭app所有数据
        'deviceLog'=>'device_log',//记录设备留存记录
        'readTime'=>'read_book_data',//阅读记录数据
        'listenTime'=>'listen_book_data',//听书记录数据
        'searchLog'=>'search_log',//搜索记录数据
    ]
];
