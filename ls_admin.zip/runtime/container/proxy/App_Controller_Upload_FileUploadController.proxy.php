<?php

declare (strict_types=1);
namespace App\Controller\Upload;

use App\Annotation\ResponseDataWrap;
use App\Constants\BusinessCode;
use App\Controller\AbstractController;
use App\Exception\BusinessException;
use App\Service\Upload\FileUploadService;
use Hyperf\Filesystem\FilesystemFactory;
/**
 * @ResponseDataWrap()
 */
class FileUploadController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    protected $service;
    protected $filesystem;
    public function __construct(FileUploadService $service, FilesystemFactory $factory)
    {
        self::__handlePropertyHandler(__CLASS__);
        parent::__construct();
        $this->service = $service;
        $this->filesystem = $factory->get('oss');
    }
    /**
     * 公共上传文件接口
     * @return array
     */
    public function index() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            if (!$this->request->hasFile('file')) {
                throw new BusinessException(BusinessCode::BAD_REQUEST, '文件不能为空');
            }
            return $this->service->upload($this->request->file('file'), $this->filesystem);
        });
    }
    /**
     * 音频文件上传接口，增加 文件大小size、音频时长duration 字段返回
     * @return array
     */
    public function uploadAudio() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            if (!$this->request->hasFile('file')) {
                throw new BusinessException(BusinessCode::BAD_REQUEST, '文件不能为空');
            }
            return $this->service->uploadAudio($this->request->file('file'), $this->filesystem);
        });
    }
}