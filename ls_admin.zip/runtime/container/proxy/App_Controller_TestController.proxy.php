<?php

declare (strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://doc.hyperf.io
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */
namespace App\Controller;

use App\Aspect\FooAspect;
use App\Constants\ErrorCode;
use App\Exception\ApiException;
use App\Exception\BusinessException;
use App\Exception\FooException;
use App\Model\Permission;
use App\Model\Role;
use App\Model\User;
use App\Request\FooRequest;
use App\Service\UserServiceEvent;
use App\Tools\Aes;
use App\Tools\PasswordHash;
use Hyperf\Contract\TranslatorInterface;
use Hyperf\HttpServer\Annotation\AutoController;
use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Contract\RequestInterface;
use Hyperf\Paginator\Paginator;
use Hyperf\Utils\Collection;
use Hyperf\Utils\Exception\ParallelExecutionException;
use Hyperf\Utils\Coroutine;
use Hyperf\Utils\Parallel;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;
use Phper666\JWTAuth\JWT;
class TestController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        if (method_exists(parent::class, '__construct')) {
            parent::__construct(...func_get_args());
        }
        self::__handlePropertyHandler(__CLASS__);
    }
    public function index()
    {
        return $this->success([1, 2, 3], 'ok');
    }
    /** @Inject
     * @var Aes
     * @return string
     */
    private $aes;
    public function test()
    {
        $pwd1 = $this->aes->encrypt('abc');
        $pwd2 = $this->aes->decrypt($pwd1);
        return $pwd1 . '----' . $pwd2;
    }
    public function pwd()
    {
        $ok = 0;
        # Try to use stronger but system-specific hashes, with a possible fallback to
        # the weaker portable hashes.
        $t_hasher = new PasswordHash(8, FALSE);
        $correct = 'test12345';
        $hash = $t_hasher->hashPassword($correct);
        print 'Hash: ' . $hash . "\n";
        $check = $t_hasher->checkPassword($correct, $hash);
        if ($check) {
            $ok++;
        }
        print "Check correct: '" . $check . "' (should be '1')\n";
        $wrong = 'test12346';
        $check = $t_hasher->checkPassword($wrong, $hash);
        if (!$check) {
            $ok++;
        }
        print "Check wrong: '" . $check . "' (should be '0' or '')\n";
        unset($t_hasher);
        echo $ok;
    }
    public function page(RequestInterface $request)
    {
        //        $user = User::query()->paginate(10)->toArray();
        $user = User::query()->first(['user_id', 'username', 'nickname', 'email', 'sex', 'phone', 'avatar', 'created_at'])->toArray();
        $data['list'] = $user['data'];
        $data['total'] = $user['total'];
        return $this->success($user);
        var_dump($data);
        return $data;
        unset($user['current_page']);
        unset($user['from']);
        unset($user['last_page']);
        unset($user['last_page_url']);
        unset($user['next_page_url']);
        unset($user['path']);
        unset($user['per_page']);
        unset($user['prev_page_url']);
        unset($user['first_page_url']);
        unset($user['to']);
        return $this->success($user);
        return $user;
        $currentPage = (int) $request->input('page', 1);
        $perPage = (int) $request->input('per_page', 2);
        // 这里根据 $currentPage 和 $perPage 进行数据查询，以下使用 Collection 代替
        $collection = new Collection([['id' => 1, 'name' => 'Tom'], ['id' => 2, 'name' => 'Sam'], ['id' => 3, 'name' => 'Tim'], ['id' => 4, 'name' => 'Joe']]);
        $users = array_values($collection->forPage($currentPage, $perPage)->toArray());
        return new Paginator($users, $perPage, $currentPage);
    }
    public function role()
    {
        $role = Role::where("id", 1)->first();
        $ss = Permission::create(['name' => 'users.get', 'display_name' => '测试权限', 'url' => 'admin.users.get']);
        $permission = Permission::findById(1);
        //        return $permission;
        //创建一个角色
        $role = Role::create(['name' => '管理员', 'description' => '']);
        //创建权限
        //        $permission = Permission::create(['name' => 'user-center/user/get','display_name'=>'用户管理','url'=>'user-center/user']);
        //        $permission = Permission::create(['name' => 'user-center/user/post','display_name'=>'创建用户','parent_id'=>2]);
        //为角色分配一个权限
        $role->givePermissionTo($permission);
        //        $role->syncPermissions($permissions);//多个
        //        $role->syncPermissions([1]);
        //权限添加到一个角色
        //        $permission->assignRole($role);
        //        $permission->syncRoles($roles);//多个
        //        $permission->syncRoles([1]);
        //删除权限
        //        $role->revokePermissionTo($permission);
        //        $permission->removeRole($role);
        //为用户直接分配权限
        //        $user = new User();
        //         $user->save([
        //            'username' => 'admin',
        //            'password' => '123456',
        //            'nick_name' => '超级管理员',
        //            'real_name' => '超级管理员'
        //        ]);
        $user = User::query()->where('user_id', 1)->first();
        //        var_dump($user)
        //        return $user->givePermissionTo('user-center/user/get','user-center/user/post');
        ////为用户分配角色
        return $user->assignRole('管理员');
        //        return $user->assignRole(2);
        //        $user->assignRole($role);
        //        $user->syncRoles(['管理员', '普通用户']);
        //        $user->syncRoles([1,2,3]);
        ////删除角色
        //        $user->removeRole('产品');
        //        $user->removeRole(2);
        ////获取用户集合
        //        $permission->users;
        //        $role->users;
        ////获取角色集合
        //        return $user->getRoleNames();
        //        $permission->roles;
        ////获取所有权限
        ///
        $permission = Permission::getPermissions(['name' => 'user-center/user/post'])->first();
        // return $permission;
        return $user->getAllPermissions();
        //        $role->permissions;
        ////获取树形菜单
        //       return $user->getMenu();
        ////验证
        return $user->can('user-center/user/gets');
        //        $user->can($permission->id);
        //        $user->can($permission);
        //        $user->hasAnyPermission([$permission1,$permission2]);
        //     return   $user->hasAnyPermission(['user-center/user/get','user-center/user/post']);
        //        $user->hasAnyPermission([1,2]);
        //        $user->hasRole('管理员');
        //        $user->hasRole(['管理员','普通用户']);
        //        $user->hasRole($role);
        //        $user->hasRole([$role1,$role2]);
    }
    public function tests(int $id) : array
    {
        $validator = $this->validationFactory->make($this->request->all(), ['name' => 'required|unique:audio_class,name,' . $id, 'parent_id' => 'required|integer|min:0', 'weight' => 'integer'], ['name.unique' => '分类名称已存在']);
        $validated = $validator->validate();
        return $this->service->updateClass($id, $validated);
    }
}