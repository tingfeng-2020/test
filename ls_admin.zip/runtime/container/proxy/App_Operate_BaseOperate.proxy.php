<?php

namespace App\Operate;

use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Contract\RequestInterface;
/**
 * Class BaseOperate
 * @package App\Operate
 */
abstract class BaseOperate
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        self::__handlePropertyHandler(__CLASS__);
    }
    /**
     * @Inject
     * @var RequestInterface
     */
    protected $request;
    protected function check()
    {
    }
    public function done()
    {
        $this->check();
        return $this->doBusiness();
    }
    protected abstract function doBusiness();
}