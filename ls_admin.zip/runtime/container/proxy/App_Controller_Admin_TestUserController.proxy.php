<?php

declare (strict_types=1);
namespace App\Controller\Admin;

use App\Controller\AbstractController;
use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Contract\RequestInterface;
use Illuminate\Hashing\BcryptHasher;
use App\Exception;
use App\Model;
use App\Request;
class TestUserController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        if (method_exists(parent::class, '__construct')) {
            parent::__construct(...func_get_args());
        }
        self::__handlePropertyHandler(__CLASS__);
    }
    /**
     * @Inject
     * @var BcryptHasher
     */
    protected $hash;
    //get
    public function index(RequestInterface $request)
    {
    }
    //post create
    public function store(Request\UserRequest $request)
    {
    }
    // get
    public function show($id)
    {
    }
    // put
    public function update(Request\UserRequest $request, $id)
    {
    }
    // delete
    public function destroy($id)
    {
    }
    public function roles($id)
    {
    }
}