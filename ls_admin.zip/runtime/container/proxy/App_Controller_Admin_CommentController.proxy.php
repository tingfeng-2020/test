<?php

namespace App\Controller\Admin;

use App\Annotation\ResponseDataWrap;
use App\Constants\BusinessCode;
use App\Controller\AbstractController;
use App\Exception\BusinessException;
use App\Model\Comment;
/**
 * @ResponseDataWrap()
 */
class CommentController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        if (method_exists(parent::class, '__construct')) {
            parent::__construct(...func_get_args());
        }
        self::__handlePropertyHandler(__CLASS__);
    }
    public function selectCommentList()
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $content = $this->request->input('content');
            $comment_member = $this->request->input('comment_member');
            $audio_member = $this->request->input('audio_member');
            $page = $this->request->input('page');
            $page_size = $this->request->input('page_size');
            if (!is_numeric($page) || (int) $page != $page || $page <= 0) {
                $page = 1;
            }
            if (!is_numeric($page_size) || (int) $page_size != $page_size || $page_size <= 0) {
                $page_size = 20;
            }
            $params = ['page' => $page, 'page_size' => $page_size, 'content' => $content, 'comment_member' => $comment_member, 'audio_member' => $audio_member];
            $model = new Comment();
            return $model->selectCommentList($params);
        });
    }
    public function updCommentStatus()
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $comment_id = $this->request->input('comment_id');
            $status = $this->request->input('status');
            $topped = $this->request->input('topped');
            if (!is_numeric($comment_id) || (int) $comment_id != $comment_id || $comment_id <= 0) {
                throw new BusinessException(BusinessCode::SERVER_ERROR, '评论ID不正确，请重试。');
            }
            $params = ['comment_id' => $comment_id];
            $model = new Comment();
            if (array_key_exists($status, $model->commentStatusList)) {
                $params['status'] = $status;
            }
            if (array_key_exists($topped, $model->toppedStatusList)) {
                $params['topped'] = $topped;
            }
            return $model->updCommentStatus($params);
        });
    }
}