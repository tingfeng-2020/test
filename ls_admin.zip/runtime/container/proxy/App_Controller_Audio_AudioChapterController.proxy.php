<?php

declare (strict_types=1);
namespace App\Controller\Audio;

use App\Annotation\ResponseDataWrap;
use App\Controller\AbstractController;
use App\Service\Audio\AudioChapterService;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;
/**
 * @ResponseDataWrap()
 */
class AudioChapterController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    protected $service;
    protected $validatorFactory;
    public function __construct(AudioChapterService $service, ValidatorFactoryInterface $validatorFactory)
    {
        self::__handlePropertyHandler(__CLASS__);
        parent::__construct();
        $this->service = $service;
        $this->validatorFactory = $validatorFactory;
    }
    /**
     * 获取音频章节列表
     * @param int $audioId 音频ID
     * @return array
     */
    public function index(int $audioId) : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $audioId) {
            return $this->service->listChapter($audioId, !empty($validated['page']) ? (int) $validated['page'] : 1, !empty($validated['page_size']) ? (int) $validated['page_size'] : 10, !empty($validated['name']) ? trim($validated['name']) : '');
        });
    }
    /**
     * 章节详情
     * @param int $id 章节ID
     * @return array
     */
    public function show(int $id) : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $id) {
            return $this->service->getChapter($id);
        });
    }
    /**
     * 添加章节(批量)
     * @param int $audioId 音频ID
     * @return array
     */
    public function store(int $audioId) : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $audioId) {
            $validator = $this->validatorFactory->make($this->request->all(), ['list' => 'required|array', 'list.*.sequence' => 'required|integer|min:1', 'list.*.name' => 'required|string|max:20', 'list.*.path' => 'required|string', 'list.*.size' => 'required|integer|min:0', 'list.*.duration' => 'required|integer|min:0', 'list.*.need_pay' => 'required|integer|in:0,1', 'list.*.amount' => 'required|numeric|min:0']);
            $validated = $validator->validate();
            return $this->service->createChapters($audioId, $validated['list']);
        });
    }
    /**
     * 编辑章节
     * @param int $id 章节ID
     * @return array
     */
    public function update(int $id) : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $id) {
            $validator = $this->validatorFactory->make($this->request->all(), ['sequence' => 'required|integer|min:1', 'name' => 'required|string|max:20', 'path' => 'required|string', 'size' => 'required|integer|min:0', 'duration' => 'required|integer|min:0', 'need_pay' => 'required|integer|in:0,1', 'amount' => 'required|numeric|min:0']);
            $validated = $validator->validate();
            return $this->service->updateChapter($id, $validated);
        });
    }
    /**
     * 获取最后一章
     * @param int $audioId 音频ID
     * @return array|null
     */
    public function last(int $audioId) : ?array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $audioId) {
            return $this->service->lastChapter($audioId);
        });
    }
    /**
     * 章节批量付费设置
     * @param int $audioId 音频ID
     * @return array|null
     */
    public function updateAmount(int $audioId) : ?array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $audioId) {
            $validator = $this->validatorFactory->make($this->request->all(), ['start' => 'required|integer|min:1', 'amount' => 'required|numeric|min:0']);
            $validated = $validator->validate();
            return $this->service->updateAmount($audioId, (int) $validated['start'], $validated['amount']);
        });
    }
}