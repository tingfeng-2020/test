<?php

declare (strict_types=1);
namespace App\Controller\Audio;

use App\Annotation\ResponseDataWrap;
use App\Controller\AbstractController;
use App\Service\Audio\AudioClassService;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;
/**
 * @ResponseDataWrap()
 */
class AudioClassController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    protected $service;
    protected $validatorFactory;
    public function __construct(AudioClassService $service, ValidatorFactoryInterface $validatorFactory)
    {
        self::__handlePropertyHandler(__CLASS__);
        parent::__construct();
        $this->service = $service;
        $this->validatorFactory = $validatorFactory;
    }
    /**
     * 音频分类列表
     * @return array
     */
    public function index() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $validator = $this->validatorFactory->make($this->request->all(), ['page' => 'integer|min:1', 'page_size' => 'integer|between:1,100', 'name' => 'string']);
            $validated = $validator->validate();
            return $this->service->listClass(!empty($validated['page']) ? (int) $validated['page'] : 1, !empty($validated['page_size']) ? (int) $validated['page_size'] : 10, !empty($validated['name']) ? trim($validated['name']) : '');
        });
    }
    /**
     * 音频分类详情
     * @param int $id 音频分类ID
     * @return array
     */
    public function show(int $id) : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $id) {
            return $this->service->getClass($id);
        });
    }
    /**
     * 添加音频分类
     * @return array
     */
    public function store() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $validator = $this->validatorFactory->make($this->request->all(), ['name' => 'required|string|max:4|unique:audio_class,name', 'parent_id' => 'required|integer|min:0', 'weight' => 'integer'], ['name.unique' => '该分类已存在']);
            $validated = $validator->validate();
            return $this->service->createClass($validated);
        });
    }
    /**
     * 编辑音频分类
     * @param int $id 音频分类ID
     * @return array
     */
    public function update(int $id) : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $id) {
            $validator = $this->validatorFactory->make($this->request->all(), ['name' => 'required|unique:audio_class,name,' . $id, 'parent_id' => 'required|integer|min:0', 'weight' => 'integer'], ['name.unique' => '分类名称已存在']);
            $validated = $validator->validate();
            return $this->service->updateClass($id, $validated);
        });
    }
    /**
     * 删除音频分类
     * @param int $id 音频分类ID
     * @return array
     */
    public function destroy(int $id) : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (int $id) {
            return $this->service->deleteClass($id);
        });
    }
    /**
     * 获取所有顶级音频分类(不分页)
     * @return array
     */
    public function top() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            return $this->service->topClass();
        });
    }
    /**
     * 获取所有音频分类(树形结构,不分页)
     * @return array
     */
    public function tree() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            return $this->service->treeClass();
        });
    }
}