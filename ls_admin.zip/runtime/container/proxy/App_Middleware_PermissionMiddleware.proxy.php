<?php

declare (strict_types=1);
namespace App\Middleware;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use Hyperf\Di\Annotation\Inject;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Hyperf\Contract\ConfigInterface;
use Hyperf\HttpServer\Router\Dispatched;
/**
 * Class PermissionMiddleware
 * @package App\Middleware
 */
class PermissionMiddleware implements MiddlewareInterface
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        self::__handlePropertyHandler(__CLASS__);
    }
    /**
     * 路由权限认证
     * @Inject
     * @var ConfigInterface
     */
    protected $config;
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler) : ResponseInterface
    {
        //去掉路由参数
        $route = $request->getAttribute(Dispatched::class)->handler->route;
        $path = $route . '/' . $request->getMethod();
        $user = $request->getAttribute('user');
        //是否超级管理员
        if (isset($user->getRoleNames()[0]) && $user->getRoleNames()[0] === $this->config->get('permission.super_user')) {
            return $handler->handle($request);
        }
        //拼接路由参数
        $name = strtolower($path);
        //        echo $name.'------';
        //是否有权限
        if ($user && $user->can($name)) {
            return $handler->handle($request);
        }
        throw new BusinessException(BusinessCode::UNAUTHORIZED, '无权进行该操作/请联系管理人员');
    }
}