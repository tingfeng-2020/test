<?php

namespace App\Operate\Common;

use App\Exception\ApiException;
use App\Model\User;
use App\Operate\BaseOperate;
use App\Tools\Aes;
use App\Tools\PasswordHash;
use Hyperf\Di\Annotation\Inject;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;
use Hyperf\Validation\Rule;
use Phper666\JWTAuth\JWT;
/**
 * 管理员登陆
 * Class LoginOperate
 * @package App\Operate\Common
 */
class LoginOperate extends BaseOperate
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        if (method_exists(parent::class, '__construct')) {
            parent::__construct(...func_get_args());
        }
        self::__handlePropertyHandler(__CLASS__);
    }
    /**
     * @Inject()
     * @var ValidatorFactoryInterface
     */
    protected $validationFactory;
    /**
     * 解密注解
     * @Inject
     * @var Aes
     * @return string
     */
    protected $aes;
    /**
     * Token注解
     * @Inject()
     * @var JWT
     */
    protected $jwt;
    protected $password;
    protected $email;
    protected $user;
    protected function check()
    {
        $validator = $this->validationFactory->make($this->request->all(), ['email' => ['required', 'email', Rule::exists(config('permission.table_names.user'))->where(function ($query) {
            $query->where('status', User::$status_en['enable']);
        })], 'password' => ['required']], ['email.required' => ':attribute 是必须的～', 'email.exists' => ':attribute 用户不存在或用户被锁定,请联系管理员~', 'email.email' => ':attribute 请输入正确的邮箱地址~', 'password.required' => ':attribute 是必须的～']);
        if ($validator->fails()) {
            $errorMessage = $validator->errors()->first();
            throw new ApiException(1000, $errorMessage);
        }
        //解密password
        $this->password = $this->aes->decrypt($this->request->input('password'));
        $this->email = $this->request->input('email');
        //拿盐
        $user = User::query()->where('email', $this->email)->first()->toArray();
        //密码转义
        $passHash = make(PasswordHash::class, [8, false]);
        if (!$passHash->checkPassword($user['salt'] . $this->password, $user['password'])) {
            throw new ApiException(1000, '密码不正确');
        }
    }
    protected function doBusiness()
    {
        $data = [];
        if ($this->password && $this->email) {
            $userData = ['uid' => $this->user['user_id'], 'username' => $this->user['username'], 'nickname' => $this->user['nickname'], 'email' => $this->user['email']];
            // 使用默认场景登录
            $token = $this->jwt->setScene('default')->getToken($userData);
            $data = ['token' => $token, 'exp' => $this->jwt->getTTL()];
        }
        return $data;
    }
}