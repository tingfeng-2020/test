<?php

namespace App\Controller\Admin;

use App\Annotation\ResponseDataWrap;
use App\Constants\BusinessCode;
use App\Controller\AbstractController;
use App\Exception\BusinessException;
use App\Model\Page;
/**
 * @ResponseDataWrap()
 */
class PageController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        if (method_exists(parent::class, '__construct')) {
            parent::__construct(...func_get_args());
        }
        self::__handlePropertyHandler(__CLASS__);
    }
    public function selectPageList()
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $name = $this->request->input('name');
            $page = $this->request->input('page');
            $page_size = $this->request->input('page_size');
            if (!is_numeric($page) || (int) $page != $page || $page <= 0) {
                $page = 1;
            }
            if (!is_numeric($page_size) || (int) $page_size != $page_size || $page_size <= 0) {
                $page_size = 20;
            }
            $params = ['page' => $page, 'page_size' => $page_size, 'name' => $name];
            $model = new Page();
            return $model->selectPageList($params);
        });
    }
    public function selectPageDetail()
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $page_id = $this->request->input('page_id');
            if (!is_numeric($page_id) || (int) $page_id != $page_id || $page_id <= 0) {
                throw new BusinessException(BusinessCode::SERVER_ERROR, '页面ID不正确，请重试。');
            }
            $params = ['page_id' => $page_id];
            $model = new Page();
            return $model->selectPageDetail($params);
        });
    }
    public function updPage()
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $page_id = $this->request->input('page_id');
            $banner_list = $this->request->input('banner_list');
            $block_list = $this->request->input('block_list');
            if (!is_numeric($page_id) || (int) $page_id != $page_id || $page_id <= 0) {
                throw new BusinessException(BusinessCode::SERVER_ERROR, '页面ID不正确，请重试。');
            }
            if (!is_array($banner_list) || count($banner_list) <= 0) {
                throw new BusinessException(BusinessCode::SERVER_ERROR, 'banner列表不正确，请重试。');
            }
            if (!is_array($block_list) || count($block_list) <= 0) {
                throw new BusinessException(BusinessCode::SERVER_ERROR, '版块列表不正确，请重试。');
            }
            foreach ($banner_list as $banner) {
                if (empty($banner['img']) || empty($banner['jump']) || !isset($banner['seq']) || !is_numeric($banner['seq']) || (int) $banner['seq'] != $banner['seq']) {
                    throw new BusinessException(BusinessCode::SERVER_ERROR, 'banner信息不正确，请重试。');
                }
            }
            foreach ($block_list as $block) {
                if (empty($block['name']) || !isset($block['type']) || !is_numeric($block['type']) || (int) $block['type'] != $block['type'] || $block['type'] <= 0 || !isset($block['topic_id']) || !is_numeric($block['topic_id']) || (int) $block['topic_id'] != $block['topic_id'] || $block['topic_id'] <= 0 || !isset($block['seq']) || !is_numeric($block['seq']) || (int) $block['seq'] != $block['seq']) {
                    throw new BusinessException(BusinessCode::SERVER_ERROR, '版块信息不正确，请重试。');
                }
            }
            $params = ['page_id' => $page_id, 'banner_list' => $banner_list, 'block_list' => $block_list];
            $model = new Page();
            return $model->updPage($params);
        });
    }
    public function pubPage()
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $page_id = $this->request->input('page_id');
            if (!is_numeric($page_id) || (int) $page_id != $page_id || $page_id <= 0) {
                throw new BusinessException(BusinessCode::SERVER_ERROR, '页面ID不正确，请重试。');
            }
            $params = ['page_id' => $page_id];
            $model = new Page();
            return $model->pubPage($params);
        });
    }
}