<?php

declare (strict_types=1);
namespace App\Controller\Admin\Permission;

use App\Annotation\ResponseDataWrap;
use App\Controller\AbstractController;
use App\Model\Permission\Permission;
/**
 * 权限相关
 * Class PermissionController
 * @package App\Controller\Admin\Permission
 * @ResponseDataWrap()
 */
class PermissionController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        if (method_exists(parent::class, '__construct')) {
            parent::__construct(...func_get_args());
        }
        self::__handlePropertyHandler(__CLASS__);
    }
    /**
     * 获取菜单
     * @return array
     */
    public function getMenu() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            return Permission::getMenuList();
        });
    }
    /**
     * 获取权限配置
     * @return array
     */
    public function getList() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
        });
    }
}