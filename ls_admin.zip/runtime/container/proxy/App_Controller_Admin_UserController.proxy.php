<?php

declare (strict_types=1);
namespace App\Controller\Admin;

use App\Annotation\PermissionCheck;
use App\Annotation\ResponseDataWrap;
use App\Constants\BusinessCode;
use App\Controller\AbstractController;
use App\Operate\Common\LoginOperate;
use http\Env\Request;
use Hyperf\Di\Annotation\AnnotationCollector;
use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Contract\RequestInterface;
use Phper666\JWTAuth\JWT;
/**
 * * Class UserController
 * @package App\Controller\Admin
 * @ResponseDataWrap()
 */
class UserController extends AbstractController
{
    use \Hyperf\Di\Aop\ProxyTrait;
    use \Hyperf\Di\Aop\PropertyHandlerTrait;
    function __construct()
    {
        if (method_exists(parent::class, '__construct')) {
            parent::__construct(...func_get_args());
        }
        self::__handlePropertyHandler(__CLASS__);
    }
    /**
     *
     * @Inject()
     * @var JWT
     */
    protected $jwt;
    /**
     * 登陆接口
     * @param JWT $jwt
     */
    public function login() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            var_dump($this->request->all());
            $operate = new LoginOperate($this->request);
            $res = $operate->done();
            return $res;
        });
    }
    /**
     * 注册接口
     */
    public function createStore() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            //验证账号密码合法性，
            //创建用户，并且生成随机salt，生成密码
            $username = $this->request->input('username');
            $password = $this->request->input('password');
            return [];
        });
    }
    /**
     * 刷新token
     */
    public function refreshToken() : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $token = $this->jwt->refreshToken();
            $data = ['code' => 0, 'msg' => 'success', 'data' => ['token' => (string) $token, 'exp' => $this->jwt->getTTL()]];
            return $data;
        });
    }
    /**
     * 退出
     */
    public function logout() : bool
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            $this->jwt->logout();
            return true;
        });
    }
    /**
     * 获取token数据
     * 只能使用default场景值生成的token访问
     */
    public function getDefaultData(RequestInterface $request) : array
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function (RequestInterface $request) {
            $data = ['code' => BusinessCode::SUCCESSFUL, 'msg' => 'success', 'data' => $this->jwt->getParserData()];
            return $data;
        });
    }
    public function getAa()
    {
        return self::__proxyCall(__CLASS__, __FUNCTION__, self::__getParamsMap(__CLASS__, __FUNCTION__, func_get_args()), function () {
            return AnnotationCollector::getMethodByAnnotation(PermissionCheck::class);
        });
    }
}