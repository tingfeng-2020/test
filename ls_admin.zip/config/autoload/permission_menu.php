<?php

/**
 * eg: 运行此命令增加菜单 php bin/hyperf.php permission:update
 * TODO: 三级菜单例子
 * 备注：默认会给url和name参数添加前缀 => /admin
 * name => 路由标识,display_name=>模块名称,url=>路由,parent_id=>父级id,is_show=>是否显示菜单栏,'child'=>子集
 *
 */

return [
    ['name' => '/login_about', 'display_name' => '登陆相关', 'url' => '', 'parent_id' => '', 'is_menu' => false, 'child' =>
        [
            ['name' => '/refresh_token/get', 'display_name' => '刷新token', 'url' => '/refresh_token', 'parent_id' => '/login_about', 'is_menu' => false],
            ['name' => '/logout/delete', 'display_name' => '登出', 'url' => '/logout', 'parent_id' => '/login_about', 'is_menu' => false],
            ['name' => '/info/get', 'display_name' => '用户详情', 'url' => '/info', 'parent_id' => '/login_about', 'is_menu' => false],
        ]
    ],
    ['name' => '/system_manage', 'display_name' => '系统管理', 'url' => '', 'parent_id' => '', 'is_menu' => true, 'child' =>
        [
            [
                    'name' => '/permission/list/get', 'display_name' => '权限配置', 'url' => '/permission/list', 'parent_id' => '/system_manage', 'is_menu' => true , 'child' =>
                [
                    ['name' => '/permission/post', 'display_name' => '添加角色', 'url' => '/permission', 'parent_id' => '/permission/list/get', 'is_menu' => false],
                    ['name' => '/permission/{id:\d+}/put', 'display_name' => '编辑角色', 'url' => '/permission/{id:\d+}', 'parent_id' => '/permission/list/get', 'is_menu' => false],
                    ['name' => '/permission/{id:\d+}/get', 'display_name' => '角色详情', 'url' => '/permission/{id:\d+}', 'parent_id' => '/permission/list/get', 'is_menu' => false],
                ]
            ],
        ]
    ]
];
