<?php

/**
 * eg: 运行此命令增加菜单 php bin/hyperf.php permission:update
 * TODO: 三级菜单例子
 * name => 路由标识,display_name=>模块名称,url=>路由,parent_id=>父级id,is_show=>是否显示菜单栏,'child'=>子集
 *
 */

return [
    ['name' => '/users', 'display_name' => '用户管理', 'url' => '', 'parent_id' => '', 'is_show' => true, 'child' =>
        [
            ['name' => '/users/get', 'display_name' => '添加用户', 'url' => '/user', 'parent_id' => '/users', 'is_show' => false],
            ['name' => '/users/post', 'display_name' => '用户更新', 'url' => '/user', 'parent_id' => '/users', 'is_show' => false],
        ]
    ],
];
