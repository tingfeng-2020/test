<?php

declare(strict_types=1);
/**
 * 路由权限表 permissions => name字段关联路由验证：验证规则（url+请求方法 Method）url 字段：路由访问url
 * 赋予权限：1.通过默认的权限接口方法增删权限，2.通过脚本自动添加...dev
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://doc.hyperf.io
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */
use Hyperf\HttpServer\Router\Router;

$middleware = [
    App\Middleware\JwtAuthMiddleware::class,
    App\Middleware\PermissionMiddleware::class,
];


# 登录
Router::post('/admin/login', 'App\Controller\Admin\UserController@login');

# 登陆加权限认证
Router::addGroup('/admin', function () {
    #登陆相关接口
    Router::get('/register', 'App\Controller\Admin\UserController@createStore');
    Router::get('/refresh-token', 'App\Controller\Admin\UserController@refreshToken');
    Router::delete('/logout', 'App\Controller\Admin\UserController@logout');
    Router::get('/data', 'App\Controller\Admin\UserController@getData');
    Router::post('/list', 'App\Controller\Admin\UserController@getDefaultData');
}, ['middleware' => $middleware]);


//Router::get('/aes',function (){
//
////    define('KEY', '504ad202615d4c42232e308e53040ad6');
//    $iv= '504ad202615d4c42';
////echo strlen($iv).PHP_EOL;
//    $str="12345678";
//# 加密 md5->true 为16位md5
//    $strEncode= base64_encode(openssl_encrypt($str, 'AES-256-CBC','504ad202615d4c42232e308e53040ad6', OPENSSL_RAW_DATA , $iv));   # AES-256-CBC
//    return $strEncode.PHP_EOL;
////   $aes = \App\Tools\Aes::encrypt('abc');
////   $des = \App\Tools\Aes::decrypt($aes);
////   return $aes.'----'.$des;
//});

Router::get('/aes','App\Controller\IndexController@test');
Router::get('/pwd','App\Controller\IndexController@pwd');



