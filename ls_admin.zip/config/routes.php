<?php

declare(strict_types=1);

/**
 * 路由权限表 permissions => name字段关联路由验证：验证规则（url+请求方法 Method）url 字段：路由访问url
 * 赋予权限：1.通过默认的权限接口方法增删权限，2.通过脚本自动添加...dev
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://doc.hyperf.io
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */

use Hyperf\HttpServer\Router\Router;

$middleware = [
    App\Middleware\JwtAuthMiddleware::class,
//    App\Middleware\PermissionMiddleware::class,
];


# 登录
Router::post('/admin/login', 'App\Controller\Admin\UserController@login');

# 登陆相关功能
Router::addGroup('/admin', static function () {
    #登陆相关接口
    Router::get('/register/{id:\d+}', 'App\Controller\Admin\UserController@createStore');
    Router::get('/refresh_token', 'App\Controller\Admin\UserController@refreshToken');
    Router::delete('/logout', 'App\Controller\Admin\UserController@logout');
    Router::get('/info', 'App\Controller\Admin\UserController@getDefaultData');
    Router::get('/getAa', 'App\Controller\Admin\UserController@getAa');

    #系统管理-权限配置
    Router::get('/permission/menu', 'App\Controller\Admin\Permission\PermissionController@getMenu');
//    Router::get('/info', 'App\Controller\Admin\UserController@getDefaultData');


}, ['middleware' => $middleware]);




Router::get('/aes', 'App\Controller\IndexController@test');
Router::get('/pwd', 'App\Controller\IndexController@pwd');
//Router::get('/tests/{id}', 'App\Controller\IndexController@tests');

Router::addGroup('/admin/member/', static function () {
    // 用户管理-主播管理
    Router::get('anchors', 'App\Controller\Member\AnchorController@index');
    Router::get('anchors/{id:\d+}', 'App\Controller\Member\AnchorController@show');
    Router::post('anchors', 'App\Controller\Member\AnchorController@store');
    Router::put('anchors/{id:\d+}', 'App\Controller\Member\AnchorController@update');

    // 用户管理-用户管理
    Router::get('members', 'App\Controller\Member\MemberController@index');
    Router::get('members/{id:\d+}', 'App\Controller\Member\MemberController@show');
    Router::put('members/{id:\d+}/switch-mute', 'App\Controller\Member\MemberController@switchMute');
});

Router::addGroup('/admin/audio/', static function () {
    // 内容管理-音频分类管理
    Router::get('classifications', 'App\Controller\Audio\AudioClassController@index');
    Router::get('classifications/{id:\d+}', 'App\Controller\Audio\AudioClassController@show');
    Router::post('classifications', 'App\Controller\Audio\AudioClassController@store');
    Router::put('classifications/{id:\d+}', 'App\Controller\Audio\AudioClassController@update');
    Router::delete('classifications/{id:\d+}', 'App\Controller\Audio\AudioClassController@destroy');
    Router::post('classifications/bulk-delete', 'App\Controller\Audio\AudioClassController@bulkDelete');
    Router::get('classifications/top', 'App\Controller\Audio\AudioClassController@top');
    Router::get('classifications/tree', 'App\Controller\Audio\AudioClassController@tree');

    // 内容管理-音频管理
    Router::get('audios', 'App\Controller\Audio\AudioController@index');
    Router::get('audios/{id:\d+}', 'App\Controller\Audio\AudioController@show');
    Router::post('audios', 'App\Controller\Audio\AudioController@store');
    Router::put('audios/{id:\d+}', 'App\Controller\Audio\AudioController@update');
    Router::put('audios/{id:\d+}/switch-status', 'App\Controller\Audio\AudioController@switchStatus');

    // 内容管理-音频章节管理
    Router::get('audios/{audioId:\d+}/chapters', 'App\Controller\Audio\AudioChapterController@index');
    Router::get('audios/{audioId:\d+}/chapters/last', 'App\Controller\Audio\AudioChapterController@last');
    Router::get('audios/{audioId:\d+}/chapters/{id:\d+}', 'App\Controller\Audio\AudioChapterController@show');
    Router::post('audios/{audioId:\d+}/chapters', 'App\Controller\Audio\AudioChapterController@store');
    Router::put('audios/{audioId:\d+}/chapters/amount', 'App\Controller\Audio\AudioChapterController@updateAmount');
});

Router::addGroup('/admin/upload/', static function () {
    // 公共上传文件接口
    Router::post('files', 'App\Controller\Upload\FileUploadController@index');

    // 上传音频(音频管理使用)
    Router::post('audios', 'App\Controller\Upload\FileUploadController@uploadAudio');
});
