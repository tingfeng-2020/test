<?php
define('SECRETKEY', '504ad202615d4c42232e308e53040ad6');

/**
* 加密方法
* @param string $str
* @return string
*/
function encrypt($str) {
//AES, 128 ECB模式加密数据
$str = addPKCS7Padding($str);
$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC), MCRYPT_RAND);
$encrypt_str = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, SECRETKEY, $str, MCRYPT_MODE_CBC, '504ad202615d4c42');
return base64_encode($encrypt_str);
}

/**
* 解密方法
* @param string $str
* @return string
*/
function decrypt($str) {
//AES, 128 CBC模式加密数据
$str = base64_decode($str);
$iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC), MCRYPT_RAND);
$encrypt_str = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, SECRETKEY, $str, MCRYPT_MODE_CBC, '504ad202615d4c42');
$encrypt_str = stripPKSC7Padding($encrypt_str);
return $encrypt_str;
}

/**
* 填充算法
* @param string $source
* @return string
*/
function addPKCS7Padding($source) {
$source = trim($source);
$block = mcrypt_get_block_size('rijndael-128', 'cbc');
$pad = $block - (strlen($source) % $block);
if ($pad <= $block) {
$char = chr($pad);
$source .= str_repeat($char, $pad);
}
return $source;
}

/**
* 移去填充算法
* @param string $source
* @return string
*/
function stripPKSC7Padding($source) {
$char = substr($source, -1);
$num = ord($char);
$source = substr($source, 0, -$num);
return $source;
}




/**
*  加密
*/
$string =encrypt('abc');
print_r($string);
echo '<hr>';
/**
*  解密
*/
$string=decrypt($string);
print_r($string);