<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://doc.hyperf.io
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */
namespace App\Traits;

use App\Constants\ErrorCode;
use Hyperf\HttpServer\Contract\ResponseInterface;

/**
 * 统一返回封装
 * Class ResponseTrait
 * @package App\Traits
 */
trait ResponseTrait
{
    /**
     * @var ResponseInterface
     */
    protected $response;

    public function success($data = [], $message = '', $code = 0)
    {
        if (is_null($message)) {
            $message = ErrorCode::getMessage($code);
        }
        return $this->response->json([
            'code' => 0,
            'message' => $message,
            'data' => $data
        ]);
    }

    public function fail($code, $message = '')
    {
        if (is_null($message)) {
            $message = ErrorCode::getMessage($code);
        }
        return $this->response->json([
            'code' => $code,
            'message' => $message,
            'data' => []
        ]);
    }
}