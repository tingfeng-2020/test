<?php

declare(strict_types=1);

namespace App\Listener\Audio;

use App\Event\Audio\AudioClassCreated;
use App\Event\Audio\AudioClassDeleted;
use App\Event\Audio\AudioClassUpdated;
use App\Model\Topic;
use Hyperf\Event\Annotation\Listener;
use Hyperf\Event\Contract\ListenerInterface;

/**
 * @Listener
 */
class AudioClassOperationListener implements ListenerInterface
{
    public function listen(): array
    {
        return [
            AudioClassCreated::class,
            AudioClassUpdated::class,
            AudioClassDeleted::class,
        ];
    }

    public function process(object $event): void
    {
        if ($event instanceof AudioClassCreated) {
            $this->audioClassCreated($event);
            return;
        }

        if ($event instanceof AudioClassUpdated) {
            $this->audioClassUpdated($event);
            return;
        }

        if ($event instanceof AudioClassDeleted) {
            $this->audioClassDeleted($event);
            return;
        }
    }

    protected function audioClassCreated(AudioClassCreated $event): void
    {
        Topic::query()->firstOrCreate([
            'name' => $event->audioClass->name,
            'type' => Topic::TOPIC_TYPE_AUDIO,
        ]);
    }

    protected function audioClassUpdated(AudioClassUpdated $event): void
    {
        $oldName = $event->oldAudioClass->name;
        $newName = $event->newAudioClass->name;
        if ($oldName !== $newName) {
            Topic::query()->where('name', $oldName)->update(['name' => $newName]);
        }
    }

    protected function audioClassDeleted(AudioClassDeleted $event): void
    {
        Topic::query()->where('name', $event->audioClass->name)->delete();
        // TODO 还需要删除中间表数据
    }
}
