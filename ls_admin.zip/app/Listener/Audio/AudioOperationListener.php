<?php

declare(strict_types=1);

namespace App\Listener\Audio;

use App\Event\Audio\AudioCreated;
use App\Event\Audio\AudioStatusChanged;
use App\Model\Audio\AudioClass;
use App\Model\Topic;
use Hyperf\DbConnection\Db;
use Hyperf\Event\Annotation\Listener;
use Hyperf\Event\Contract\ListenerInterface;

/**
 * @Listener
 */
class AudioOperationListener implements ListenerInterface
{
    public function listen(): array
    {
        return [
            AudioCreated::class,
            AudioStatusChanged::class,
        ];
    }

    public function process(object $event): void
    {
        if ($event instanceof AudioCreated) {
            $this->audioCreated($event);
            return;
        }

        if ($event instanceof AudioStatusChanged) {
            $this->audioStatusChanged($event);
            return;
        }
    }

    protected function audioCreated(AudioCreated $event): void
    {
        $audioClassArr = AudioClass::query()->whereIn('id', $event->classIds)->get(['name'])->toArray();
        $audioClassNames = array_column($audioClassArr, 'name');

        $topicArr = Topic::query()->whereIn('name', $audioClassNames)->get(['id'])->toArray();
        $topicIds = array_column($topicArr, 'id');

        $values = [];
        foreach ($topicIds as $topicId) {
            $values[] = ['topic_id' => $topicId, 'audio_id' => $event->audio->id];
        }

        // TODO 改用中间表模型
        Db::table('topic_audio')->insertOrIgnore($values);
    }

    protected function audioStatusChanged(AudioStatusChanged $event): void
    {
        // TODO 音频上下架事件
    }

}
