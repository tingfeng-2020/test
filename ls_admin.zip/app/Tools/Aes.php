<?php


namespace App\Tools;

/**
 * 加密解密aes
 * @!!需要环境支持openssl扩展
 * 替代php7.1以下版本函数:openssl_encrypt => mcrypt_encrypt
 * Class Aes
 * @package App\Tools
 */
class Aes
{
    /**
     * 加密方法
     * @var string
     */
    private $method;

    /**
     * 加密钥匙
     * @var string
     */
    private $key;

    /**
     * 偏移量
     * @var string
     */
    private $iv;

    public function __construct()
    {
        $this->key = '504ad202615d4c42232e308e53040ad6';
        $this->method = 'AES-256-CBC';
        $this->iv = '504ad202615d4c42';
    }


    /**
     * 加密
     * @param string $string 需要加密的字符串
     * @return string
     */
    public function encrypt($string)
    {
        return  base64_encode(openssl_encrypt($string, $this->method, $this->key, OPENSSL_RAW_DATA, $this->iv));
    }


    /**
     * 解密
     * @param string $string 需要解密的字符串
     * @return string
     */
    public function decrypt($string)
    {
        return  openssl_decrypt(base64_decode($string), $this->method, $this->key, OPENSSL_RAW_DATA, $this->iv);
    }
}

