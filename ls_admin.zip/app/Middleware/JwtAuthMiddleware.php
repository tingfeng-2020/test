<?php
declare(strict_types = 1);

namespace App\Middleware;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use App\Model\User;
use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Contract\RequestInterface;
use Hyperf\HttpServer\Contract\ResponseInterface as HttpResponse;
use Hyperf\Utils\Context;
use Phper666\JWTAuth\JWT;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

class JwtAuthMiddleware implements MiddlewareInterface
{

    /**
     * @Inject
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var HttpResponse
     */
    protected $response;

    /**
     * 登陆token验证
     * @Inject
     * @var JWT
     */
    protected $jwt;


    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        try {
            if ($this->jwt->checkToken()) {
                $userData = $this->jwt->getParserData();
                $userId = $userData['uid'];
                $user = User::where('user_id', $userId)->where('status', User::STATUS_ENABLE)->first();
                if (!$user) {
                    throw new BusinessException(BusinessCode::ACCOUNT_UNUSUAL,'账号异常,禁止登陆!');
                }
                $request = $request->withAttribute('user', $user);
                Context::set(ServerRequestInterface::class, $request);
            }
        } catch (\Exception $e) {
            throw new BusinessException(BusinessCode::TOKEN_FAIL,'Token未验证通过');
        }
        return $handler->handle($request);
    }

}