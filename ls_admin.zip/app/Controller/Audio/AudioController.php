<?php

declare(strict_types=1);

namespace App\Controller\Audio;

use App\Annotation\ResponseDataWrap;
use App\Controller\AbstractController;
use App\Service\Audio\AudioService;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;

/**
 * @ResponseDataWrap()
 */
class AudioController extends AbstractController
{
    protected $service;
    protected $validatorFactory;

    public function __construct(AudioService $service, ValidatorFactoryInterface $validatorFactory)
    {
        parent::__construct();
        $this->service = $service;
        $this->validatorFactory = $validatorFactory;
    }

    /**
     * 音频列表
     * @return array
     */
    public function index(): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'page' => 'integer|min:1',
            'page_size' => 'integer|between:1,100',
            'name' => 'string',
            'anchor_name' => 'string',
            'status' => 'integer|in:0,1',
            'progress' => 'integer|in:1,2,3',
        ]);

        $validated = $validator->validate();
        return $this->service->listAudio(
            !empty($validated['page']) ? (int)$validated['page'] : 1,
            !empty($validated['page']) ? (int)$validated['page_size'] : 10,
            !empty($validated['name']) ? trim($validated['name']) : '',
            !empty($validated['anchor_name']) ? trim($validated['anchor_name']) : '',
            !empty($validated['status']) ? (int)$validated['status'] : null,
            !empty($validated['progress']) ? (int)$validated['progress'] : null
        );
    }

    /**
     * 音频详情
     * @param int $id 音频ID
     * @return array
     */
    public function show(int $id): array
    {
        return $this->service->getAudio($id);
    }

    /**
     * 添加音频
     * @return array
     */
    public function store(): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'type' => 'required|integer|in:1',
            'original_name' => 'required|string|max:12',
            'author' => 'required|string|max:5',
            'intro' => 'required|string|max:300',
            'name' => 'required|string|max:12',
            'anchor_id' => 'required|integer',
            'cover' => 'required',
            'label' => 'required|string|max:4',
            'classifications' => 'required|array',
            'classifications.*' => 'integer',
            'tags' => 'required|array',
            'tags.*' => 'string|max:10',
            'quality' => 'required|integer|in:1,2',
            'progress' => 'required|integer|in:1,2,3',
        ]);

        $validated = $validator->validate();
        return $this->service->createAudio($validated);
    }

    /**
     * 编辑音频
     * @param int $id 音频ID
     * @return array
     */
    public function update(int $id): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'type' => 'required|integer|in:1',
            'original_name' => 'required|string|max:12',
            'author' => 'required|string|max:5',
            'intro' => 'required|string|max:300',
            'name' => 'required|string|max:12',
            'anchor_id' => 'required|integer',
            'cover' => 'required',
            'label' => 'required|string|max:4',
            'classifications' => 'required|array',
            'classifications.*' => 'integer',
            'tags' => 'required|array',
            'tags.*' => 'string|max:10',
            'quality' => 'required|integer|in:1,2',
            'progress' => 'required|integer|in:1,2,3',
        ]);

        $validated = $validator->validate();
        return $this->service->updateAudio($id, $validated);
    }

    /**
     * 音频上下架
     * @param int $id 音频ID
     * @return array
     */
    public function switchStatus(int $id): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'status' => 'required|integer|in:0,1',
        ]);

        $validated = $validator->validate();
        return $this->service->switchStatus($id, (int)$validated['status']);
    }

    /**
     * 搜索音频
     * @return array
     */
    public function search(): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'name' => 'required',
        ]);

        $validated = $validator->validate();
        return $this->service->searchAudio($validated['name']);
    }
}
