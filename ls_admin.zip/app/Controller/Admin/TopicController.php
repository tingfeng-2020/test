<?php

namespace App\Controller\Admin;

use App\Annotation\ResponseDataWrap;
use App\Constants\BusinessCode;
use App\Controller\AbstractController;
use App\Exception\BusinessException;
use App\Model\Topic;
use Illuminate\Support\Facades\Bus;

/**
 * @ResponseDataWrap()
 */
class TopicController extends AbstractController
{
    public function selectTopicList(){
        $name = $this->request->input('name');
        $page = $this->request->input('page');
        $page_size = $this->request->input('page_size');
        if((!is_numeric($page)) || ((int)$page != $page) || ($page <= 0)){
            $page = 1;
        }
        if((!is_numeric($page_size)) || ((int)$page_size != $page_size) || ($page_size <= 0)){
            $page_size = 20;
        }

        $params = ['page' => $page, 'page_size' => $page_size, 'name' => $name];
        $model = new Topic();
        return $model->selectTopicList($params);
    }

    public function selectTopicDetail(){
        $topic_id = $this->request->input('topic_id');
        $page = $this->request->input('page');
        $page_size = $this->request->input('page_size');
        if((!is_numeric($topic_id)) || ((int)$topic_id != $topic_id) || ($topic_id <= 0)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '专题ID不正确，请重试。');
        }
        if((!is_numeric($page)) || ((int)$page != $page) || ($page <= 0)){
            $page = 1;
        }
        if((!is_numeric($page_size)) || ((int)$page_size != $page_size) || ($page_size <= 0)) {
            $page_size = 20;
        }

        $params = ['topic_id' => $topic_id, 'page' => $page, 'page_size' => $page_size];
        $model = new Topic();
        return $model->selectTopicDetail($params);
    }

    public function addTopic(){
        $name = $this->request->input('name');
        $audio_list = $this->request->input('audio_list');
        if(empty($name)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '专题名称为空，请重试。');
        }
        if((!is_array($audio_list)) || (count($audio_list) <= 0)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '音频列表不正确，请重试。');
        }
        foreach($audio_list as $audio_id){
            if(!is_numeric($audio_id)){
                throw new BusinessException(BusinessCode::SERVER_ERROR, '音频ID不正确，请重试。');
            }
        }

        $params = ['name' => $name, 'audio_list' => $audio_list];
        $model = new Topic();
        return $model->addTopic($params);
    }

    public function updTopicAudio(){
        $topic_id = $this->request->input('topic_id');
        $name = $this->request->input('name');
        $audio_list = $this->request->input('audio_list');
        if((!is_numeric($topic_id)) || ((int)$topic_id != $topic_id) || ($topic_id <= 0)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '专题ID不正确，请重试。');
        }
        if(empty($name)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '专题名称为空，请重试。');
        }
        if((!is_array($audio_list)) || (count($audio_list) <= 0)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '音频列表不正确，请重试。');
        }
        foreach($audio_list as $audio_id){
            if(!is_numeric($audio_id)){
                throw new BusinessException(BusinessCode::SERVER_ERROR, '音频ID不正确，请重试。');
            }
        }

        $params = ['topic_id' => $topic_id, 'name' => $name, 'audio_list' => $audio_list];
        $model = new Topic();
        return $model->updTopicAudio($params);
    }
    public function updAudioWeight(){
        $topic_id = $this->request->input('topic_id');
        $audio_id = $this->request->input('audio_id');
        $weight = $this->request->input('weight');
        if((!is_numeric($topic_id)) || ((int)$topic_id != $topic_id) || ($topic_id <= 0)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '专题ID不正确，请重试。');
        }
        if(!is_numeric($audio_id)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '音频ID不正确，请重试。');
        }
        if((!is_numeric($weight)) || ((int)$weight != $weight)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '权重不正确，请重试。');
        }

        $params = ['topic_id' => $topic_id, 'audio_id' => $audio_id, 'weight' => $weight];
        $model = new Topic();
        return $model->updAudioWeight($params);
    }
}