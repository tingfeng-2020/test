<?php
declare(strict_types=1);

namespace App\Controller\Admin\Permission;


use App\Annotation\ResponseDataWrap;
use App\Controller\AbstractController;
use App\Model\Permission\Permission;

/**
 * 权限相关
 * Class PermissionController
 * @package App\Controller\Admin\Permission
 * @ResponseDataWrap()
 */
class PermissionController extends AbstractController
{
    /**
     * 获取菜单
     * @return array
     */
    public function getMenu(): array
    {
        return Permission::getMenuList();
    }

    /**
     * 获取权限配置
     * @return array
     */
    public function getList(): array
    {

    }

}