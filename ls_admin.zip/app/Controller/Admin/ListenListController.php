<?php

namespace App\Controller\Admin;

use App\Annotation\ResponseDataWrap;
use App\Constants\BusinessCode;
use App\Controller\AbstractController;
use App\Exception\BusinessException;
use App\Model\ListenList;

/**
 * @ResponseDataWrap()
 */
class ListenListController extends AbstractController
{
    public function selectListenList(){
        $name = $this->request->input('name');
        $description = $this->request->input('description');
        $page = $this->request->input('page');
        $page_size = $this->request->input('page_size');
        if((!is_numeric($page)) || ((int)$page != $page) || ($page <= 0)){
            $page = 1;
        }
        if((!is_numeric($page_size)) || ((int)$page_size != $page_size) || ($page_size <= 0)){
            $page_size = 20;
        }

        $params = ['page' => $page, 'page_size' => $page_size, 'name' => $name, 'description' => $description];
        $model = new ListenList();
        return $model->selectListenList($params);
    }

    public function delListenList(){
        $listen_list_id = $this->request->input('listen_list_id');
        if((!is_numeric($listen_list_id)) || ((int)$listen_list_id != $listen_list_id) || ($listen_list_id <= 0)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '听单ID不正确，请重试。');
        }

        $params = ['listen_list_id' => $listen_list_id];
        $model = new ListenList();
        return $model->delListenList($params);
    }
}