<?php


namespace App\Controller\Admin;

use App\Controller\AbstractController;
use App\Operate\Common\LoginOperate;
use App\Request\FooRequest;
use App\Request\LoginRequest;
use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Annotation\DeleteMapping;
use Hyperf\HttpServer\Annotation\GetMapping;
use Hyperf\HttpServer\Annotation\Middleware;
use Hyperf\HttpServer\Annotation\PutMapping;
use Hyperf\HttpServer\Contract\RequestInterface;
use Phper666\JWTAuth\JWT;

/**
 * Class UserController
 * @package App\Controller\Admin
 */
class UserController extends AbstractController
{
    /**
     *
     * @Inject()
     * @var JWT
     */
    protected $jwt;

    /**
     * 登陆接口
     * @param JWT $jwt
     * @return \Psr\Http\Message\ResponseInterface
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public function login()
    {
        $operate = new LoginOperate($this->request);
        $res =  $operate->done();
        return $this->success($res,'sucess');
    }

    /**
     * 注册接口
     */
    public function createStore()
    {
        //验证账号密码合法性，
        //创建用户，并且生成随机salt，生成密码
        $username = $this->request->input('username');
        $password = $this->request->input('password');
        return $this->success($this->request->inputs());
    }

    # http头部必须携带token才能访问的路由
    public function getData()
    {
        return $this->response->json(['code' => 0, 'msg' => 'success', 'data' => ['a' => 1]]);
    }

    /**
     * @PutMapping(path="refresh")
     * @Middleware(JWTAuthMiddleware::class)
     * @return \Psr\Http\Message\ResponseInterface
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public function refreshToken()
    {
        $token = $this->jwt->refreshToken();
        $data = [
            'code' => 0,
            'msg' => 'success',
            'data' => [
                'token' => (string)$token,
                'exp' => $this->jwt->getTTL(),
            ]
        ];
        return $this->response->json($data);
    }

    /**
     * 退出
     * @DeleteMapping(path="logout")
     * @Middleware(JWTAuthMiddleware::class)
     * @return bool
     * @throws \Psr\SimpleCache\InvalidArgumentException
     */
    public function logout()
    {
        return $this->jwt->logout();
    }

    /**
     * 获取token数据
     * 只能使用default场景值生成的token访问
     * @GetMapping(path="list")
     * @Middleware(JWTAuthSceneDefaultMiddleware::class)
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function getDefaultData(RequestInterface $request)
    {
        $username = $request->all();
        var_dump($username);
//        $ss = $this->jwt->getParserData();
//        return $ss['uid'];
        $data = [
            'code' => 0,
            'msg' => 'success',
            'data' => $this->jwt->getParserData()
        ];
        return $this->response->json($data);
    }
}