<?php

declare(strict_types=1);

namespace App\Controller\Member;

use App\Annotation\ResponseDataWrap;
use App\Controller\AbstractController;
use App\Service\Member\MemberService;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;

/**
 * @ResponseDataWrap()
 */
class MemberController extends AbstractController
{
    protected $service;
    protected $validatorFactory;

    public function __construct(MemberService $service, ValidatorFactoryInterface $validatorFactory)
    {
        parent::__construct();
        $this->service = $service;
        $this->validatorFactory = $validatorFactory;
    }

    /**
     * 会员列表
     * @return array
     */
    public function index(): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'page' => 'integer|min:1',
            'page_size' => 'integer|between:1,100',
            'account' => 'string',
            'nickname' => 'string',
            'is_anchor' => 'integer|in:0,1',
        ]);

        $validated = $validator->validate();
        return $this->service->listMember(
            !empty($validated['page']) ? (int)$validated['page'] : 1,
            !empty($validated['page_size']) ? (int)$validated['page_size'] : 10,
            !empty($validated['account']) ? trim($validated['account']) : '',
            !empty($validated['nickname']) ? trim($validated['nickname']) : '',
            !empty($validated['is_anchor']) ? (int)($validated['is_anchor']) : null
        );
    }

    /**
     * 会员详情
     * @param int $id 会员ID
     * @return array
     */
    public function show(int $id): array
    {
        return $this->service->getMember($id);
    }

    /**
     * 会员禁言/恢复
     * @param int $id 会员ID
     * @return array
     */
    public function switchMute(int $id): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'is_mute' => 'required|integer|in:0,1',
        ]);

        $validated = $validator->validate();
        return $this->service->updateMember($id, $validated);
    }
}
