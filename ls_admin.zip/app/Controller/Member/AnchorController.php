<?php

declare(strict_types=1);

namespace App\Controller\Member;

use App\Annotation\ResponseDataWrap;
use App\Controller\AbstractController;
use App\Service\Member\AnchorService;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;

/**
 * @ResponseDataWrap()
 */
class AnchorController extends AbstractController
{
    protected $service;
    protected $validatorFactory;

    public function __construct(AnchorService $service, ValidatorFactoryInterface $validatorFactory)
    {
        parent::__construct();
        $this->service = $service;
        $this->validatorFactory = $validatorFactory;
    }

    /**
     * 主播列表
     * @return array
     */
    public function index(): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'page' => 'integer|min:1',
            'page_size' => 'integer|between:1,100',
            'account' => 'string',
            'nickname' => 'string',
        ]);

        $validated = $validator->validate();
        return $this->service->listAnchor(
            !empty($validated['page']) ? (int)$validated['page'] : 1,
            !empty($validated['page_size']) ? (int)$validated['page_size'] : 10,
            !empty($validated['account']) ? trim($validated['account']) : '',
            !empty($validated['nickname']) ? trim($validated['nickname']) : ''
        );
    }

    /**
     * 主播详情
     * @param int $id 主播ID
     * @return array
     */
    public function show(int $id): array
    {
        return $this->service->getAnchor($id);
    }

    /**
     * 添加主播
     * @return array
     */
    public function store(): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'account' => 'required|string|max:11|unique:member,account',
            'nickname' => 'required|string|max:16',
            'avatar' => 'required|string',
            'desc' => 'required|string|max:120',
        ]);

        $validated = $validator->validate();
        return $this->service->createAnchor($validated);
    }

    /**
     * 编辑主播
     * @param int $id 主播ID
     * @return array
     */
    public function update(int $id): array
    {
        $validator = $this->validatorFactory->make($this->request->all(), [
            'account' => 'required|string|max:11|unique:member,account,' . $id,
            'nickname' => 'required|string|max:16',
            'avatar' => 'required|string',
            'desc' => 'required|string|max:120',
        ]);

        $validated = $validator->validate();
        return $this->service->updateAnchor($id, $validated);
    }
}
