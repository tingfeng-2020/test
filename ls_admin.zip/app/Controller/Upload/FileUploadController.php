<?php

declare(strict_types=1);

namespace App\Controller\Upload;

use App\Annotation\ResponseDataWrap;
use App\Constants\BusinessCode;
use App\Controller\AbstractController;
use App\Exception\BusinessException;
use App\Service\Upload\FileUploadService;
use Hyperf\Filesystem\FilesystemFactory;

/**
 * @ResponseDataWrap()
 */
class FileUploadController extends AbstractController
{
    protected $service;
    protected $filesystem;

    public function __construct(FileUploadService $service, FilesystemFactory $factory)
    {
        parent::__construct();
        $this->service = $service;
        $this->filesystem = $factory->get('oss');
    }

    /**
     * 公共上传文件接口
     * @return array
     */
    public function index(): array
    {
        if (!$this->request->hasFile('file')) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '文件不能为空');
        }
        return $this->service->upload($this->request->file('file'), $this->filesystem);
    }

    /**
     * 音频文件上传接口，增加 文件大小size、音频时长duration 字段返回
     * @return array
     */
    public function uploadAudio(): array
    {
        if (!$this->request->hasFile('file')) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '文件不能为空');
        }
        return $this->service->uploadAudio($this->request->file('file'), $this->filesystem);
    }
}
