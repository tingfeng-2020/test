<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://doc.hyperf.io
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */
namespace App\Controller;

use App\Aspect\FooAspect;
use App\Constants\ErrorCode;
use App\Exception\ApiException;
use App\Exception\BusinessException;
use App\Exception\FooException;
use App\Model\Permission;
use App\Model\Role;
use App\Model\User;
use App\Request\FooRequest;
use App\Service\UserServiceEvent;
use App\Tools\Aes;
use App\Tools\PasswordHash;
use Hyperf\Contract\TranslatorInterface;
use Hyperf\HttpServer\Annotation\AutoController;
use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Contract\RequestInterface;
use Hyperf\Paginator\Paginator;
use Hyperf\Utils\Collection;
use Hyperf\Utils\Exception\ParallelExecutionException;
use Hyperf\Utils\Coroutine;
use Hyperf\Utils\Parallel;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;
use Phper666\JWTAuth\JWT;


class IndexController extends AbstractController
{
    /**
     * @Inject
     * @var UserServiceInterface
     */
    private $userService;
    public function index()
    {
        return $this->success([1,2,3],'ok');
    }

    /** @Inject
     * @var Aes
     * @return string
     */
    private $aes;
    public function test()
    {
        $pwd1 = $this->aes->encrypt('abc');
        $pwd2 = $this->aes->decrypt($pwd1);
       return $pwd1.'----'.$pwd2;
    }


    public function pwd()
    {
        $ok = 0;

# Try to use stronger but system-specific hashes, with a possible fallback to
# the weaker portable hashes.
        $t_hasher = new PasswordHash(8, FALSE);

        $correct = 'test12345';
        $hash = $t_hasher->hashPassword($correct);

        print 'Hash: ' . $hash . "\n";

        $check = $t_hasher->checkPassword($correct, $hash);
        if ($check) $ok++;
        print "Check correct: '" . $check . "' (should be '1')\n";

        $wrong = 'test12346';
        $check = $t_hasher->checkPassword($wrong, $hash);
        if (!$check) $ok++;
        print "Check wrong: '" . $check . "' (should be '0' or '')\n";

        unset($t_hasher);
        echo $ok;

    }

}
