<?php


namespace App\Operate;


use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Contract\RequestInterface;

/**
 * Class BaseOperate
 * @package App\Operate
 */
abstract class BaseOperate
{
    /**
     * @Inject
     * @var RequestInterface
     */
    protected $request;

    protected function check(){

    }

    public function done()
    {
        $this->check();
        return $this->doBusiness();
    }

    abstract protected function doBusiness();
}