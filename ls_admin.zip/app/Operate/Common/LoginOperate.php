<?php


namespace App\Operate\Common;



use App\Exception\ApiException;
use App\Exception\BusinessException;
use App\Model\User;
use App\Operate\BaseOperate;
use App\Tools\Aes;
use App\Tools\PasswordHash;
use Hyperf\Di\Annotation\Inject;
use Hyperf\Validation\Contract\ValidatorFactoryInterface;
use Hyperf\Validation\Rule;
use Phper666\JWTAuth\JWT;

/**
 * 管理员登陆
 * Class LoginOperate
 * @package App\Operate\Common
 */
class LoginOperate extends BaseOperate
{

    /**
     * @Inject()
     * @var ValidatorFactoryInterface
     */
    protected $validationFactory;

    /**
     * 解密注解
     * @Inject
     * @var Aes
     * @return string
     */
    protected $aes;

    /**
     * Token注解
     * @Inject()
     * @var JWT
     */
    protected $jwt;

    protected $password;

    protected $email;


    protected $roles;

    protected $user;

    protected function check()
    {
        $validator = $this->validationFactory->make(
            $this->request->all(),
            [
                'email' => [
                    'required',
                    'email',
                    Rule::exists(config('permission.table_names.user'))->where(static function ($query) {
                        $query->where('status',User::$status_en['enable']);
                    }),
                ],
                'password' => [
                    'required',
                ]
            ],
            [
                'email.required' => ':attribute 是必须的～',
                'email.exists' => ':attribute 用户不存在或用户被锁定,请联系管理员~',
                'email.email' => ':attribute 请输入正确的邮箱地址~',
                'password.required'  => ':attribute 是必须的～',
            ]
        );

        if ($validator->fails()) {
            $errorMessage = $validator->errors()->first();
            throw new BusinessException(1000,$errorMessage);
        }

        //解密password
        $this->password = $this->aes->decrypt($this->request->input('password'));
        $this->email = $this->request->input('email');

        $user = User::query()
            ->where('email',$this->email)
            ->first();

        $this->user = (clone $user)->toArray();
        $this->roles = $user ? $user->getRoleNames()->toArray() : '';


        //密码转义
        $passHash = make(PasswordHash::class,
            [
                config('password_hash.iteration_count_log2'),
                config('password_hash.portable_hashes')
            ]
        );

        //校验密码
        if(!$passHash->checkPassword($this->user['salt'].$this->password,$this->user['password'])) {
            throw new BusinessException(1000,'密码不正确');
        }


    }

    protected function doBusiness()
    {
        $data = [];
        if ($this->password && $this->email) {
            $userData = [
                'uid' => $this->user['user_id'],
                'username' => $this->user['username'],
                'nickname' => $this->user['nickname'],
                'email' => $this->user['email'],
                'sex' => $this->user['sex'],
                'phone' => $this->user['phone'],
                'avatar' => $this->user['avatar'],
                'roles' => $this->roles ? implode(',',$this->roles) : '',
                'created_at' => $this->user['created_at'],
            ];
            // 使用默认场景登录
            $token = $this->jwt->setScene('default')->getToken($userData);
            $data = [
                'token' => $token,
                'exp' => $this->jwt->getTTL(),
                'info' => $userData
            ];
        }

        return $data;
    }


}