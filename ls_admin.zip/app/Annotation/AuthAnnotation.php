<?php

declare(strict_types=1);

namespace App\Annotation;

use Hyperf\Di\Annotation\AbstractAnnotation;

/**
 * 路由授权注解
 * @Annotation
 * @Target({"CLASS", "METHOD"})
 */
class AuthAnnotation extends AbstractAnnotation
{
    /**
     * 路由标示,用来授权的时候，绑定方法的字段
     * @var string
     */
    public $name = '';
}
