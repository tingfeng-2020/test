<?php

declare(strict_types=1);

namespace App\Aspect;

use App\Annotation\AuthAnnotation;
use App\Annotation\PermissionCheck;
use App\Common\ResponseData;
use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use Hyperf\Di\Annotation\Aspect;
use Hyperf\Di\Aop\AbstractAspect;
use Hyperf\Di\Aop\ProceedingJoinPoint;
use Psr\Container\ContainerInterface;

/**
 * 权限验证注解
 * @Aspect
 */
class PermissonCheckAspect extends AbstractAspect
{
    protected $container;

    /**
     *  要切入的注解，具体切入的还是使用了这些注解的类，仅可切入类注解和类方法注解
     * @var string[]
     */
    public $annotations = [
        AuthAnnotation::class,
    ];

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function process(ProceedingJoinPoint $proceedingJoinPoint)
    {
        //验证权限
        $user = $proceedingJoinPoint->getAnnotationMetadata()->method[AuthAnnotation::class];

        if ($user && $user->can($name)) {
            return $proceedingJoinPoint->process();
        }
        throw new BusinessException(BusinessCode::UNAUTHORIZED, '无权进行该操作/请联系管理人员');
    }
}
