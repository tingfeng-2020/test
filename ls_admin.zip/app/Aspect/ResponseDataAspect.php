<?php

declare(strict_types=1);

namespace App\Aspect;

use App\Annotation\ResponseDataWrap;
use App\Common\ResponseData;
use Hyperf\Di\Annotation\Aspect;
use Hyperf\Di\Aop\AbstractAspect;
use Hyperf\Di\Aop\ProceedingJoinPoint;

/**
 * @Aspect
 */
class ResponseDataAspect extends AbstractAspect
{
    public $annotations = [
        ResponseDataWrap::class,
    ];

    public function process(ProceedingJoinPoint $proceedingJoinPoint)
    {
        return ResponseData::successful($proceedingJoinPoint->process());
    }
}
