<?php

declare(strict_types=1);

namespace App\Common;

use App\Constants\BusinessCode;

class ResponseData
{
    public static function make(int $code, string $msg = '', $data = null): array
    {
        if ($msg === '') {
            $msg = BusinessCode::getMessage($code);
        }
        return ['code' => $code, 'msg' => $msg, 'data' => $data];
    }

    public static function successful($data = null, string $msg = '', int $code = BusinessCode::SUCCESSFUL): array
    {
        return self::make($code, $msg, $data);
    }
}
