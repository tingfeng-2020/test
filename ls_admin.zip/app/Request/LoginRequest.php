<?php

declare(strict_types=1);

namespace App\Request;

use App\Model\User;
use App\Tools\Aes;
use App\Tools\PasswordHash;
use Hyperf\Di\Annotation\Inject;
use Hyperf\Validation\Request\FormRequest;
use Hyperf\Validation\Rule;
class LoginRequest extends FormRequest
{
    /**
     * @Inject
     * @var Aes
     * @return string
     */
    private $aes;

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'username' => [
                'required',
//                'length:4',
                Rule::exists(config('permission.table_names.user'))->where(function ($query) {
                    $query->where('status',User::$status_en['enable']);
                }),
            ],
            'password' => [
                'required',
                Rule::requiredIf(function ()  {
                    return 'tt';
                }),

            ],
        ];

    }



    /**
     * 获取已定义验证规则的错误消息
     */
    public function messages(): array
    {
        return [
            'username.required' => ':attribute 是必须的～',
            'username.exists' => '用户不存在或用户被锁定,请联系管理员~',
            'username.length' => '用户名长度只能4位!',
            'password.required'  => ':attribute 是必须的～',
            'password.exists'  => ':attribute 密码不正确!',
            'password.requiredIf'  => ':attribute testset!',
        ];
    }

    /**
     * 获取验证错误的自定义属性
     */
    public function attributes(): array
    {
        return [
            'username' => 'username:',
            'password' => 'password:',
        ];
    }

    /**
     * 密码验证转换
     * @return string
     */
    public function getPassWord(): string
    {
        if($this->input('password')) return '';
        //解密password
        $pwd = $this->aes->decrypt($this->input('password'));
        //拿盐
        $salt = User::query()->where('username',$this->input('username'))->value('salt');
        //密码转义
        $hash = make(PasswordHash::class,[8,false]);
//        $hash = new PasswordHash(8,false);
        return $hash->hashPassword($pwd.$salt);
    }

    public function tt(){
        return false;
    }
}
