<?php

declare(strict_types=1);

namespace App\Constants;

use Hyperf\Constants\AbstractConstants;
use Hyperf\Constants\Annotation\Constants;

/**
 * @Constants
 */
class ErrorCode extends AbstractConstants
{
    /**
     * @Message("成功")
     */
    public const OK = 0;

    /**
     * @Message("通用错误码")
     */
    public const PARAMS_INVALID = 1000;

    /**
     * @Message("服务器错误")
     */
    public const SERVER_ERROR = 1001;

    /**
     * @Message("路由错误")
     */
    public const ROUTE_INVALID = 1011;



    /**
     * @Message("系统参数错误")
     */
    public const SYSTEM_INVALID = 700;
    public const CLIENT_INVALID = 401;

    public static function getMessage(int $code)
    {
        return trans("error.{$code}") ?? 'No matching results.';
    }
}
