<?php

declare(strict_types=1);

namespace App\Constants;

class OS
{
    public const ANDROID = 1;
    public const IOS = 2;
    public const H5 = 3;
}
