<?php

declare(strict_types=1);

namespace App\Constants;

class BusinessCode
{
    public const SUCCESSFUL = 0;

    public const BAD_REQUEST = 1000;
    public const SERVER_ERROR = 1001;
    public const TOKEN_FAIL = 1003;

    public const ACCOUNT_UNUSUAL = 1201;
    public const UNAUTHORIZED = 1202;

    public static $message = [
        self::SUCCESSFUL => '成功',

        //通用错误码：1000-1099
        self::BAD_REQUEST => '请求错误', //通用错误码(含各种操作失败，如添加失败、保存失败等)
        self::SERVER_ERROR => '服务器错误',
        1002 => '签名错误',
        self::TOKEN_FAIL => 'Token错误',
        1004 => 'Token过期',
        1005 => '重放请求错误',
        1006 => '系统繁忙',
        1007 => '数据非法',
        1008 => '数据不存在',
        1009 => '操作非法',
        1010 => '第三方调用错误',
        1011 => '路由错误',
        1012 => '请求方式错误',
        1013 => '账号未登录',

        //参数相关：1100-1199
        1100 => '参数为空',
        1101 => '参数值越界',
        1102 => '参数格式错误',
        1103 => '参数长度错误',
        1104 => '参数类型错误',
        1105 => '参数错误——通用',

        //账号与权限相关：1200-1299
        1200 => '账号不存在',
        self::ACCOUNT_UNUSUAL => '账号状态异常',
        self::UNAUTHORIZED => '账号权限错误',
        1203 => '密码错误',
        1204 => '账号被踢出登录状态',
        1205 => '账号已在其他设备登录',

        //用户相关：1300-2999

        //业务相关：3000-9999
    ];

    public static function getMessage($code): string
    {
        return self::$message[$code] ?? '';
    }
}
