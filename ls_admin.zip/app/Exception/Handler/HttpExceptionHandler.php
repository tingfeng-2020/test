<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://hyperf.wiki
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */

namespace App\Exception\Handler;

use App\Common\ResponseData;
use Hyperf\HttpMessage\Exception\HttpException;
use Hyperf\HttpMessage\Stream\SwooleStream;
use Hyperf\HttpServer\Exception\Handler\HttpExceptionHandler as HyperfHttpExceptionHandler;
use Psr\Http\Message\ResponseInterface;
use Throwable;

class HttpExceptionHandler extends HyperfHttpExceptionHandler
{
    public function handle(Throwable $throwable, ResponseInterface $response)
    {
        /** @var HttpException $throwable */
        $this->logger->debug($this->formatter->format($throwable));

        $this->stopPropagation();
        $body = json_encode(ResponseData::make($throwable->getStatusCode(), $throwable->getMessage(), null));
        return $response
            ->withAddedHeader('content-type', 'application/json; charset=utf-8')
            ->withBody(new SwooleStream($body));
    }
}
