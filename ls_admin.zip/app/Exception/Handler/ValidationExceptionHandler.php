<?php

declare(strict_types=1);

namespace App\Exception\Handler;

use App\Common\ResponseData;
use App\Constants\BusinessCode;
use Hyperf\HttpMessage\Stream\SwooleStream;
use Hyperf\Validation\ValidationException;
use Hyperf\Validation\ValidationExceptionHandler as HyperfValidationExceptionHandler;
use Psr\Http\Message\ResponseInterface;
use Throwable;

class ValidationExceptionHandler extends HyperfValidationExceptionHandler
{
    public function handle(Throwable $throwable, ResponseInterface $response)
    {
        /** @var ValidationException $throwable */
        $this->stopPropagation();

        $errors = $throwable->validator->errors();
        $body = json_encode(ResponseData::make(BusinessCode::BAD_REQUEST, $errors->first(), $errors));
        return $response
            ->withAddedHeader('content-type', 'application/json; charset=utf-8')
            ->withBody(new SwooleStream($body));
    }
}
