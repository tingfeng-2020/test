<?php

declare(strict_types=1);

namespace App\Service\Upload;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use App\Model\Upload\OSSEtag;
use getID3;
use Hyperf\HttpMessage\Upload\UploadedFile;
use League\Flysystem\FileExistsException;
use League\Flysystem\Filesystem;
use Ramsey\Uuid\Uuid;

class FileUploadService
{
    protected function upload0(UploadedFile $file, Filesystem $filesystem): string
    {
        $path = self::getFolderPath() . self::getUUIDFilename($file->getExtension());

        $fp = fopen($file->getRealPath(), 'rb+');
        try {
            $filesystem->writeStream($path, $fp);
        } catch (FileExistsException $e) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '文件上传失败(' . $e . ')');
        } finally {
            if (is_resource($fp)) {
                fclose($fp);
            }
        }

        return $path;
    }

    public function upload(UploadedFile $file, Filesystem $filesystem): array
    {
        $etag = md5(file_get_contents($file->getRealPath()));
        $path = self::getFileRecord($etag);

        if (is_null($path)) {
            $path = $this->upload0($file, $filesystem);
            self::saveFileRecord($etag, $path);
        }

        return [
            'path' => $path,
            'url' => config('file.storage.oss.domain') . $path,
        ];
    }

    public function uploadAudio(UploadedFile $file, Filesystem $filesystem): array
    {
        $result = $this->upload($file, $filesystem);
        $result['size'] = $file->getSize();
        $result['duration'] = round((new getID3)->analyze($file->getRealPath())['playtime_seconds'] ?? 0);
        return $result;
    }

    protected static function getFileRecord(string $etag)
    {
        $record = OSSEtag::query()->where('etag', $etag)->first();
        return !is_null($record) ? $record->path : null;
    }

    protected static function saveFileRecord(string $etag, string $path): void
    {
        OSSEtag::query()->create(compact('etag', 'path'));
    }

    protected static function getUUIDFilename(string $suffix = null): string
    {
        return Uuid::uuid4()->toString() . ($suffix ? '.' . $suffix : '');
    }

    protected static function getFolderPath(): string
    {
        return implode('/', ['common', date('Y'), date('md')]) . '/';
    }
}
