<?php

declare(strict_types=1);

namespace App\Service\Audio;

use App\Constants\BusinessCode;
use App\Event\Audio\AudioCreated;
use App\Exception\BusinessException;
use App\Model\Audio\Audio;
use App\Model\Audio\AudioClass;
use App\Model\Audio\Tag;
use App\Model\Member\Member;
use Hyperf\Database\Model\Builder;
use Hyperf\HttpMessage\Exception\NotFoundHttpException;
use Psr\EventDispatcher\EventDispatcherInterface;

class AudioService
{
    private $eventDispatcher;

    public function __construct(EventDispatcherInterface $eventDispatcher)
    {
        $this->eventDispatcher = $eventDispatcher;
    }

    public function listAudio(int $page, int $pageSize, string $name = '', string $anchorName = '', ?int $status = null, ?int $progress = null): array
    {
        $query = Audio::query()->with('anchor:id,nickname', 'classifications:class_id as id,name', 'tags:name');

        if ($name !== '') {
            $query = $query->where('name', 'like', '%' . $name . '%');
        }
        if ($anchorName !== '') {
            $query = $query->whereHas('anchor', static function (Builder $query) use ($anchorName) {
                $query->where('name', 'like', '%' . $anchorName . '%');
            });
            // $query = $query->join('anchor', 'anchor_id', '=', 'anchor.id')->where('anchor.name', 'like', '%' . $anchorName . '%')->select('audio.*', 'anchor.name as anchor_name');
        }
        if (!is_null($status)) {
            $query = $query->where('status', $status);
        }
        if (!is_null($progress)) {
            $query = $query->where('progress', $progress);
        }

        $list = $query->orderByDesc('audio.id')->forPage($page, $pageSize)->get()->toArray();

        foreach ($list as &$item) {
            foreach ($item['tags'] as &$tag) {
                $tag = $tag['name'];
            }
            unset($tag);
        }
        unset($item);

        return [
//            'total_pages' => ($count = $query->count()) !== 0 ? (int)ceil($count / $pageSize) : 1,
            'total' => $query->count(),
            'list' => $list,
        ];
    }

    public function getAudio(int $id): array
    {
        $instance = Audio::query()->with('anchor:id,nickname', 'classifications:class_id as id,name', 'tags:name')->find($id);
        if (is_null($instance)) {
            throw new NotFoundHttpException();
        }

        $result = $instance->toArray();

        foreach ($result['tags'] as &$tag) {
            $tag = $tag['name'];
        }
        unset($tag);

        return $result;
    }

    public function createAudio(array $data): array
    {
        $classArr = AudioClass::query()->whereIn('id', $data['classifications'])->get(['id'])->toArray();
        $diff = array_diff($data['classifications'], array_column($classArr, 'id'));
        if (!empty($diff)) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的分类ID:' . implode(',', $diff));
        }

        if (is_null(Member::query()->find($data['anchor_id']))) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的主播ID:' . $data['anchor_id']);
        }

        /* @var Audio $instance */
        $instance = Audio::query()->create($data);
        $instance->classifications()->attach($data['classifications']);
        $instance->tags()->attach(Tag::bulkQueryOrCreateTag($data['tags']));

        $this->eventDispatcher->dispatch(new AudioCreated($instance, $data['classifications']));

        return $this->getAudio($instance->id);
    }

    public function updateAudio(int $id, array $data): array
    {
        $classArr = AudioClass::query()->whereIn('id', $data['classifications'])->get(['id'])->toArray();
        $diff = array_diff($data['classifications'], array_column($classArr, 'id'));
        if (!empty($diff)) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的分类ID:' . implode(',', $diff));
        }

        if (is_null(Member::query()->find($data['anchor_id']))) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的主播ID:' . $data['anchor_id']);
        }

        /* @var Audio $instance */
        $instance = Audio::query()->find($id);
        if (is_null($instance)) {
            throw new NotFoundHttpException();
        }

        $instance->fill($data)->save();
        $instance->classifications()->sync($data['classifications']);
        $instance->tags()->sync(Tag::bulkQueryOrCreateTag($data['tags']));

        return $this->getAudio($id);
    }

    public function switchStatus(int $id, int $status): array
    {
        $instance = Audio::query()->find($id);
        if (is_null($instance)) {
            throw new NotFoundHttpException();
        }
        $instance->fill(compact('status'))->save();
        return $instance->toArray();
    }

    public function deleteAudio(array $ids): array
    {
        return [
            'result' => Audio::destroy($ids),
        ];
    }

    public function searchAudio(string $name): array
    {
        $wheres = [];
        if ($name) {
            $wheres[] = ['name', 'like', '%' . $name . '%'];
        }

        return [
            'list' => Audio::query()
                ->where($wheres)
                ->orderByDesc('id')
                ->limit(20)
                ->get(['id', 'name']),
        ];
    }
}
