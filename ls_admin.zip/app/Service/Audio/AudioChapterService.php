<?php

declare(strict_types=1);

namespace App\Service\Audio;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use App\Model\Audio\Audio;
use App\Model\Audio\AudioChapter;
use App\Model\Audio\AudioClass;
use Hyperf\DbConnection\Db;
use Hyperf\HttpMessage\Exception\NotFoundHttpException;
use Hyperf\Snowflake\IdGeneratorInterface;
use Hyperf\Utils\ApplicationContext;

class AudioChapterService
{
    public function listChapter(int $audioId, int $page, int $pageSize, string $name): array
    {
        $query = AudioChapter::query()->where('audio_id', $audioId);

        if ($name !== '') {
            $query = $query->where('name', 'like', '%' . $name . '%');
        }

        return [
//            'total_pages' => (int)ceil($query->count() / $pageSize),
            'total' => AudioChapter::query()->count(),
            'list' => $query->orderByDesc('id')->forPage($page, $pageSize)->get(),
        ];
    }

    public function getChapter(int $id): array
    {
        $instance = AudioChapter::query()->find($id);
        if (is_null($instance)) {
            throw new NotFoundHttpException();
        }
        return $instance->toArray();
    }

    public function createChapters(int $audioId, array $list): array
    {
        if (is_null(Audio::query()->find($audioId))) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的音频ID');
        }

        $container = ApplicationContext::getContainer();
        $generator = $container->get(IdGeneratorInterface::class);

        foreach ($list as &$item) {
            $item['id'] = $generator->generate();
            $item['audio_id'] = $audioId;
        }
        unset($item);

        $result = AudioChapter::query()->insert($list);
        return ['result' => $result];
    }

    public function updateChapter(int $id, array $data): array
    {
        if (!AudioClass::query()->where('id', $data['class_id'])->exists()) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的分类');
        }

        $instance = Audio::query()->where('id', $id)->first();
        if (is_null($instance)) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的音频');
        }

        $instance->update($data);
        return $instance->toArray();
    }

    public function deleteChapter(array $ids): array
    {
        return [
            'result' => Audio::destroy($ids),
        ];
    }

    public function lastChapter(int $audioId): ?array
    {
        $instance = AudioChapter::query()->where('audio_id', $audioId)->latest('id')->first();
        if (is_null($instance)) {
            return null;
        }
        return $instance->toArray();
    }

    public function updateAmount(int $audioId, int $start, $amount): ?array
    {
        $result = 0;
        Db::transaction(static function () use ($audioId, $start, $amount, &$result) {
            $result += AudioChapter::query()
                ->where('audio_id', $audioId)
                ->where('sequence', '>=', $start)
                ->update(['need_pay' => 1, 'amount' => $amount]);

            $result += AudioChapter::query()
                ->where('audio_id', $audioId)
                ->where('sequence', '<', $start)
                ->update(['need_pay' => 0, 'amount' => 0]);
        });

        return ['result' => $result];
    }
}
