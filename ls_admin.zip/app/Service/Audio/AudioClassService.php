<?php

declare(strict_types=1);

namespace App\Service\Audio;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use App\Model\Audio\AudioClass;
use App\Model\Audio\AudioClassAudio;

class AudioClassService
{
    public function listClass(int $page, int $pageSize, string $name): array
    {
        $query = AudioClass::query()->with('parent:id,name');

        if ($name !== '') {
            $query = $query->where(['name', 'like', '%' . $name . '%']);
        }

        return [
            'total' => $query->count(),
            'list' => $query->orderByDesc('id')->forPage($page, $pageSize)->get(),
        ];
    }

    public function getClass(int $id): array
    {
        $instance = AudioClass::query()->with('parent:id,name')->find($id);
        if (is_null($instance)) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '该分类不存在');
        }
        return $instance->toArray();
    }

    public function createClass(array $data): array
    {
        if ((int)$data['parent_id'] !== 0 && !AudioClass::query()->find($data['parent_id'])) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的父分类');
        }

        /* @var AudioClass $instance */
        $instance = AudioClass::query()->create($data);
        return $this->getClass($instance->id);
    }

    public function updateClass(int $id, array $data): array
    {
        if ((int)$data['parent_id'] !== 0 && !AudioClass::query()->find($data['parent_id'])) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的父分类');
        }

        $instance = AudioClass::query()->find($id);
        if (is_null($instance)) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '无效的分类');
        }

        $result = $instance->fill($data)->save();
        return [
            'result' => $result
        ];
    }

    public function deleteClass(int $id): array
    {
        $count = AudioClassAudio::query()->where('class_id', $id)->count();
        if ($count > 0) {
            throw new BusinessException(BusinessCode::BAD_REQUEST, '该分类下已有' . $count . '本书籍，不可删除！');
        }

        return [
            'result' => AudioClass::destroy($id),
        ];
    }

    public function topClass(): array
    {
        return [
            'list' => AudioClass::query()->where('parent_id', 0)->orderByDesc('id')->get(['id', 'name']),
        ];
    }

    public function treeClass(): array
    {
        return [
            'list' => self::generateTree(AudioClass::query()->get(['id', 'parent_id', 'name']), 0, 'parent_id'),
        ];
    }

    protected static function generateTree($list, int $parentId, string $key): array
    {
        $tree = [];
        foreach ($list as $item) {
            if ($item[$key] === $parentId) {
                $item['children'] = self::generateTree($list, $item['id'], $key);
                $tree[] = $item;
            }
        }
        return $tree;
    }
}
