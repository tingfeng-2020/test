<?php


namespace App\Service;


class UserService extends BaseService
{

}