<?php

declare(strict_types=1);

namespace App\Service\Member;

use App\Model\Member\Member;
use Hyperf\HttpMessage\Exception\NotFoundHttpException;

class MemberService
{
    public function listMember(int $page, int $pageSize, string $account, string $nickname, ?int $isAnchor): array
    {
        $query = Member::query();

        if ($account !== '') {
            $query = $query->where('account', 'like', '%' . $account . '%');
        }

        if ($nickname !== '') {
            $query = $query->where('nickname', 'like', '%' . $nickname . '%');
        }

        if (!is_null($isAnchor)) {
            $query = $query->where('is_anchor', $isAnchor);
        }

        $columns = [
            'id', 'account', 'nickname', 'follows', 'fans', 'created_at', 'last_login_at', 'is_mute',
            'gender', 'reg_source',
        ];
        return [
            'total' => $query->count(),
            'list' => $query->orderByDesc('id')->forPage($page, $pageSize)->get($columns)->toArray(),
        ];
    }

    public function getMember(int $id): array
    {
        $columns = [
            'id',
            'nickname',
            'account',
            'gender',
            'birthday',
            'address',
            'signature',
            'fans',
            'follows',
            'created_at',
            'reg_source',
            'last_login_at',
        ];
        $instance = Member::query()->where('is_anchor', 1)->find($id, $columns);
        if (is_null($instance)) {
            throw new NotFoundHttpException();
        }

        $result = $instance->toArray();

        // FIXME 缺少 位置信息 和 IP信息，后续从埋点数据中获取
        $result['location'] = [];
        $result['ip'] = [];

        return $result;
    }

    public function updateMember(int $id, array $data): array
    {
        $instance = Member::query()->find($id);
        if (is_null($instance)) {
            throw new NotFoundHttpException();
        }
        $result = $instance->fill($data)->save();
        return [
            'result' => $result
        ];
    }
}
