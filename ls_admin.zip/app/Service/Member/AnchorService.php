<?php

declare(strict_types=1);

namespace App\Service\Member;

use App\Model\Member\Member;
use Hyperf\HttpMessage\Exception\NotFoundHttpException;

class AnchorService
{
    public function listAnchor(int $page, int $pageSize, string $account, string $nickname): array
    {
        $query = Member::query();

        if ($account !== '') {
            $query = $query->where('account', 'like', '%' . $account . '%');
        }

        if ($nickname !== '') {
            $query = $query->where('nickname', 'like', '%' . $nickname . '%');
        }

        $list = $query
            ->where('is_anchor', 1)
            ->select(['id', 'account', 'nickname', 'follows', 'fans', 'created_at'])
            ->orderByDesc('id')
            ->forPage($page, $pageSize)
            ->withCount('audios as audio_count')
            ->get()
            ->toArray();

        return [
            'total' => $query->count(),
            'list' => $list,
        ];
    }

    public function getAnchor(int $id): array
    {
        return (new MemberService())->getMember($id);
    }

    public function createAnchor(array $data): array
    {
        $data['is_anchor'] = 1;
        /* @var Member $instance */
        $instance = Member::query()->create($data);
        return [
            'id' => $instance->id,
        ];
    }

    public function updateAnchor(int $id, array $data): array
    {
        /* @var Member $instance */
        $instance = Member::query()->find($id);
        if (is_null($instance)) {
            throw new NotFoundHttpException();
        }
        $instance->fill($data)->save();
        return [
            'id' => $instance->id,
        ];
    }
}
