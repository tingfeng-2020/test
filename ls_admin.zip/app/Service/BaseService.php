<?php


namespace App\Service;

class BaseService
{
    //TODO: 待定
    public function __construct()
    {

    }
}
