<?php

declare(strict_types=1);

namespace App\Event\Audio;

class AudioCreated
{
    public $audio;
    public $classIds;

    public function __construct($audio, $classIds)
    {
        $this->audio = $audio;
        $this->classIds = $classIds;
    }
}
