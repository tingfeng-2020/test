<?php

declare(strict_types=1);

namespace App\Event\Audio;

class AudioStatusChanged
{
    public $audio;

    public function __construct($audio)
    {
        $this->audio = $audio;
    }
}
