<?php

declare(strict_types=1);

namespace App\Event\Audio;

class AudioClassUpdated
{
    public $oldAudioClass;
    public $newAudioClass;

    public function __construct($oldAudioClass, $newAudioClass)
    {
        $this->oldAudioClass = $oldAudioClass;
        $this->newAudioClass = $newAudioClass;
    }
}
