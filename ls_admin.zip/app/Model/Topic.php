<?php

namespace App\Model;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use App\Model\Model;
use Hyperf\DbConnection\Db;

class Topic extends Model
{
    const TOPIC_TYPE_AUDIO = 1; // 专题类型：音频分类
    const TOPIC_TYPE_INTELLIGENCE = 2; // 专题类型：智能推荐
    const TOPIC_TYPE_OPERATE = 3; // 专题类型：运营推荐
    const UPDATED_AT = null;

    public $topicTypeList = [self::TOPIC_TYPE_AUDIO => '音频分类', self::TOPIC_TYPE_INTELLIGENCE => '智能推荐', self::TOPIC_TYPE_OPERATE => '运营推荐'];
    protected $table = 'topic';
    protected $fillable = ['name', 'type'];

    public function selectTopicList($params){
        $where = [];
        if(!empty($params['name'])){
            $where[] = ['name', 'like', '%' . $params['name'] . '%'];
        }

        $total = Db::connection('lsbook')->table('topic')->where($where)->count();
        if($total <= 0){
            return ['total' => 0, 'list' => []];
        }

        $topicList = Db::connection('lsbook')->table('topic')->where($where)
            ->orderBy('type', 'desc')->orderBy('id', 'desc')->offset(($params['page'] - 1) * $params['page_size'])->limit($params['page_size'])->get()->toArray();
        $topicIDList = array_column($topicList, 'id');
        $numAudioList = Db::connection('lsbook')->table('topic_audio')
            ->select('topic_id', Db::raw('count(1) as num_audio'))->whereIn('topic_id', $topicIDList)->groupBy('topic_id')->get()->toArray();
        $tmpList = array_column($numAudioList, 'num_audio', 'topic_id');
        foreach($topicList as $i => $topic){
            $topicList[$i]->num_audio = isset($tmpList[$topic->id]) ? $tmpList[$topic->id] : 0;
            $topicList[$i]->type_name = $this->topicTypeList[$topic->type];
        }

        return ['total' => $total, 'list' => $topicList];
    }

    public function selectTopicDetail($params){
        $total = Db::connection('lsbook')->table('topic_audio')->where('topic_id', $params['topic_id'])->count();
        if($total <= 0){
            return ['total' => 0, 'list' => []];
        }

        $topicAudioList = Db::connection('lsbook')->table('topic_audio')->where('topic_id', $params['topic_id'])
            ->offset(($params['page'] - 1) * $params['page_size'])->limit($params['page_size'])->get()->toArray();
        $audioIDList = array_unique(array_column($topicAudioList, 'audio_id'));
        $audioList = Db::connection('lsbook')->table('audio')->join('audio_class_audio', 'audio.id', '=', 'audio_class_audio.audio_id')
            ->select('audio.id', 'audio.name', 'audio.cover', 'audio.author', 'audio_class_audio.class_id')->whereIn('audio.id', $audioIDList)->get()->toArray();
        $audioTypeList = array_unique(array_column($audioList, 'class_id'));
        $audioList = array_column($audioList, null, 'id');
        $tmpList = Db::connection('lsbook')->table('audio_class')->select('id', 'name')->whereIn('id', $audioTypeList)->get()->toArray();
        $tmpList = array_column($tmpList, 'name', 'id');
        foreach($audioList as $audio_id => $audio){
            $audioList[$audio_id]->class_name = $tmpList[$audio->class_id];
        }
        foreach($topicAudioList as $i => $topicAudio){
            $topicAudioList[$i]->audio_name = $audioList[$topicAudio->audio_id]->name;
            $topicAudioList[$i]->audio_cover = $audioList[$topicAudio->audio_id]->cover;
            $topicAudioList[$i]->audio_author = $audioList[$topicAudio->audio_id]->author;
            $topicAudioList[$i]->audio_class = $audioList[$topicAudio->audio_id]->class_name;
        }

        return ['total' => $total, 'list' => $topicAudioList];
    }

    public function addTopic($params){
        if(Db::connection('lsbook')->table('topic')->where('name', $params['name'])->exists()){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '专题已存在，请重试。');
        }

        $topic_id = Db::connection('lsbook')->table('topic')->insertGetId(['name' => $params['name'], 'type' => self::TOPIC_TYPE_OPERATE]);
        if((!is_numeric($topic_id)) || ((int)$topic_id != $topic_id) || ($topic_id <= 0)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '专题添加异常，请重试。');
        }

        $tmpList = [];
        foreach($params['audio_list'] as $audio_id){
            $tmpList[] = ['topic_id' => $topic_id, 'audio_id' => $audio_id];
        }

        Db::connection('lsbook')->table('topic_audio')->insert($tmpList);
        return [];
    }

    public function updTopicAudio($params){
        if(Db::connection('lsbook')->table('topic')->where([['name', '=', $params['name']], ['id', '!=', $params['topic_id']]])->exists()){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '专题已存在，请重试。');
        }

        Db::connection('lsbook')->table('topic')->where('id', $params['topic_id'])->update(['name' => $params['name']]);
        $topicAudioList = Db::connection('lsbook')->table('topic_audio')->where('topic_id', $params['topic_id'])->get()->toArray();
        $oldAudioList = array_column($topicAudioList, 'audio_id');
        $addAudioList = array_diff($params['audio_list'], $oldAudioList);
        $delAudioList = array_diff($oldAudioList, $params['audio_list']);
        if(count($addAudioList) > 0){
            $insertList = [];
            foreach($addAudioList as $audio_id){
                $insertList[] = ['topic_id' => $params['topic_id'], 'audio_id' => $audio_id];
            }

            Db::connection('lsbook')->table('topic_audio')->insert($insertList);
        }
        if(count($delAudioList) > 0){
            Db::connection('lsbook')->table('topic_audio')->where('topic_id', $params['topic_id'])->whereIn('audio_id', $delAudioList)->delete();
        }

        return [];
    }

    public function updAudioWeight($params){
        Db::connection('lsbook')->table('topic_audio')
            ->where([['topic_id', '=', $params['topic_id']], ['audio_id', '=', $params['audio_id']]])->update(['weight' => $params['weight']]);
        return [];
    }
}