<?php

namespace App\Model;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use App\Model\Model;
use Hyperf\DbConnection\Db;

class Comment extends Model
{
    const COMMENT_STATUS_DEL = 0; // 评论状态：无效
    const COMMENT_STATUS_OK = 1; // 评论状态：有效
    const COMMENT_TOPPED_NO = 0; // 评论置顶：否
    const COMMENT_TOPPED_YES = 1; // 评论置顶：是

    public $commentStatusList = [self::COMMENT_STATUS_DEL => '无效', self::COMMENT_STATUS_OK => '有效'];
    public $toppedStatusList = [self::COMMENT_TOPPED_NO => '否', self::COMMENT_TOPPED_YES => '是'];

    public function selectCommentList($params){
        $sqlHandle = Db::connection('lsbook')->table('comment')->where('status', self::COMMENT_STATUS_OK);
        if(!empty($params['content'])){
            $sqlHandle->where('content', 'like', '%' . $params['content'] . '%');
        }
        if(!empty($params['comment_member'])){
            $tmpList = Db::connection('lsbook')->table('member')->select('id')->where('nickname', 'like', '%'. $params['comment_member'] . '%')->get()->toArray();
            $sqlHandle->whereIn('member_id', array_column($tmpList, 'id'));
        }
        if(!empty($params['audio_member'])){
            $tmpList = Db::connection('lsbook')->table('audio')->select('id')->where('author', 'like', '%'. $params['audio_member'] . '%')->get()->toArray();
            $sqlHandle->whereIn('audio_id', array_column($tmpList, 'id'));
        }

        $total = $sqlHandle->count();
        if($total <= 0){
            return ['total' => 0, 'list' => []];
        }

        $commentList = $sqlHandle->orderBy('id', 'desc')->offset(($params['page'] - 1) * $params['page_size'])->limit($params['page_size'])->get()->toArray();
        $commentIDList = array_column($commentList, 'id');
        $memberIDList = array_unique(array_column($commentList, 'member_id'));
        $audioIDList = array_unique(array_column($commentList, 'audio_id'));
        $numPraiseList = Db::connection('lsbook')->table('comment_praise')->select('comment_id', Db::raw('count(1) as num_praise'))
            ->whereIn('comment_id', $commentIDList)->groupBy('comment_id')->get()->toArray();
        $memberList = Db::connection('lsbook')->table('member')->select('id', 'nickname')->whereIn('id', $memberIDList)->get()->toArray();
        $audioList = Db::connection('lsbook')->table('audio')->select('id', 'name', 'author')->whereIn('id', $audioIDList)->get()->toArray();
        $numPraiseList = array_column($numPraiseList, 'num_praise', 'comment_id');
        $memberList = array_column($memberList, 'nickname', 'id');
        $audioList = array_column($audioList, null, 'id');
        foreach($commentList as $i => $comment){
            $commentList[$i]->num_praise = isset($numPraiseList[$comment->id]) ? $numPraiseList[$comment->id] : 0;
            $commentList[$i]->nickname = isset($memberList[$comment->member_id]) ? $memberList[$comment->member_id] : '';
            $commentList[$i]->audio_name = isset($audioList[$comment->audio_id]->name) ? $audioList[$comment->audio_id]->name : '';
            $commentList[$i]->author = isset($audioList[$comment->audio_id]->author) ? $audioList[$comment->audio_id]->author : '';
        }

        return ['total' => $total, 'list' => $commentList];
    }

    public function updCommentStatus($params){
        if(isset($params['topped']) && ($params['topped'] == self::COMMENT_TOPPED_YES)){
            $comment = Db::connection('lsbook')->table('comment')->where('id', $params['comment_id'])->first();
            if(empty($comment)){
                throw new BusinessException(BusinessCode::SERVER_ERROR, '评论不存在，请重试。');
            }

            Db::connection('lsbook')->table('comment')->where('audio_id', $comment->audio_id)->update(['topped' => 0]);
        }

        $updData = [];
        isset($params['status']) ? ($updData['status'] = $params['status']) : null;
        isset($params['topped']) ? ($updData['topped'] = $params['topped']) : null;
        Db::connection('lsbook')->table('comment')->where('id', $params['comment_id'])->update($updData);
        return [];
    }
}