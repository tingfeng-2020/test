<?php

declare(strict_types=1);

namespace App\Model\Permission;

use \Donjan\Permission\Models\Permission as Model;
use Hyperf\Utils\Collection;

class Permission extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'Permission';

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'default';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [];

    /**
     * 获取树形的permission列表.
     * @param int||string $parentId 父级ID
     * @param bool $isUrl 是否是一个URL
     * @param Collection $permission 传入permission集合，如果不传将从所有的permission生成
     * @return Collection
     */
    public static function getMenuList($parentId = 0, $isUrl = false, Collection $permission = null)
    {
        \is_int($parentId) && $parentId = (string)$parentId;
        !$permission && $permission = self::getPermissions();
        $menus = $permission->where('parent_id', $parentId)->sortByDesc('sort')->values();
        if ($isUrl) {
            $menus = $menus->filter(static function($value, $key) {
                return !empty($value->url);
            });
        }
        foreach ($menus as $menu) {
            $menu['child'] = self::getMenuList($menu['id'], $isUrl, $permission);
        }
        return $menus;
    }
}