<?php

namespace App\Model;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use App\Model\Model;
use Hyperf\DbConnection\Db;

class ListenList extends Model
{
    const LISTEN_LIST_STATUS_DEL = 0; // 听单状态：无效
    const LISTEN_LIST_STATUS_OK = 1; // 听单状态：有效

    public $statusList = [self::LISTEN_LIST_STATUS_DEL => '无效', self::LISTEN_LIST_STATUS_OK => '有效'];

    public function selectListenList($params){
        $where = [['status', '=', self::LISTEN_LIST_STATUS_OK]];
        if(!empty($params['name'])){
            $where[] = ['name', 'like', '%' . $params['name'] . '%'];
        }
        if(!empty($params['description'])){
            $where[] = ['description', 'like', '%' . $params['description'] . '%'];
        }

        $total = Db::connection('lsbook')->table('listen_list')->where($where)->count();
        if($total <= 0){
            return ['total' => 0, 'list' => []];
        }

        $listenListArray = Db::connection('lsbook')->table('listen_list')->where($where)
            ->orderBy('id', 'desc')->offset(($params['page'] - 1) * $params['page_size'])->limit($params['page_size'])->get()->toArray();
        $listenListIDArray = array_column($listenListArray, 'id');
        $memberIDList = array_unique(array_column($listenListArray, 'member_id'));
        $memberList = Db::connection('lsbook')->table('member')->select('id', 'nickname')->whereIn('id', $memberIDList)->get()->toArray();
        $memberList = array_column($memberList, 'nickname', 'id');
        $numAudioList = Db::connection('lsbook')->table('listen_list_audio')
            ->select('listen_list_id', Db::raw('count(1) as num_audio'))->whereIn('listen_list_id', $listenListIDArray)->groupBy('listen_list_id')->get()->toArray();
        $numFavorList = Db::connection('lsbook')->table('listen_list_favor')
            ->select('listen_list_id', Db::raw('count(1) as num_favor'))->whereIn('listen_list_id', $listenListIDArray)->groupBy('listen_list_id')->get()->toArray();
        $numAudioList = array_column($numAudioList, 'num_audio', 'listen_list_id');
        $numFavorList = array_column($numFavorList, 'num_favor', 'listen_list_id');
        foreach($listenListArray as $i => $listenList){
            $listenListArray[$i]->nickname = isset($memberList[$listenList->member_id]) ? $memberList[$listenList->member_id] : '';
            $listenListArray[$i]->num_audio = isset($numAudioList[$listenList->id]) ? $numAudioList[$listenList->id] : 0;
            $listenListArray[$i]->num_favor = isset($numFavorList[$listenList->id]) ? $numFavorList[$listenList->id] : 0;
        }

        return ['total' => $total, 'list' => $listenListArray];
    }

    public function delListenList($params){
        $listenList = Db::connection('lsbook')->table('listen_list')->where('id', $params['listen_list_id'])->first();
        if(empty($listenList)) {
            throw new BusinessException(BusinessCode::SERVER_ERROR, '听单不存在，请重试。');
        }
        if($listenList->created_from == 1){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '系统创建的听单不能删除，请重试。');
        }

        Db::connection('lsbook')->table('listen_list')->where('id', $params['listen_list_id'])->update(['status' => self::LISTEN_LIST_STATUS_DEL]);
        return [];
    }
}