<?php

declare(strict_types=1);

namespace App\Model\Audio;

use App\Event\Audio\AudioClassCreated;
use App\Event\Audio\AudioClassDeleted;
use App\Event\Audio\AudioClassUpdated;
use Hyperf\Database\Model\Events\Created;
use Hyperf\Database\Model\Events\Deleted;
use Hyperf\Database\Model\Events\Updating;
use Hyperf\Database\Model\Relations\BelongsTo;
use Hyperf\Database\Model\Relations\BelongsToMany;
use Hyperf\Database\Model\Relations\HasMany;
use Hyperf\DbConnection\Model\Model;
use Hyperf\Utils\ApplicationContext;
use Psr\EventDispatcher\EventDispatcherInterface;

/**
 * @property int id
 */
class AudioClass extends Model
{
    protected $table = 'audio_class';
    protected $fillable = [
        'name', 'parent_id', 'weight', 'status'
    ];
    protected $casts = [
        'created_at' => 'timestamp',
    ];
    protected $hidden = [
        'status',
    ];
    public const UPDATED_AT = null;

    public function parent(): BelongsTo
    {
        return $this->belongsTo(__CLASS__, 'parent_id', 'id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(__CLASS__, 'parent_id', 'id');
    }

    public function audios(): BelongsToMany
    {
        return $this->belongsToMany(Audio::class, 'audio_class_audio', 'class_id', 'audio_id');
    }

    /**
     * 触发创建音频分类事件
     * @param Created $event
     */
    public function created(Created $event): void
    {
        ApplicationContext::getContainer()->get(EventDispatcherInterface::class)->dispatch(new AudioClassCreated($this));
    }

    /**
     * 触发编辑音频分类事件
     * @param Updating $event
     */
    public function updating(Updating $event): void
    {
        ApplicationContext::getContainer()->get(EventDispatcherInterface::class)->dispatch(new AudioClassUpdated($this->fresh(), $this));
    }

    /**
     * 触发删除音频分类事件
     * @param Deleted $event
     */
    public function deleted(Deleted $event): void
    {
        ApplicationContext::getContainer()->get(EventDispatcherInterface::class)->dispatch(new AudioClassDeleted($this));
    }
}
