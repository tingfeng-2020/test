<?php

declare(strict_types=1);

namespace App\Model\Audio;

use Hyperf\DbConnection\Model\Model;

class Tag extends Model
{
    protected $table = 'tag';
    protected $fillable = ['name'];

    public const CREATED_AT = null;
    public const UPDATED_AT = null;

    /**
     * 批量查询或创建标签
     * @param array $names 标签名称数组
     * @return array 标签ID数组
     */
    public static function bulkQueryOrCreateTag(array $names): array
    {
        $ids = [];
        foreach ($names as $name) {
            $attrs = ['name' => $name];
            $ids[] = self::query()->firstOrCreate($attrs, $attrs)->id;
        }
        return $ids;
    }
}
