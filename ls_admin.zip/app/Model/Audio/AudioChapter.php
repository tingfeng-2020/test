<?php

declare(strict_types=1);

namespace App\Model\Audio;

use Hyperf\Database\Model\Relations\BelongsTo;
use Hyperf\DbConnection\Model\Model;
use Hyperf\Snowflake\Concern\Snowflake;

class AudioChapter extends Model
{
    use Snowflake;

    protected $table = 'audio_chapter';
    protected $casts = [
        'created_at' => 'timestamp',
    ];
    public const UPDATED_AT = null;

    public function book(): BelongsTo
    {
        return $this->belongsTo(Audio::class, 'audio_id', 'id');
    }
}
