<?php

declare(strict_types=1);

namespace App\Model\Audio;

use App\Model\Member\Member;
use Hyperf\Database\Model\Relations\BelongsTo;
use Hyperf\Database\Model\Relations\BelongsToMany;
use Hyperf\Database\Model\Relations\HasMany;
use Hyperf\DbConnection\Model\Model;
use Hyperf\Snowflake\Concern\Snowflake;

class Audio extends Model
{
    use Snowflake;

    protected $table = 'audio';
    protected $fillable = [
        'type',
        'name',
        'original_name',
        'status',
        'author',
        'anchor_id',
        'intro',
        'cover',
        'label',
        'quality',
        'progress',
    ];
    protected $casts = [
        'created_at' => 'timestamp',
    ];
    public const UPDATED_AT = null;

    public function anchor(): BelongsTo
    {
        return $this->belongsTo(Member::class, 'anchor_id', 'id');
    }

    public function classifications(): BelongsToMany
    {
        return $this->belongsToMany(AudioClass::class, 'audio_class_audio', 'audio_id', 'class_id');
    }

    public function chapters(): HasMany
    {
        return $this->hasMany(AudioChapter::class, 'audio_id', 'id');
    }

    public function tags(): BelongsToMany
    {
        return $this->belongsToMany(Tag::class, 'audio_tag', 'audio_id', 'tag_id');
    }
}
