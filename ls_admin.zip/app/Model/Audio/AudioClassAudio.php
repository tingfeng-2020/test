<?php

declare(strict_types=1);

namespace App\Model\Audio;

use Hyperf\DbConnection\Model\Model;

class AudioClassAudio extends Model
{
    protected $table = 'audio_class_audio';
    public $timestamps = false;
}
