<?php

declare(strict_types=1);

namespace App\Model\Upload;

use Hyperf\DbConnection\Model\Model;

class OSSEtag extends Model
{
    protected $table = 'oss_etag';
    protected $fillable = ['etag', 'path', 'size'];
    protected $casts = [
        'created_at' => 'timestamp',
    ];
    public const UPDATED_AT = null;
}
