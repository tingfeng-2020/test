<?php

declare(strict_types=1);

namespace App\Model\Member;

use App\Model\Audio\Audio;
use Hyperf\Database\Model\Relations\HasMany;
use Hyperf\DbConnection\Model\Model;
use Hyperf\Snowflake\Concern\Snowflake;

/**
 * @property int id
 * @property int gender
 * @property int reg_source
 */
class Member extends Model
{
    use Snowflake;

    protected $table = 'member';
    protected $fillable = ['account', 'nickname', 'avatar', 'desc', 'is_anchor'];
    protected $casts = [
        'created_at' => 'timestamp',
        'last_login_at' => 'timestamp',
    ];
    protected $appends = ['gender_text', 'reg_source_text'];
    public const UPDATED_AT = null;

    public const GENDER_ENUM = [
        0 => '保密',
        1 => '男',
        2 => '女',
    ];
    public const REG_SOURCE_ENUM = [
        1 => '听书',
        2 => '追书',
        3 => '漫画',
    ];

    public function audios(): HasMany
    {
        return $this->hasMany(Audio::class, 'anchor_id', 'id');
    }

    public function getGenderTextAttribute(): string
    {
        return self::GENDER_ENUM[$this->gender] ?? '';
    }

    public function getRegSourceTextAttribute(): string
    {
        return self::REG_SOURCE_ENUM[$this->reg_source] ?? '';
    }
}
