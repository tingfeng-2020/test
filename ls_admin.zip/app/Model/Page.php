<?php

namespace App\Model;

use App\Constants\BusinessCode;
use App\Exception\BusinessException;
use App\Model\Model;
use Hyperf\DbConnection\Db;

class Page extends Model
{
    const PAGE_STATUS_NOT_PUB = 0; // 页面状态：待发布
    const PAGE_STATUS_PUB = 1; // 页面状态：已发布

    public $statusList = [self::PAGE_STATUS_NOT_PUB => '待发布', self::PAGE_STATUS_PUB => '已发布'];

    public function selectPageList($params){
        $where = [];
        if(!empty($params['name'])){
            $where[] = ['name', 'like', '%' . $params['name'] . '%'];
        }

        $total = Db::connection('lsbook')->table('page_draft')->where($where)->count();
        if($total <= 0){
            return ['total' => 0, 'list' => []];
        }

        $pageList = Db::connection('lsbook')->table('page_draft')->where($where)
            ->orderBy('id', 'desc')->offset(($params['page'] - 1) * $params['page_size'])->limit($params['page_size'])->get()->toArray();
        foreach($pageList as $i => $page){
            $page->banner_list = empty($page->banner_list) ? '' : json_decode($page->banner_list, true);
            $page->block_list = empty($page->block_list) ? '' : json_decode($page->block_list, true);
            $pageList[$i]->num_banner = count($page->banner_list);
            $pageList[$i]->num_block = count($page->block_list);
            unset($pageList[$i]->banner_list, $pageList[$i]->block_list);
            $pageList[$i]->status_name = $this->statusList[$page->status];
        }

        return ['total' => $total, 'list' => $pageList];
    }

    public function selectPageDetail($params){
        $page = Db::connection('lsbook')->table('page_draft')->where('id', $params['page_id'])->first();
        if(empty($page)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '页面不存在，请重试。');
        }

        $page = json_decode(json_encode($page), true);
        $page['banner_list'] = empty($page['banner_list']) ? '' : json_decode($page['banner_list'], true);
        $page['block_list'] = empty($page['block_list']) ? '' : json_decode($page['block_list'], true);
        $topicIDList = array_column($page['block_list'], 'topic_id');
        $topicList = Db::connection('lsbook')->table('topic')->whereIn('id', $topicIDList)->get()->toArray();
        $topicList = array_column($topicList, 'name', 'id');
        foreach($page['block_list'] as $i => $block){
            $page['block_list'][$i]['topic_name'] = $topicList[$block['topic_id']];
        }

        return $page;
    }

    public function updPage($params){
        Db::connection('lsbook')->table('page_draft')->where('id', $params['page_id'])->update([
            'banner_list' => json_encode($params['banner_list']),
            'block_list' => json_encode($params['block_list']),
            'status' => self::PAGE_STATUS_NOT_PUB
        ]);

        return [];
    }

    public function pubPage($params){
        $page = Db::connection('lsbook')->table('page_draft')->where('id', $params['page_id'])->first();
        if(empty($page)){
            throw new BusinessException(BusinessCode::SERVER_ERROR, '页面不存在，请重试。');
        }

        $bannerList = json_decode($page->banner_list, true);
        $blockList = json_decode($page->block_list, true);
        foreach($bannerList as $i => $banner){
            $bannerList[$i]['page_id'] = $page->id;
        }
        foreach($blockList as $i => $block){
            $blockList[$i]['page_id'] = $page->id;
        }

        Db::connection('lsbook')->beginTransaction();
        try{
            Db::connection('lsbook')->table('page_draft')->where('id', $page->id)->update([
                'status' => self::PAGE_STATUS_PUB,
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            Db::connection('lsbook')->table('page')->updateOrInsert(
                ['id' => $page->id],
                ['name' => $page->name, 'updated_at' => date('Y-m-d H:i:s')]
            );

            Db::connection('lsbook')->table('page_banner')->where('page_id', $page->id)->delete();
            Db::connection('lsbook')->table('page_block')->where('page_id', $page->id)->delete();
            Db::connection('lsbook')->table('page_banner')->insert($bannerList);
            Db::connection('lsbook')->table('page_block')->insert($blockList);
            Db::connection('lsbook')->commit();
        } catch(\Exception $e){
            Db::connection('lsbook')->rollBack();
        }

        return [];
    }
}