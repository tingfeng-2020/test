<?php


declare(strict_types = 1);

namespace App\Model;

class Permission extends \Donjan\Permission\Models\Permission
{
}