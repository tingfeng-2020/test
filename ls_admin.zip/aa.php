<?php
/**
* openssl 实现
*/
define('KEY', '504ad202615d4c42232e308e53040ad6');
$iv= '504ad202615d4c42';
//echo strlen($iv).PHP_EOL;
$str="12345678";
# 加密 md5->true 为16位md5
 $strEncode= base64_encode(openssl_encrypt($str, 'AES-256-CBC',KEY, OPENSSL_RAW_DATA , $iv));   # AES-256-CBC
echo $strEncode.PHP_EOL;
/**
* 解密
*/
echo openssl_decrypt(base64_decode($strEncode), 'AES-256-CBC', KEY, OPENSSL_RAW_DATA, $iv);
/**
     * 加密
     * @param $input
     * @param $key
     * @return string
     * @throws
     */
//    private static function encryptForDES($input, $key){
//        $data = openssl_encrypt($input, 'DES-ECB', $key, OPENSSL_RAW_DATA);
//        $data = base64_encode($data);
//        return $data;
//    }
//————————————————
//版权声明：本文为CSDN博主「尕夜寻欢」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
//原文链接：https://blog.csdn.net/lw545034502/java/article/details/91974921